<?php
if (!defined('ABSPATH')) exit;
if (!is_user_logged_in()) {
    wp_redirect(wp_login_url(get_permalink()));
    exit;
}
$cu = wp_get_current_user();
$nonce = wp_create_nonce('nxerp_nonce');
$ajax_url = admin_url('admin-ajax.php');
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<title>NexoERP — Sistema Empresarial</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
/* ═══════════════════════════════════════════════════
   NEXOERP — DESIGN SYSTEM
   ═══════════════════════════════════════════════════ */
:root {
  --bg-root: #f1f5f9;
  --bg-sidebar: #0f172a;
  --bg-sidebar-hover: rgba(255,255,255,0.06);
  --bg-sidebar-active: rgba(99,102,241,0.18);
  --bg-card: #ffffff;
  --bg-modal-overlay: rgba(15,23,42,0.6);
  --bg-input: #f8fafc;
  --bg-table-header: #f8fafc;
  --bg-table-hover: #f1f5f9;
  --bg-badge: #e0e7ff;
  --border: #e2e8f0;
  --border-focus: #6366f1;
  --text-primary: #0f172a;
  --text-secondary: #475569;
  --text-muted: #94a3b8;
  --text-sidebar: #cbd5e1;
  --text-sidebar-active: #ffffff;
  --accent: #6366f1;
  --accent-hover: #4f46e5;
  --accent-soft: #e0e7ff;
  --accent-gradient: linear-gradient(135deg, #6366f1, #8b5cf6);
  --success: #10b981;
  --success-soft: #d1fae5;
  --warning: #f59e0b;
  --warning-soft: #fef3c7;
  --danger: #ef4444;
  --danger-soft: #fee2e2;
  --info: #06b6d4;
  --info-soft: #cffafe;
  --shadow-sm: 0 1px 2px rgba(0,0,0,0.04);
  --shadow: 0 1px 3px rgba(0,0,0,0.06), 0 1px 2px rgba(0,0,0,0.04);
  --shadow-md: 0 4px 6px -1px rgba(0,0,0,0.07), 0 2px 4px -2px rgba(0,0,0,0.05);
  --shadow-lg: 0 10px 25px -3px rgba(0,0,0,0.08), 0 4px 10px -4px rgba(0,0,0,0.04);
  --shadow-xl: 0 20px 50px -5px rgba(0,0,0,0.12);
  --radius-sm: 6px;
  --radius: 10px;
  --radius-lg: 14px;
  --radius-xl: 20px;
  --sidebar-w: 260px;
  --topbar-h: 60px;
  --font: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;
  --transition: 0.2s cubic-bezier(0.4,0,0.2,1);
}

*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
html, body { height:100%; overflow:hidden; }
body {
  font-family: var(--font);
  background: var(--bg-root);
  color: var(--text-primary);
  font-size: 14px;
  line-height: 1.5;
  -webkit-font-smoothing: antialiased;
}

/* ─── LAYOUT ─── */
.nx-app { display:flex; height:100vh; overflow:hidden; }

/* ─── SIDEBAR ─── */
.nx-sidebar {
  width: var(--sidebar-w);
  min-width: var(--sidebar-w);
  background: var(--bg-sidebar);
  display: flex;
  flex-direction: column;
  z-index: 100;
  transition: transform 0.3s ease;
  overflow: hidden;
}
.nx-sidebar-brand {
  height: var(--topbar-h);
  display: flex;
  align-items: center;
  padding: 0 20px;
  gap: 12px;
  border-bottom: 1px solid rgba(255,255,255,0.06);
  flex-shrink: 0;
}
.nx-brand-icon {
  width: 36px; height: 36px;
  background: var(--accent-gradient);
  border-radius: 10px;
  display: flex; align-items: center; justify-content: center;
  color: #fff; font-weight: 800; font-size: 15px;
  box-shadow: 0 4px 12px rgba(99,102,241,0.4);
}
.nx-brand-text { color:#fff; font-size:17px; font-weight:700; letter-spacing:-0.3px; }
.nx-brand-text span { color:#818cf8; }

.nx-sidebar-nav {
  flex: 1;
  overflow-y: auto;
  padding: 12px 0;
  scrollbar-width: thin;
  scrollbar-color: rgba(255,255,255,0.1) transparent;
}
.nx-nav-section {
  padding: 0 12px;
  margin-bottom: 4px;
}
.nx-nav-label {
  padding: 8px 12px 6px;
  font-size: 10px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1.2px;
  color: rgba(148,163,184,0.5);
}
.nx-nav-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 9px 12px;
  border-radius: 8px;
  color: var(--text-sidebar);
  cursor: pointer;
  font-size: 13px;
  font-weight: 500;
  transition: all var(--transition);
  position: relative;
  user-select: none;
}
.nx-nav-item:hover { background: var(--bg-sidebar-hover); color:#e2e8f0; }
.nx-nav-item.active {
  background: var(--bg-sidebar-active);
  color: var(--text-sidebar-active);
}
.nx-nav-item.active::before {
  content:'';
  position:absolute;
  left: -12px;
  top: 50%;
  transform: translateY(-50%);
  width: 3px;
  height: 20px;
  background: var(--accent);
  border-radius: 0 3px 3px 0;
}
.nx-nav-item i { width:18px; text-align:center; font-size:14px; opacity:0.7; }
.nx-nav-item.active i { opacity:1; color:#a5b4fc; }
.nx-nav-badge {
  margin-left:auto;
  background: var(--danger);
  color:#fff;
  font-size:10px;
  padding:2px 7px;
  border-radius:10px;
  font-weight:700;
  line-height:1.4;
}

.nx-sidebar-footer {
  padding: 16px;
  border-top: 1px solid rgba(255,255,255,0.06);
  flex-shrink: 0;
}
.nx-user-card {
  display: flex; align-items: center; gap: 10px;
  padding: 8px 10px; border-radius: 10px;
  background: rgba(255,255,255,0.04);
}
.nx-user-avatar {
  width:34px; height:34px; border-radius:9px;
  background: var(--accent-gradient);
  display:flex; align-items:center; justify-content:center;
  color:#fff; font-weight:700; font-size:13px;
}
.nx-user-info { flex:1; min-width:0; }
.nx-user-name { color:#e2e8f0; font-size:13px; font-weight:600; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.nx-user-role { color:#64748b; font-size:11px; }

/* ─── MAIN AREA ─── */
.nx-main { flex:1; display:flex; flex-direction:column; overflow:hidden; min-width:0; }

/* ─── TOPBAR ─── */
.nx-topbar {
  height: var(--topbar-h);
  min-height: var(--topbar-h);
  background: var(--bg-card);
  border-bottom: 1px solid var(--border);
  display: flex;
  align-items: center;
  padding: 0 24px;
  gap: 16px;
  z-index: 50;
}
.nx-menu-toggle {
  display:none;
  width:36px; height:36px;
  border:none; background:none;
  font-size:18px; color:var(--text-secondary);
  cursor:pointer; border-radius:8px;
}
.nx-menu-toggle:hover { background:var(--bg-table-hover); }
.nx-page-title { font-size:18px; font-weight:700; letter-spacing:-0.3px; }

.nx-topbar-search {
  margin-left: auto;
  position: relative;
}
.nx-search-trigger {
  display: flex; align-items: center; gap: 8px;
  padding: 7px 14px;
  background: var(--bg-input);
  border: 1px solid var(--border);
  border-radius: 8px;
  color: var(--text-muted);
  font-size: 13px;
  cursor: pointer;
  transition: all var(--transition);
  min-width: 220px;
}
.nx-search-trigger:hover { border-color:#cbd5e1; }
.nx-search-trigger kbd {
  margin-left:auto;
  background:#e2e8f0;
  padding:2px 6px;
  border-radius:4px;
  font-size:11px;
  font-family:inherit;
  color:var(--text-secondary);
}
.nx-topbar-actions { display:flex; gap:4px; }
.nx-topbar-btn {
  width:38px; height:38px; border:none;
  background:none; cursor:pointer;
  border-radius:8px; font-size:16px;
  color:var(--text-secondary);
  position:relative;
  transition: all var(--transition);
}
.nx-topbar-btn:hover { background:var(--bg-table-hover); color:var(--text-primary); }
.nx-topbar-btn .badge-dot {
  position:absolute; top:8px; right:8px;
  width:8px; height:8px; background:var(--danger);
  border-radius:50%; border:2px solid var(--bg-card);
}

/* ─── CONTENT ─── */
.nx-content {
  flex: 1;
  overflow-y: auto;
  padding: 24px;
  scroll-behavior: smooth;
}
.nx-content::-webkit-scrollbar { width:6px; }
.nx-content::-webkit-scrollbar-track { background:transparent; }
.nx-content::-webkit-scrollbar-thumb { background:#cbd5e1; border-radius:3px; }

/* ─── PAGE TRANSITIONS ─── */
.nx-page { animation: nxFadeIn 0.25s ease; }
@keyframes nxFadeIn { from { opacity:0; transform:translateY(8px); } to { opacity:1; transform:translateY(0); } }

/* ─── CARDS ─── */
.nx-card {
  background: var(--bg-card);
  border: 1px solid var(--border);
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow-sm);
  transition: box-shadow var(--transition);
}
.nx-card:hover { box-shadow: var(--shadow); }
.nx-card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 18px 20px;
  border-bottom: 1px solid var(--border);
}
.nx-card-title { font-size:15px; font-weight:700; }
.nx-card-body { padding: 20px; }

/* ─── KPI CARDS ─── */
.nx-kpi-grid { display:grid; grid-template-columns:repeat(auto-fit, minmax(220px,1fr)); gap:16px; margin-bottom:24px; }
.nx-kpi {
  background:var(--bg-card);
  border:1px solid var(--border);
  border-radius:var(--radius-lg);
  padding:20px;
  display:flex; align-items:flex-start; gap:14px;
  transition: all var(--transition);
  box-shadow: var(--shadow-sm);
}
.nx-kpi:hover { box-shadow:var(--shadow-md); transform:translateY(-1px); }
.nx-kpi-icon {
  width:44px; height:44px; border-radius:12px;
  display:flex; align-items:center; justify-content:center;
  font-size:18px; flex-shrink:0;
}
.nx-kpi-icon.indigo { background:var(--accent-soft); color:var(--accent); }
.nx-kpi-icon.green { background:var(--success-soft); color:var(--success); }
.nx-kpi-icon.amber { background:var(--warning-soft); color:var(--warning); }
.nx-kpi-icon.red { background:var(--danger-soft); color:var(--danger); }
.nx-kpi-icon.cyan { background:var(--info-soft); color:var(--info); }
.nx-kpi-info { flex:1; }
.nx-kpi-label { font-size:12px; color:var(--text-muted); font-weight:500; margin-bottom:4px; }
.nx-kpi-value { font-size:22px; font-weight:800; letter-spacing:-0.5px; line-height:1.2; }
.nx-kpi-change { font-size:11px; font-weight:600; margin-top:4px; }
.nx-kpi-change.up { color:var(--success); }
.nx-kpi-change.down { color:var(--danger); }

/* ─── BUTTONS ─── */
.nx-btn {
  display:inline-flex; align-items:center; gap:6px;
  padding:8px 16px; border-radius:8px;
  font-size:13px; font-weight:600; font-family:var(--font);
  border:none; cursor:pointer;
  transition:all var(--transition);
  line-height:1.4;
  white-space: nowrap;
}
.nx-btn-primary { background:var(--accent); color:#fff; }
.nx-btn-primary:hover { background:var(--accent-hover); box-shadow:0 4px 12px rgba(99,102,241,0.3); }
.nx-btn-secondary { background:var(--bg-input); color:var(--text-primary); border:1px solid var(--border); }
.nx-btn-secondary:hover { background:#e2e8f0; }
.nx-btn-danger { background:var(--danger); color:#fff; }
.nx-btn-danger:hover { background:#dc2626; }
.nx-btn-success { background:var(--success); color:#fff; }
.nx-btn-success:hover { background:#059669; }
.nx-btn-ghost { background:none; color:var(--text-secondary); }
.nx-btn-ghost:hover { background:var(--bg-table-hover); }
.nx-btn-sm { padding:5px 10px; font-size:12px; }
.nx-btn-xs { padding:3px 8px; font-size:11px; border-radius:6px; }
.nx-btn-icon { width:34px; height:34px; padding:0; justify-content:center; border-radius:8px; }

/* ─── TABLES ─── */
.nx-table-wrap { overflow-x:auto; }
.nx-table {
  width:100%; border-collapse:collapse; font-size:13px;
}
.nx-table th {
  text-align:left; padding:10px 14px;
  background:var(--bg-table-header);
  font-weight:600; font-size:12px;
  color:var(--text-secondary);
  text-transform:uppercase;
  letter-spacing:0.5px;
  border-bottom:1px solid var(--border);
  white-space:nowrap;
}
.nx-table td {
  padding:10px 14px;
  border-bottom:1px solid var(--border);
  vertical-align:middle;
}
.nx-table tbody tr { transition:background var(--transition); }
.nx-table tbody tr:hover { background:var(--bg-table-hover); }
.nx-table tbody tr:last-child td { border-bottom:none; }

/* ─── BADGES ─── */
.nx-badge {
  display:inline-flex; align-items:center;
  padding:3px 10px; border-radius:20px;
  font-size:11px; font-weight:600;
  line-height:1.4;
}
.nx-badge-draft { background:#f1f5f9; color:#64748b; }
.nx-badge-sent { background:#dbeafe; color:#2563eb; }
.nx-badge-approved { background:var(--accent-soft); color:var(--accent); }
.nx-badge-paid { background:var(--success-soft); color:var(--success); }
.nx-badge-partial { background:var(--warning-soft); color:var(--warning); }
.nx-badge-overdue, .nx-badge-cancelled { background:var(--danger-soft); color:var(--danger); }
.nx-badge-active { background:var(--success-soft); color:var(--success); }
.nx-badge-inactive { background:#f1f5f9; color:#94a3b8; }
.nx-badge-client { background:#dbeafe; color:#2563eb; }
.nx-badge-supplier { background:#fce7f3; color:#db2777; }
.nx-badge-lead { background:var(--warning-soft); color:#d97706; }
.nx-badge-received { background:var(--info-soft); color:var(--info); }

/* ─── FORMS ─── */
.nx-form-group { margin-bottom:16px; }
.nx-form-label { display:block; font-size:12px; font-weight:600; color:var(--text-secondary); margin-bottom:5px; }
.nx-form-row { display:grid; grid-template-columns:1fr 1fr; gap:14px; }
.nx-form-row-3 { display:grid; grid-template-columns:1fr 1fr 1fr; gap:14px; }

.nx-input, .nx-select, .nx-textarea {
  width:100%; padding:9px 12px;
  background:var(--bg-input);
  border:1px solid var(--border);
  border-radius:8px;
  font-size:13px; font-family:var(--font);
  color:var(--text-primary);
  transition:all var(--transition);
  outline:none;
}
.nx-input:focus, .nx-select:focus, .nx-textarea:focus {
  border-color:var(--border-focus);
  box-shadow:0 0 0 3px rgba(99,102,241,0.08);
}
.nx-textarea { resize:vertical; min-height:80px; }
.nx-select { cursor:pointer; }

/* ─── MODALS ─── */
.nx-modal-overlay {
  position:fixed; inset:0;
  background:var(--bg-modal-overlay);
  backdrop-filter:blur(4px);
  z-index:1000;
  display:flex; align-items:flex-start; justify-content:center;
  padding:40px 20px;
  overflow-y:auto;
  animation: nxFadeOverlay 0.2s ease;
}
@keyframes nxFadeOverlay { from { opacity:0; } to { opacity:1; } }
.nx-modal {
  background:var(--bg-card);
  border-radius:var(--radius-xl);
  box-shadow:var(--shadow-xl);
  width:100%; max-width:640px;
  animation: nxSlideUp 0.25s ease;
}
@keyframes nxSlideUp { from { opacity:0; transform:translateY(16px); } to { opacity:1; transform:translateY(0); } }
.nx-modal-lg { max-width:860px; }
.nx-modal-header {
  display:flex; align-items:center; justify-content:space-between;
  padding:20px 24px;
  border-bottom:1px solid var(--border);
}
.nx-modal-title { font-size:17px; font-weight:700; }
.nx-modal-close {
  width:32px; height:32px; border:none;
  background:none; cursor:pointer; border-radius:8px;
  font-size:18px; color:var(--text-muted);
  transition:all var(--transition);
  display:flex; align-items:center; justify-content:center;
}
.nx-modal-close:hover { background:var(--bg-table-hover); color:var(--text-primary); }
.nx-modal-body { padding:24px; max-height:65vh; overflow-y:auto; }
.nx-modal-footer {
  display:flex; align-items:center; justify-content:flex-end; gap:8px;
  padding:16px 24px;
  border-top:1px solid var(--border);
}

/* ─── COMMAND PALETTE ─── */
.nx-cmd-overlay {
  position:fixed; inset:0;
  background:rgba(15,23,42,0.5);
  backdrop-filter:blur(8px);
  z-index:2000;
  display:flex; align-items:flex-start; justify-content:center;
  padding-top:20vh;
  animation: nxFadeOverlay 0.15s ease;
}
.nx-cmd-box {
  background:var(--bg-card);
  border-radius:var(--radius-xl);
  box-shadow:var(--shadow-xl);
  width:90%; max-width:560px;
  overflow:hidden;
  animation: nxSlideUp 0.2s ease;
}
.nx-cmd-input-wrap {
  display:flex; align-items:center; gap:10px;
  padding:16px 20px;
  border-bottom:1px solid var(--border);
}
.nx-cmd-input-wrap i { color:var(--text-muted); font-size:16px; }
.nx-cmd-input {
  flex:1; border:none; background:none;
  font-size:15px; font-family:var(--font);
  color:var(--text-primary);
  outline:none;
}
.nx-cmd-results { max-height:300px; overflow-y:auto; padding:8px; }
.nx-cmd-item {
  display:flex; align-items:center; gap:10px;
  padding:10px 12px; border-radius:8px;
  cursor:pointer; transition:background 0.1s;
  font-size:13px;
}
.nx-cmd-item:hover, .nx-cmd-item.active { background:var(--bg-table-hover); }
.nx-cmd-item i { width:20px; text-align:center; color:var(--text-muted); }
.nx-cmd-item-label { flex:1; }
.nx-cmd-item-type { font-size:11px; color:var(--text-muted); }

/* ─── TOAST ─── */
.nx-toast-container {
  position:fixed; top:20px; right:20px;
  z-index:5000; display:flex; flex-direction:column; gap:8px;
}
.nx-toast {
  display:flex; align-items:center; gap:10px;
  padding:12px 16px;
  background:var(--bg-card);
  border:1px solid var(--border);
  border-radius:var(--radius);
  box-shadow:var(--shadow-lg);
  font-size:13px; font-weight:500;
  animation: nxSlideRight 0.3s ease;
  min-width:280px;
}
@keyframes nxSlideRight { from { transform:translateX(100%); opacity:0; } to { transform:translateX(0); opacity:1; } }
.nx-toast.success { border-left:3px solid var(--success); }
.nx-toast.error { border-left:3px solid var(--danger); }
.nx-toast.warning { border-left:3px solid var(--warning); }
.nx-toast.info { border-left:3px solid var(--info); }
.nx-toast i { font-size:16px; }
.nx-toast.success i { color:var(--success); }
.nx-toast.error i { color:var(--danger); }
.nx-toast.warning i { color:var(--warning); }
.nx-toast.info i { color:var(--info); }

/* ─── TOOLBAR ─── */
.nx-toolbar {
  display:flex; align-items:center; gap:10px;
  margin-bottom:16px; flex-wrap:wrap;
}
.nx-toolbar-search {
  position:relative; flex:1; min-width:200px; max-width:320px;
}
.nx-toolbar-search i {
  position:absolute; left:10px; top:50%; transform:translateY(-50%);
  color:var(--text-muted); font-size:13px;
}
.nx-toolbar-search input {
  width:100%; padding:8px 12px 8px 32px;
  background:var(--bg-input); border:1px solid var(--border);
  border-radius:8px; font-size:13px; font-family:var(--font);
  outline:none; transition:all var(--transition);
}
.nx-toolbar-search input:focus { border-color:var(--border-focus); }

.nx-filter-btn {
  display:inline-flex; align-items:center; gap:5px;
  padding:7px 12px; border-radius:8px;
  font-size:12px; font-weight:600; font-family:var(--font);
  border:1px solid var(--border); background:var(--bg-card);
  color:var(--text-secondary); cursor:pointer;
  transition:all var(--transition);
}
.nx-filter-btn:hover { background:var(--bg-table-hover); }
.nx-filter-btn.active { background:var(--accent-soft); color:var(--accent); border-color:var(--accent); }

/* ─── PAGINATION ─── */
.nx-pagination {
  display:flex; align-items:center; justify-content:space-between;
  padding:12px 0; font-size:13px; color:var(--text-muted);
}
.nx-pagination-btns { display:flex; gap:4px; }
.nx-page-btn {
  padding:6px 12px; border-radius:6px;
  border:1px solid var(--border); background:var(--bg-card);
  font-size:12px; font-family:var(--font);
  cursor:pointer; transition:all var(--transition);
}
.nx-page-btn:hover { background:var(--bg-table-hover); }
.nx-page-btn.active { background:var(--accent); color:#fff; border-color:var(--accent); }

/* ─── EMPTY STATE ─── */
.nx-empty {
  text-align:center; padding:48px 20px;
  color:var(--text-muted);
}
.nx-empty i { font-size:40px; margin-bottom:12px; opacity:0.4; }
.nx-empty p { font-size:14px; margin-top:4px; }

/* ─── TABS ─── */
.nx-tabs { display:flex; gap:2px; border-bottom:1px solid var(--border); margin-bottom:20px; }
.nx-tab {
  padding:10px 18px; font-size:13px; font-weight:600;
  color:var(--text-muted); cursor:pointer;
  border-bottom:2px solid transparent;
  transition:all var(--transition);
  font-family:var(--font); background:none; border-top:none; border-left:none; border-right:none;
}
.nx-tab:hover { color:var(--text-primary); }
.nx-tab.active { color:var(--accent); border-bottom-color:var(--accent); }

/* ─── DASHBOARD CHARTS ─── */
.nx-chart-grid { display:grid; grid-template-columns:2fr 1fr; gap:16px; margin-bottom:24px; }
.nx-chart-card { background:var(--bg-card); border:1px solid var(--border); border-radius:var(--radius-lg); padding:20px; box-shadow:var(--shadow-sm); }
.nx-chart-title { font-size:14px; font-weight:700; margin-bottom:16px; }
.nx-chart-canvas { width:100%; height:240px; }

/* ─── KANBAN BOARD ─── */
.nx-kanban { display:flex; gap:14px; overflow-x:auto; padding-bottom:16px; min-height:400px; }
.nx-kanban-col {
  min-width:260px; width:260px;
  background:var(--bg-input);
  border-radius:var(--radius-lg);
  display:flex; flex-direction:column;
  flex-shrink:0;
}
.nx-kanban-col-header {
  padding:14px 16px;
  font-size:13px; font-weight:700;
  display:flex; align-items:center; gap:8px;
  border-bottom:2px solid var(--border);
}
.nx-kanban-col-header .count {
  background:#e2e8f0; padding:2px 8px;
  border-radius:10px; font-size:11px; color:var(--text-secondary);
}
.nx-kanban-col-body {
  flex:1; padding:10px;
  display:flex; flex-direction:column; gap:8px;
  overflow-y:auto;
}
.nx-kanban-card {
  background:var(--bg-card);
  border:1px solid var(--border);
  border-radius:var(--radius);
  padding:12px;
  cursor:grab;
  transition:box-shadow var(--transition);
}
.nx-kanban-card:hover { box-shadow:var(--shadow-md); }
.nx-kanban-card-title { font-size:13px; font-weight:600; margin-bottom:6px; }
.nx-kanban-card-meta { display:flex; align-items:center; gap:8px; font-size:11px; color:var(--text-muted); }

/* ─── STAT ROW ─── */
.nx-stat-row { display:flex; align-items:center; justify-content:space-between; padding:10px 0; border-bottom:1px solid var(--border); }
.nx-stat-row:last-child { border:none; }

/* ─── RESPONSIVE ─── */
@media (max-width:768px) {
  .nx-sidebar {
    position:fixed; inset:0; right:auto;
    transform:translateX(-100%);
    z-index:200;
    box-shadow:var(--shadow-xl);
  }
  .nx-sidebar.open { transform:translateX(0); }
  .nx-menu-toggle { display:flex; align-items:center; justify-content:center; }
  .nx-content { padding:16px; }
  .nx-kpi-grid { grid-template-columns:1fr 1fr; gap:10px; }
  .nx-chart-grid { grid-template-columns:1fr; }
  .nx-form-row, .nx-form-row-3 { grid-template-columns:1fr; }
  .nx-modal { margin:10px; }
  .nx-topbar { padding:0 12px; }
  .nx-search-trigger { display:none; }
}

/* ─── LINE ITEMS TABLE ─── */
.nx-items-table { width:100%; font-size:12px; border-collapse:collapse; }
.nx-items-table th { text-align:left; padding:6px 8px; font-weight:600; color:var(--text-secondary); font-size:11px; text-transform:uppercase; letter-spacing:0.3px; border-bottom:1px solid var(--border); }
.nx-items-table td { padding:6px 8px; border-bottom:1px solid var(--border); }
.nx-items-table input, .nx-items-table select {
  width:100%; padding:6px 8px; border:1px solid var(--border); border-radius:6px;
  font-size:12px; font-family:var(--font); background:var(--bg-input);
}
.nx-items-table input:focus { border-color:var(--border-focus); outline:none; }
.nx-items-total { text-align:right; padding:12px 0; }
.nx-items-total-row { display:flex; justify-content:flex-end; gap:20px; font-size:13px; padding:4px 0; }
.nx-items-total-row.grand { font-size:16px; font-weight:800; color:var(--accent); }

/* ─── LOADING ─── */
.nx-loading { text-align:center; padding:40px; color:var(--text-muted); }
.nx-spinner {
  display:inline-block; width:28px; height:28px;
  border:3px solid var(--border);
  border-top-color:var(--accent);
  border-radius:50%;
  animation: nxSpin 0.6s linear infinite;
}
@keyframes nxSpin { to { transform:rotate(360deg); } }

/* ─── UTIL ─── */
.text-right { text-align:right!important; }
.text-center { text-align:center!important; }
.text-muted { color:var(--text-muted)!important; }
.text-success { color:var(--success)!important; }
.text-danger { color:var(--danger)!important; }
.text-accent { color:var(--accent)!important; }
.mt-1 { margin-top:8px; }
.mt-2 { margin-top:16px; }
.mb-2 { margin-bottom:16px; }
.gap-2 { gap:16px; }
.fw-bold { font-weight:700; }
.d-flex { display:flex; }
.ai-center { align-items:center; }
.jc-between { justify-content:space-between; }
.clickable { cursor:pointer; }
.hidden { display:none!important; }

/* ─── OVERLAY FOR MOBILE ─── */
.nx-overlay {
  position:fixed; inset:0;
  background:rgba(0,0,0,0.4);
  z-index:150;
  display:none;
}
.nx-overlay.show { display:block; }
</style>
</head>
<body>
<div class="nx-app" id="nxApp">
<!-- ═══ SIDEBAR ═══ -->
<aside class="nx-sidebar" id="nxSidebar">
  <div class="nx-sidebar-brand">
    <div class="nx-brand-icon">NX</div>
    <div class="nx-brand-text">Nexo<span>ERP</span></div>
  </div>
  <nav class="nx-sidebar-nav" id="nxNav">
    <div class="nx-nav-section">
      <div class="nx-nav-item active" data-page="dashboard"><i class="fas fa-th-large"></i> Dashboard</div>
    </div>
    <div class="nx-nav-section">
      <div class="nx-nav-label">Ventas</div>
      <div class="nx-nav-item" data-page="quotes"><i class="fas fa-file-alt"></i> Cotizaciones</div>
      <div class="nx-nav-item" data-page="orders"><i class="fas fa-shopping-cart"></i> Pedidos</div>
      <div class="nx-nav-item" data-page="invoices"><i class="fas fa-file-invoice-dollar"></i> Facturas</div>
    </div>
    <div class="nx-nav-section">
      <div class="nx-nav-label">Compras</div>
      <div class="nx-nav-item" data-page="purchase_orders"><i class="fas fa-truck"></i> Ordenes Compra</div>
    </div>
    <div class="nx-nav-section">
      <div class="nx-nav-label">Catalogo</div>
      <div class="nx-nav-item" data-page="contacts"><i class="fas fa-address-book"></i> Contactos</div>
      <div class="nx-nav-item" data-page="products"><i class="fas fa-boxes-stacked"></i> Productos</div>
      <div class="nx-nav-item" data-page="inventory"><i class="fas fa-warehouse"></i> Inventario</div>
    </div>
    <div class="nx-nav-section">
      <div class="nx-nav-label">Finanzas</div>
      <div class="nx-nav-item" data-page="banks"><i class="fas fa-building-columns"></i> Bancos</div>
      <div class="nx-nav-item" data-page="accounting"><i class="fas fa-calculator"></i> Contabilidad</div>
    </div>
    <div class="nx-nav-section">
      <div class="nx-nav-label">RRHH</div>
      <div class="nx-nav-item" data-page="employees"><i class="fas fa-users"></i> Empleados</div>
      <div class="nx-nav-item" data-page="payroll"><i class="fas fa-money-check"></i> Nomina</div>
    </div>
    <div class="nx-nav-section">
      <div class="nx-nav-label">Proyectos</div>
      <div class="nx-nav-item" data-page="projects"><i class="fas fa-diagram-project"></i> Proyectos</div>
    </div>
    <div class="nx-nav-section">
      <div class="nx-nav-label">Herramientas</div>
      <div class="nx-nav-item" data-page="reports"><i class="fas fa-chart-pie"></i> Reportes</div>
      <div class="nx-nav-item" data-page="settings"><i class="fas fa-gear"></i> Configuracion</div>
      <div class="nx-nav-item" data-page="activity"><i class="fas fa-clock-rotate-left"></i> Auditoria</div>
    </div>
  </nav>
  <div class="nx-sidebar-footer">
    <div class="nx-user-card">
      <div class="nx-user-avatar"><?php echo strtoupper(mb_substr($cu->display_name,0,2)); ?></div>
      <div class="nx-user-info">
        <div class="nx-user-name"><?php echo esc_html($cu->display_name); ?></div>
        <div class="nx-user-role"><?php echo current_user_can('manage_options') ? 'Administrador' : 'Usuario'; ?></div>
      </div>
    </div>
  </div>
</aside>

<div class="nx-overlay" id="nxOverlay"></div>

<!-- ═══ MAIN ═══ -->
<div class="nx-main">
  <header class="nx-topbar">
    <button class="nx-menu-toggle" id="nxMenuBtn"><i class="fas fa-bars"></i></button>
    <div class="nx-page-title" id="nxPageTitle">Dashboard</div>
    <div class="nx-topbar-search">
      <div class="nx-search-trigger" id="nxSearchTrigger">
        <i class="fas fa-search"></i> Buscar...
        <kbd>Ctrl+K</kbd>
      </div>
    </div>
    <div class="nx-topbar-actions">
      <button class="nx-topbar-btn" onclick="NX.toggleNotifications()" title="Notificaciones">
        <i class="fas fa-bell"></i>
        <span class="badge-dot hidden" id="nxNotifDot"></span>
      </button>
    </div>
  </header>
  <main class="nx-content" id="nxContent">
    <div class="nx-loading"><div class="nx-spinner"></div><p class="mt-1">Cargando...</p></div>
  </main>
</div>
</div>

<!-- ═══ TOAST CONTAINER ═══ -->
<div class="nx-toast-container" id="nxToasts"></div>

<script>
/* ═══════════════════════════════════════════════════
   NEXOERP — APPLICATION ENGINE
   ═══════════════════════════════════════════════════ */
const NX = {
  ajax: '<?php echo esc_js($ajax_url); ?>',
  nonce: '<?php echo $nonce; ?>',
  currentPage: 'dashboard',
  charts: {},

  /* ─── AJAX HELPER ─── */
  async api(action, data = {}) {
    const fd = new FormData();
    fd.append('action', 'nxerp');
    fd.append('_nonce', this.nonce);
    fd.append('do', action);
    for (const [k, v] of Object.entries(data)) {
      fd.append(k, typeof v === 'object' ? JSON.stringify(v) : v);
    }
    try {
      const r = await fetch(this.ajax, { method: 'POST', body: fd, credentials: 'same-origin' });
      const j = await r.json();
      if (!j.success) throw new Error(j.data || 'Error desconocido');
      return j.data;
    } catch (e) {
      this.toast(e.message, 'error');
      throw e;
    }
  },

  /* ─── TOAST ─── */
  toast(msg, type = 'info') {
    const icons = { success: 'fa-check-circle', error: 'fa-exclamation-circle', warning: 'fa-exclamation-triangle', info: 'fa-info-circle' };
    const c = document.getElementById('nxToasts');
    const t = document.createElement('div');
    t.className = `nx-toast ${type}`;
    t.innerHTML = `<i class="fas ${icons[type]||icons.info}"></i><span>${msg}</span>`;
    c.appendChild(t);
    setTimeout(() => { t.style.opacity = '0'; t.style.transform = 'translateX(50px)'; setTimeout(() => t.remove(), 300); }, 3500);
  },

  /* ─── NAVIGATION ─── */
  navigate(page) {
    this.currentPage = page;
    document.querySelectorAll('.nx-nav-item').forEach(n => n.classList.toggle('active', n.dataset.page === page));
    const titles = {
      dashboard:'Dashboard', contacts:'Contactos', products:'Productos', inventory:'Inventario',
      quotes:'Cotizaciones', orders:'Pedidos', invoices:'Facturas', purchase_orders:'Ordenes de Compra',
      banks:'Bancos', accounting:'Contabilidad', employees:'Empleados', payroll:'Nomina',
      projects:'Proyectos', reports:'Reportes', settings:'Configuracion', activity:'Auditoria'
    };
    document.getElementById('nxPageTitle').textContent = titles[page] || page;
    this.closeMobile();
    this.renderPage(page);
  },

  /* ─── RENDER ROUTER ─── */
  async renderPage(page) {
    const c = document.getElementById('nxContent');
    c.innerHTML = '<div class="nx-loading"><div class="nx-spinner"></div></div>';
    try {
      switch (page) {
        case 'dashboard': await this.pageDashboard(c); break;
        case 'contacts': await this.pageContacts(c); break;
        case 'products': await this.pageProducts(c); break;
        case 'inventory': await this.pageInventory(c); break;
        case 'quotes': await this.pageDocuments(c, 'quote', 'Cotizaciones'); break;
        case 'orders': await this.pageDocuments(c, 'order', 'Pedidos'); break;
        case 'invoices': await this.pageDocuments(c, 'invoice', 'Facturas'); break;
        case 'purchase_orders': await this.pageDocuments(c, 'purchase_order', 'Ordenes de Compra'); break;
        case 'banks': await this.pageBanks(c); break;
        case 'accounting': await this.pageAccounting(c); break;
        case 'employees': await this.pageEmployees(c); break;
        case 'payroll': await this.pagePayroll(c); break;
        case 'projects': await this.pageProjects(c); break;
        case 'reports': await this.pageReports(c); break;
        case 'settings': await this.pageSettings(c); break;
        case 'activity': await this.pageActivity(c); break;
        default: c.innerHTML = '<div class="nx-empty"><i class="fas fa-tools"></i><p>Modulo en desarrollo</p></div>';
      }
    } catch (e) { c.innerHTML = `<div class="nx-empty"><i class="fas fa-exclamation-triangle"></i><p>${e.message}</p></div>`; }
  },

  /* ─── FORMAT HELPERS ─── */
  money(v) { return '$' + Number(v||0).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); },
  num(v) { return Number(v||0).toLocaleString('es-MX'); },
  date(d) { if (!d) return '—'; const dt = new Date(d + 'T00:00:00'); return dt.toLocaleDateString('es-MX', { day:'2-digit', month:'short', year:'numeric' }); },
  badge(status) {
    const labels = { draft:'Borrador',sent:'Enviado',approved:'Aprobado',paid:'Pagado',partial:'Parcial',overdue:'Vencido',cancelled:'Cancelado',active:'Activo',inactive:'Inactivo',blocked:'Bloqueado',received:'Recibido',planning:'Planeacion',paused:'Pausado',completed:'Completado',client:'Cliente',supplier:'Proveedor',lead:'Lead' };
    return `<span class="nx-badge nx-badge-${status}">${labels[status]||status}</span>`;
  },
  pctChange(cur, prev) {
    if (!prev) return '';
    const pct = ((cur - prev) / prev * 100).toFixed(1);
    return pct >= 0 ? `<span class="nx-kpi-change up"><i class="fas fa-arrow-up"></i> ${pct}%</span>` : `<span class="nx-kpi-change down"><i class="fas fa-arrow-down"></i> ${Math.abs(pct)}%</span>`;
  },

  /* ════════════════════════════════════════════════
     PAGE: DASHBOARD
     ════════════════════════════════════════════════ */
  async pageDashboard(c) {
    const s = await this.api('dashboard_stats');
    c.innerHTML = `<div class="nx-page">
      <div class="nx-kpi-grid">
        <div class="nx-kpi"><div class="nx-kpi-icon indigo"><i class="fas fa-chart-line"></i></div><div class="nx-kpi-info"><div class="nx-kpi-label">Ventas del Mes</div><div class="nx-kpi-value">${this.money(s.sales_month)}</div>${this.pctChange(s.sales_month, s.sales_last_month)}</div></div>
        <div class="nx-kpi"><div class="nx-kpi-icon amber"><i class="fas fa-clock"></i></div><div class="nx-kpi-info"><div class="nx-kpi-label">Por Cobrar</div><div class="nx-kpi-value">${this.money(s.receivables)}</div><div class="nx-kpi-change">${s.overdue_invoices} vencidas</div></div></div>
        <div class="nx-kpi"><div class="nx-kpi-icon green"><i class="fas fa-building-columns"></i></div><div class="nx-kpi-info"><div class="nx-kpi-label">Saldo Bancos</div><div class="nx-kpi-value">${this.money(s.bank_total)}</div></div></div>
        <div class="nx-kpi"><div class="nx-kpi-icon red"><i class="fas fa-file-invoice"></i></div><div class="nx-kpi-info"><div class="nx-kpi-label">Por Pagar</div><div class="nx-kpi-value">${this.money(s.payables)}</div></div></div>
      </div>
      <div class="nx-kpi-grid">
        <div class="nx-kpi clickable" onclick="NX.navigate('contacts')"><div class="nx-kpi-icon cyan"><i class="fas fa-users"></i></div><div class="nx-kpi-info"><div class="nx-kpi-label">Clientes</div><div class="nx-kpi-value">${s.clients}</div></div></div>
        <div class="nx-kpi clickable" onclick="NX.navigate('products')"><div class="nx-kpi-icon indigo"><i class="fas fa-box"></i></div><div class="nx-kpi-info"><div class="nx-kpi-label">Productos</div><div class="nx-kpi-value">${s.products}</div></div></div>
        <div class="nx-kpi clickable" onclick="NX.navigate('employees')"><div class="nx-kpi-icon green"><i class="fas fa-id-badge"></i></div><div class="nx-kpi-info"><div class="nx-kpi-label">Empleados</div><div class="nx-kpi-value">${s.employees}</div></div></div>
        <div class="nx-kpi clickable" onclick="NX.navigate('projects')"><div class="nx-kpi-icon amber"><i class="fas fa-diagram-project"></i></div><div class="nx-kpi-info"><div class="nx-kpi-label">Proyectos Activos</div><div class="nx-kpi-value">${s.active_projects}</div></div></div>
      </div>
      <div class="nx-chart-grid">
        <div class="nx-chart-card"><div class="nx-chart-title">Ventas Ultimos 6 Meses</div><canvas id="nxChartSales" class="nx-chart-canvas"></canvas></div>
        <div class="nx-chart-card"><div class="nx-chart-title">Alertas</div>
          <div style="padding:8px 0">
            ${s.low_stock ? `<div class="nx-stat-row"><span><i class="fas fa-exclamation-triangle text-danger"></i> Stock bajo</span><strong>${s.low_stock} productos</strong></div>` : ''}
            ${s.overdue_invoices ? `<div class="nx-stat-row"><span><i class="fas fa-clock text-danger"></i> Facturas vencidas</span><strong>${s.overdue_invoices}</strong></div>` : ''}
            <div class="nx-stat-row"><span><i class="fas fa-tasks text-accent"></i> Tareas pendientes</span><strong>${s.pending_tasks}</strong></div>
            <div class="nx-stat-row"><span><i class="fas fa-truck text-muted"></i> Proveedores</span><strong>${s.suppliers}</strong></div>
            ${!s.low_stock && !s.overdue_invoices ? '<div class="nx-stat-row text-success" style="justify-content:center;border:none"><i class="fas fa-check-circle"></i>&nbsp; Todo al dia</div>' : ''}
          </div>
          <div class="nx-chart-title mt-2">Top Productos</div>
          ${(s.top_products||[]).map(p => `<div class="nx-stat-row"><span style="font-size:12px">${p.name||'Sin nombre'}</span><strong style="font-size:12px">${this.money(p.revenue)}</strong></div>`).join('')}
        </div>
      </div>
      <div class="nx-card"><div class="nx-card-header"><div class="nx-card-title">Actividad Reciente</div></div><div class="nx-card-body" style="padding:0">
        <table class="nx-table"><thead><tr><th>Usuario</th><th>Accion</th><th>Modulo</th><th>Descripcion</th><th>Fecha</th></tr></thead>
        <tbody>${(s.recent_activity||[]).map(a => `<tr><td>${a.user_name}</td><td>${a.action}</td><td>${a.module}</td><td>${a.description}</td><td style="font-size:11px;color:var(--text-muted)">${a.created_at}</td></tr>`).join('')}</tbody></table>
      </div></div>
    </div>`;
    /* Chart */
    const ctx = document.getElementById('nxChartSales');
    if (ctx && s.sales_chart) {
      if (this.charts.sales) this.charts.sales.destroy();
      this.charts.sales = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: s.sales_chart.map(x => x.month),
          datasets: [{ label: 'Ventas', data: s.sales_chart.map(x => x.value), backgroundColor: 'rgba(99,102,241,0.7)', borderRadius: 6, borderSkipped: false }]
        },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { callback: v => '$'+v.toLocaleString() } }, x: { grid: { display: false } } } }
      });
    }
  },

  /* ════════════════════════════════════════════════
     PAGE: CONTACTS
     ════════════════════════════════════════════════ */
  contactType: 'client',
  async pageContacts(c) {
    const type = this.contactType;
    const data = await this.api('contacts_list', { type });
    c.innerHTML = `<div class="nx-page">
      <div class="nx-toolbar">
        <div class="nx-filter-btn ${type==='client'?'active':''}" onclick="NX.contactType='client';NX.pageContacts(document.getElementById('nxContent'))">Clientes</div>
        <div class="nx-filter-btn ${type==='supplier'?'active':''}" onclick="NX.contactType='supplier';NX.pageContacts(document.getElementById('nxContent'))">Proveedores</div>
        <div class="nx-filter-btn ${type==='lead'?'active':''}" onclick="NX.contactType='lead';NX.pageContacts(document.getElementById('nxContent'))">Leads</div>
        <div class="nx-toolbar-search"><i class="fas fa-search"></i><input placeholder="Buscar contacto..." onkeyup="if(event.key==='Enter')NX.searchContacts(this.value)"></div>
        <button class="nx-btn nx-btn-primary" style="margin-left:auto" onclick="NX.editContact()"><i class="fas fa-plus"></i> Nuevo</button>
      </div>
      <div class="nx-card"><div class="nx-table-wrap"><table class="nx-table"><thead><tr><th>Nombre</th><th>RFC</th><th>Email</th><th>Telefono</th><th>Saldo</th><th>Estado</th><th></th></tr></thead>
      <tbody>${data.rows.length ? data.rows.map(r => `<tr>
        <td><strong>${r.name}</strong></td><td>${r.rfc||'—'}</td><td>${r.email||'—'}</td><td>${r.phone||'—'}</td>
        <td class="text-right">${this.money(r.balance)}</td><td>${this.badge(r.status)}</td>
        <td class="text-right"><button class="nx-btn nx-btn-ghost nx-btn-sm" onclick="NX.editContact(${r.id})"><i class="fas fa-pen"></i></button>
        <button class="nx-btn nx-btn-ghost nx-btn-sm text-danger" onclick="NX.deleteContact(${r.id})"><i class="fas fa-trash"></i></button></td>
      </tr>`).join('') : '<tr><td colspan="7" class="text-center text-muted" style="padding:32px">Sin registros</td></tr>'}</tbody></table></div></div>
    </div>`;
  },

  async searchContacts(q) {
    const data = await this.api('contacts_list', { type: this.contactType, search: q });
    const tbody = document.querySelector('.nx-table tbody');
    if (tbody) tbody.innerHTML = data.rows.map(r => `<tr><td><strong>${r.name}</strong></td><td>${r.rfc||'—'}</td><td>${r.email||'—'}</td><td>${r.phone||'—'}</td><td class="text-right">${this.money(r.balance)}</td><td>${this.badge(r.status)}</td><td class="text-right"><button class="nx-btn nx-btn-ghost nx-btn-sm" onclick="NX.editContact(${r.id})"><i class="fas fa-pen"></i></button><button class="nx-btn nx-btn-ghost nx-btn-sm text-danger" onclick="NX.deleteContact(${r.id})"><i class="fas fa-trash"></i></button></td></tr>`).join('') || '<tr><td colspan="7" class="text-center text-muted">Sin resultados</td></tr>';
  },

  async editContact(id) {
    let r = { type:this.contactType, name:'',rfc:'',email:'',phone:'',address:'',city:'',state:'',zip:'',credit_limit:0,notes:'',status:'active',tags:'',lead_stage:'',lead_value:0 };
    if (id) r = await this.api('contact_get', { id });
    const isLead = r.type === 'lead';
    this.openModal('Contacto', `
      <div class="nx-form-row"><div class="nx-form-group"><label class="nx-form-label">Nombre *</label><input class="nx-input" id="mf_name" value="${r.name}"></div>
      <div class="nx-form-group"><label class="nx-form-label">RFC</label><input class="nx-input" id="mf_rfc" value="${r.rfc||''}"></div></div>
      <div class="nx-form-row"><div class="nx-form-group"><label class="nx-form-label">Email</label><input class="nx-input" id="mf_email" value="${r.email||''}"></div>
      <div class="nx-form-group"><label class="nx-form-label">Telefono</label><input class="nx-input" id="mf_phone" value="${r.phone||''}"></div></div>
      <div class="nx-form-group"><label class="nx-form-label">Direccion</label><textarea class="nx-textarea" id="mf_address" rows="2">${r.address||''}</textarea></div>
      <div class="nx-form-row-3"><div class="nx-form-group"><label class="nx-form-label">Ciudad</label><input class="nx-input" id="mf_city" value="${r.city||''}"></div>
      <div class="nx-form-group"><label class="nx-form-label">Estado</label><input class="nx-input" id="mf_state" value="${r.state||''}"></div>
      <div class="nx-form-group"><label class="nx-form-label">CP</label><input class="nx-input" id="mf_zip" value="${r.zip||''}"></div></div>
      <div class="nx-form-row"><div class="nx-form-group"><label class="nx-form-label">Limite Credito</label><input class="nx-input" id="mf_credit" type="number" value="${r.credit_limit||0}"></div>
      <div class="nx-form-group"><label class="nx-form-label">Estado</label><select class="nx-select" id="mf_status"><option value="active" ${r.status==='active'?'selected':''}>Activo</option><option value="inactive" ${r.status==='inactive'?'selected':''}>Inactivo</option><option value="blocked" ${r.status==='blocked'?'selected':''}>Bloqueado</option></select></div></div>
      ${isLead ? `<div class="nx-form-row"><div class="nx-form-group"><label class="nx-form-label">Etapa Lead</label><select class="nx-select" id="mf_lead_stage"><option value="new" ${r.lead_stage==='new'?'selected':''}>Nuevo</option><option value="contacted" ${r.lead_stage==='contacted'?'selected':''}>Contactado</option><option value="qualified" ${r.lead_stage==='qualified'?'selected':''}>Calificado</option><option value="proposal" ${r.lead_stage==='proposal'?'selected':''}>Propuesta</option><option value="won" ${r.lead_stage==='won'?'selected':''}>Ganado</option><option value="lost" ${r.lead_stage==='lost'?'selected':''}>Perdido</option></select></div>
      <div class="nx-form-group"><label class="nx-form-label">Valor Estimado</label><input class="nx-input" id="mf_lead_value" type="number" value="${r.lead_value||0}"></div></div>` : ''}
      <div class="nx-form-group"><label class="nx-form-label">Notas</label><textarea class="nx-textarea" id="mf_notes" rows="2">${r.notes||''}</textarea></div>
    `, async () => {
      await this.api('contact_save', { id: id||'', type: r.type, name: document.getElementById('mf_name').value, rfc: document.getElementById('mf_rfc').value, email: document.getElementById('mf_email').value, phone: document.getElementById('mf_phone').value, address: document.getElementById('mf_address').value, city: document.getElementById('mf_city').value, state: document.getElementById('mf_state').value, zip: document.getElementById('mf_zip').value, credit_limit: document.getElementById('mf_credit').value, status: document.getElementById('mf_status').value, notes: document.getElementById('mf_notes').value, lead_stage: document.getElementById('mf_lead_stage')?.value||'', lead_value: document.getElementById('mf_lead_value')?.value||0 });
      this.toast('Contacto guardado', 'success');
      this.closeModal();
      this.pageContacts(document.getElementById('nxContent'));
    });
  },

  async deleteContact(id) {
    if (!confirm('Eliminar este contacto?')) return;
    await this.api('contact_delete', { id });
    this.toast('Contacto eliminado', 'success');
    this.pageContacts(document.getElementById('nxContent'));
  },

  /* ════════════════════════════════════════════════
     PAGE: PRODUCTS
     ════════════════════════════════════════════════ */
  async pageProducts(c) {
    const [data, cats] = await Promise.all([this.api('products_list'), this.api('categories_list')]);
    c.innerHTML = `<div class="nx-page">
      <div class="nx-toolbar">
        <div class="nx-toolbar-search"><i class="fas fa-search"></i><input placeholder="Buscar producto..." onkeyup="if(event.key==='Enter')NX.searchProducts(this.value)"></div>
        <button class="nx-btn nx-btn-primary" style="margin-left:auto" onclick="NX.editProduct()"><i class="fas fa-plus"></i> Nuevo Producto</button>
      </div>
      <div class="nx-card"><div class="nx-table-wrap"><table class="nx-table"><thead><tr><th>SKU</th><th>Nombre</th><th>Categoria</th><th>Costo</th><th>Precio</th><th>Stock</th><th>Estado</th><th></th></tr></thead>
      <tbody>${data.rows.map(r => {
        const low = r.min_stock > 0 && Number(r.stock_qty) <= Number(r.min_stock);
        return `<tr>
        <td><code style="font-size:11px;background:#f1f5f9;padding:2px 6px;border-radius:4px">${r.sku||'—'}</code></td>
        <td><strong>${r.name}</strong></td>
        <td>${r.category_name ? `<span style="display:inline-flex;align-items:center;gap:4px;font-size:12px"><span style="width:8px;height:8px;border-radius:50%;background:${r.category_color||'#94a3b8'}"></span>${r.category_name}</span>` : '—'}</td>
        <td class="text-right">${this.money(r.cost)}</td>
        <td class="text-right">${this.money(r.price)}</td>
        <td class="text-right ${low?'text-danger fw-bold':''}">${this.num(r.stock_qty)} ${r.unit||''} ${low?'<i class="fas fa-exclamation-triangle"></i>':''}</td>
        <td>${this.badge(r.status)}</td>
        <td class="text-right"><button class="nx-btn nx-btn-ghost nx-btn-sm" onclick="NX.editProduct(${r.id})"><i class="fas fa-pen"></i></button></td>
      </tr>`;}).join('')||'<tr><td colspan="8" class="text-center text-muted" style="padding:32px">Sin productos</td></tr>'}</tbody></table></div></div>
    </div>`;
    this._cats = cats;
  },

  async searchProducts(q) {
    const data = await this.api('products_list', { search: q });
    const tbody = document.querySelector('.nx-table tbody');
    if (tbody) tbody.innerHTML = data.rows.map(r => `<tr><td><code style="font-size:11px;background:#f1f5f9;padding:2px 6px;border-radius:4px">${r.sku||'—'}</code></td><td><strong>${r.name}</strong></td><td>${r.category_name||'—'}</td><td class="text-right">${this.money(r.cost)}</td><td class="text-right">${this.money(r.price)}</td><td class="text-right">${this.num(r.stock_qty)}</td><td>${this.badge(r.status)}</td><td class="text-right"><button class="nx-btn nx-btn-ghost nx-btn-sm" onclick="NX.editProduct(${r.id})"><i class="fas fa-pen"></i></button></td></tr>`).join('') || '<tr><td colspan="8" class="text-center text-muted">Sin resultados</td></tr>';
  },

  async editProduct(id) {
    let r = { sku:'',name:'',description:'',category_id:0,type:'product',unit:'PZA',cost:0,price:0,tax_rate:16,min_stock:0,max_stock:0,status:'active' };
    if (id) r = await this.api('product_get', { id });
    const cats = this._cats || await this.api('categories_list');
    const catOpts = cats.map(c => `<option value="${c.id}" ${c.id==r.category_id?'selected':''}>${c.name}</option>`).join('');
    this.openModal('Producto', `
      <div class="nx-form-row"><div class="nx-form-group"><label class="nx-form-label">Nombre *</label><input class="nx-input" id="mf_name" value="${r.name}"></div>
      <div class="nx-form-group"><label class="nx-form-label">SKU</label><input class="nx-input" id="mf_sku" value="${r.sku||''}"></div></div>
      <div class="nx-form-row"><div class="nx-form-group"><label class="nx-form-label">Tipo</label><select class="nx-select" id="mf_type"><option value="product" ${r.type==='product'?'selected':''}>Producto</option><option value="service" ${r.type==='service'?'selected':''}>Servicio</option></select></div>
      <div class="nx-form-group"><label class="nx-form-label">Categoria</label><select class="nx-select" id="mf_cat"><option value="0">Sin categoria</option>${catOpts}</select></div></div>
      <div class="nx-form-row-3"><div class="nx-form-group"><label class="nx-form-label">Unidad</label><input class="nx-input" id="mf_unit" value="${r.unit||'PZA'}"></div>
      <div class="nx-form-group"><label class="nx-form-label">Costo</label><input class="nx-input" id="mf_cost" type="number" step="0.01" value="${r.cost||0}"></div>
      <div class="nx-form-group"><label class="nx-form-label">Precio Venta</label><input class="nx-input" id="mf_price" type="number" step="0.01" value="${r.price||0}"></div></div>
      <div class="nx-form-row-3"><div class="nx-form-group"><label class="nx-form-label">IVA %</label><input class="nx-input" id="mf_tax" type="number" value="${r.tax_rate||16}"></div>
      <div class="nx-form-group"><label class="nx-form-label">Stock Min</label><input class="nx-input" id="mf_min" type="number" value="${r.min_stock||0}"></div>
      <div class="nx-form-group"><label class="nx-form-label">Stock Max</label><input class="nx-input" id="mf_max" type="number" value="${r.max_stock||0}"></div></div>
      <div class="nx-form-group"><label class="nx-form-label">Descripcion</label><textarea class="nx-textarea" id="mf_desc" rows="2">${r.description||''}</textarea></div>
    `, async () => {
      await this.api('product_save', { id:id||'', name:document.getElementById('mf_name').value, sku:document.getElementById('mf_sku').value, type:document.getElementById('mf_type').value, category_id:document.getElementById('mf_cat').value, unit:document.getElementById('mf_unit').value, cost:document.getElementById('mf_cost').value, price:document.getElementById('mf_price').value, tax_rate:document.getElementById('mf_tax').value, min_stock:document.getElementById('mf_min').value, max_stock:document.getElementById('mf_max').value, description:document.getElementById('mf_desc').value });
      this.toast('Producto guardado', 'success');
      this.closeModal();
      this.pageProducts(document.getElementById('nxContent'));
    });
  },

  /* ════════════════════════════════════════════════
     PAGE: INVENTORY
     ════════════════════════════════════════════════ */
  async pageInventory(c) {
    const data = await this.api('report_inventory');
    const total_val = data.reduce((s,r) => s + Number(r.stock_value||0), 0);
    c.innerHTML = `<div class="nx-page">
      <div class="nx-kpi-grid" style="margin-bottom:20px">
        <div class="nx-kpi"><div class="nx-kpi-icon indigo"><i class="fas fa-boxes-stacked"></i></div><div class="nx-kpi-info"><div class="nx-kpi-label">Productos en Inventario</div><div class="nx-kpi-value">${data.length}</div></div></div>
        <div class="nx-kpi"><div class="nx-kpi-icon green"><i class="fas fa-dollar-sign"></i></div><div class="nx-kpi-info"><div class="nx-kpi-label">Valor Total</div><div class="nx-kpi-value">${this.money(total_val)}</div></div></div>
        <div class="nx-kpi"><div class="nx-kpi-icon red"><i class="fas fa-triangle-exclamation"></i></div><div class="nx-kpi-info"><div class="nx-kpi-label">Bajo Stock</div><div class="nx-kpi-value">${data.filter(r=>r.min_stock>0 && Number(r.stock_qty)<=Number(r.min_stock)).length}</div></div></div>
      </div>
      <div class="nx-card"><div class="nx-card-header"><div class="nx-card-title">Niveles de Stock</div><button class="nx-btn nx-btn-secondary nx-btn-sm" onclick="NX.showStockModal()"><i class="fas fa-plus"></i> Movimiento</button></div>
      <div class="nx-table-wrap"><table class="nx-table"><thead><tr><th>SKU</th><th>Producto</th><th>Categoria</th><th>Stock</th><th>Minimo</th><th>Costo Unit.</th><th>Valor Stock</th><th>Estado</th></tr></thead>
      <tbody>${data.map(r => {
        const low = r.min_stock > 0 && Number(r.stock_qty) <= Number(r.min_stock);
        return `<tr><td><code>${r.sku||'—'}</code></td><td>${r.name}</td><td>${r.category_name||'—'}</td><td class="text-right ${low?'text-danger fw-bold':''}">${this.num(r.stock_qty)} ${r.unit||''}</td><td class="text-right">${r.min_stock||'—'}</td><td class="text-right">${this.money(r.cost)}</td><td class="text-right">${this.money(r.stock_value)}</td><td>${low?'<span class="nx-badge nx-badge-overdue">Bajo</span>':'<span class="nx-badge nx-badge-active">OK</span>'}</td></tr>`;
      }).join('')}</tbody></table></div></div></div>`;
  },

  async showStockModal() {
    this.openModal('Movimiento de Inventario', `
      <div class="nx-form-group"><label class="nx-form-label">Buscar Producto</label><input class="nx-input" id="mf_prod_search" placeholder="Escribe para buscar..." oninput="NX.searchProductsForStock(this.value)"><div id="mf_prod_results" style="margin-top:4px"></div><input type="hidden" id="mf_prod_id"></div>
      <div class="nx-form-row"><div class="nx-form-group"><label class="nx-form-label">Tipo</label><select class="nx-select" id="mf_move_type"><option value="in">Entrada</option><option value="out">Salida</option><option value="adjust">Ajuste</option></select></div>
      <div class="nx-form-group"><label class="nx-form-label">Cantidad</label><input class="nx-input" id="mf_qty" type="number" min="1" value="1"></div></div>
      <div class="nx-form-group"><label class="nx-form-label">Notas</label><input class="nx-input" id="mf_notes" placeholder="Referencia o motivo"></div>
    `, async () => {
      const pid = document.getElementById('mf_prod_id').value;
      if (!pid) { this.toast('Selecciona un producto', 'warning'); return; }
      await this.api('stock_adjust', { product_id: pid, quantity: document.getElementById('mf_qty').value, move_type: document.getElementById('mf_move_type').value, notes: document.getElementById('mf_notes').value });
      this.toast('Stock actualizado', 'success');
      this.closeModal();
      this.pageInventory(document.getElementById('nxContent'));
    });
  },

  async searchProductsForStock(q) {
    if (q.length < 2) { document.getElementById('mf_prod_results').innerHTML = ''; return; }
    const rows = await this.api('products_search', { q });
    document.getElementById('mf_prod_results').innerHTML = rows.map(r => `<div class="nx-cmd-item" onclick="document.getElementById('mf_prod_id').value='${r.id}';document.getElementById('mf_prod_search').value='${r.name}';document.getElementById('mf_prod_results').innerHTML=''"><i class="fas fa-box"></i><span>${r.sku?r.sku+' — ':''}${r.name}</span></div>`).join('');
  },

  /* ════════════════════════════════════════════════
     PAGE: DOCUMENTS (shared for quotes/orders/invoices/POs)
     ════════════════════════════════════════════════ */
  async pageDocuments(c, type, title) {
    const data = await this.api('documents_list', { type });
    const canConvert = { quote:'order', order:'invoice' };
    c.innerHTML = `<div class="nx-page">
      <div class="nx-toolbar">
        <div class="nx-toolbar-search"><i class="fas fa-search"></i><input placeholder="Buscar..." onkeyup="if(event.key==='Enter')NX.searchDocs('${type}',this.value)"></div>
        <button class="nx-btn nx-btn-primary" style="margin-left:auto" onclick="NX.editDocument(null,'${type}')"><i class="fas fa-plus"></i> Nuevo</button>
      </div>
      <div class="nx-card"><div class="nx-table-wrap"><table class="nx-table"><thead><tr><th>Folio</th><th>Contacto</th><th>Fecha</th><th>Vence</th><th>Total</th><th>Estado</th><th></th></tr></thead>
      <tbody>${data.rows.map(r => `<tr>
        <td><strong>${r.doc_number}</strong></td><td>${r.contact_name||'—'}</td>
        <td>${this.date(r.date_issued)}</td><td>${this.date(r.date_due)}</td>
        <td class="text-right fw-bold">${this.money(r.total)}</td><td>${this.badge(r.status)}</td>
        <td class="text-right" style="white-space:nowrap">
          <button class="nx-btn nx-btn-ghost nx-btn-xs" onclick="NX.editDocument(${r.id},'${type}')"><i class="fas fa-pen"></i></button>
          ${canConvert[type] && r.status!=='cancelled' ? `<button class="nx-btn nx-btn-xs nx-btn-secondary" onclick="NX.convertDoc(${r.id},'${canConvert[type]}')"><i class="fas fa-arrow-right"></i> Convertir</button>` : ''}
          ${r.status==='draft'||r.status==='sent' ? `<button class="nx-btn nx-btn-xs nx-btn-success" onclick="NX.changeDocStatus(${r.id},'${type==='purchase_order'?'received':'paid'}','${type}')"><i class="fas fa-check"></i></button>` : ''}
          <button class="nx-btn nx-btn-ghost nx-btn-xs text-danger" onclick="NX.deleteDoc(${r.id},'${type}')"><i class="fas fa-trash"></i></button>
        </td>
      </tr>`).join('')||`<tr><td colspan="7" class="text-center text-muted" style="padding:32px">Sin ${title.toLowerCase()}</td></tr>`}</tbody></table></div></div></div>`;
  },

  async searchDocs(type, q) {
    const data = await this.api('documents_list', { type, search: q });
    const tbody = document.querySelector('.nx-table tbody');
    if (tbody) tbody.innerHTML = data.rows.map(r => `<tr><td><strong>${r.doc_number}</strong></td><td>${r.contact_name||'—'}</td><td>${this.date(r.date_issued)}</td><td>${this.date(r.date_due)}</td><td class="text-right fw-bold">${this.money(r.total)}</td><td>${this.badge(r.status)}</td><td></td></tr>`).join('') || '<tr><td colspan="7" class="text-center text-muted">Sin resultados</td></tr>';
  },

  docItems: [],
  async editDocument(id, type) {
    let doc = { type, doc_number:'', contact_id:0, contact_name:'', date_issued:new Date().toISOString().split('T')[0], date_due:'', status:'draft', notes:'', terms:'', discount:0 };
    let items = [];
    if (id) { const r = await this.api('document_get', { id }); doc = r.doc; items = r.items; }
    this.docItems = items.length ? items : [{ product_id:0, description:'', quantity:1, unit:'PZA', unit_price:0, tax_rate:16, discount_pct:0 }];

    const isSale = ['quote','order','invoice','credit_note'].includes(type);
    const contactType = isSale ? 'client' : 'supplier';

    this.openModal(id ? `Editar ${doc.doc_number}` : 'Nuevo Documento', `
      <div class="nx-form-row"><div class="nx-form-group"><label class="nx-form-label">Contacto</label><input class="nx-input" id="mf_contact_search" placeholder="Buscar ${contactType}..." value="${doc.contact_name||''}" oninput="NX.searchContactForDoc(this.value,'${contactType}')"><div id="mf_contact_results"></div><input type="hidden" id="mf_contact_id" value="${doc.contact_id||0}"></div>
      <div class="nx-form-group"><label class="nx-form-label">Estado</label><select class="nx-select" id="mf_status"><option value="draft" ${doc.status==='draft'?'selected':''}>Borrador</option><option value="sent" ${doc.status==='sent'?'selected':''}>Enviado</option><option value="approved" ${doc.status==='approved'?'selected':''}>Aprobado</option><option value="paid" ${doc.status==='paid'?'selected':''}>Pagado</option><option value="cancelled" ${doc.status==='cancelled'?'selected':''}>Cancelado</option></select></div></div>
      <div class="nx-form-row"><div class="nx-form-group"><label class="nx-form-label">Fecha</label><input class="nx-input" id="mf_date" type="date" value="${doc.date_issued}"></div>
      <div class="nx-form-group"><label class="nx-form-label">Vencimiento</label><input class="nx-input" id="mf_due" type="date" value="${doc.date_due||''}"></div></div>
      <div class="nx-form-group"><label class="nx-form-label">Partidas</label>
        <div id="mf_items_container"></div>
        <button class="nx-btn nx-btn-secondary nx-btn-sm mt-1" onclick="NX.addDocItem()"><i class="fas fa-plus"></i> Agregar Linea</button>
      </div>
      <div id="mf_totals" class="nx-items-total"></div>
      <div class="nx-form-group"><label class="nx-form-label">Notas</label><textarea class="nx-textarea" id="mf_notes" rows="2">${doc.notes||''}</textarea></div>
    `, async () => {
      await this.api('document_save', { id:id||'', type, contact_id:document.getElementById('mf_contact_id').value, contact_name:document.getElementById('mf_contact_search').value, date_issued:document.getElementById('mf_date').value, date_due:document.getElementById('mf_due').value, status:document.getElementById('mf_status').value, notes:document.getElementById('mf_notes').value, discount:0, items:this.docItems });
      this.toast('Documento guardado', 'success');
      this.closeModal();
      this.renderPage(this.currentPage);
    }, 'nx-modal-lg');
    this.renderDocItems();
  },

  renderDocItems() {
    const ct = document.getElementById('mf_items_container');
    if (!ct) return;
    ct.innerHTML = `<table class="nx-items-table"><thead><tr><th style="width:30%">Descripcion</th><th>Cant</th><th>Unidad</th><th>P. Unit.</th><th>IVA%</th><th>Dto%</th><th>Total</th><th></th></tr></thead>
    <tbody>${this.docItems.map((it,i) => `<tr>
      <td><input value="${it.description||''}" onchange="NX.docItems[${i}].description=this.value" placeholder="Buscar producto..."></td>
      <td style="width:70px"><input type="number" value="${it.quantity}" min="0.01" step="0.01" onchange="NX.docItems[${i}].quantity=parseFloat(this.value);NX.calcDocTotals()"></td>
      <td style="width:60px"><input value="${it.unit||'PZA'}" onchange="NX.docItems[${i}].unit=this.value"></td>
      <td style="width:90px"><input type="number" value="${it.unit_price||0}" step="0.01" onchange="NX.docItems[${i}].unit_price=parseFloat(this.value);NX.calcDocTotals()"></td>
      <td style="width:60px"><input type="number" value="${it.tax_rate||16}" onchange="NX.docItems[${i}].tax_rate=parseFloat(this.value);NX.calcDocTotals()"></td>
      <td style="width:60px"><input type="number" value="${it.discount_pct||0}" onchange="NX.docItems[${i}].discount_pct=parseFloat(this.value);NX.calcDocTotals()"></td>
      <td class="text-right fw-bold">${this.money((it.quantity||1)*(it.unit_price||0)*(1-(it.discount_pct||0)/100)*(1+(it.tax_rate||16)/100))}</td>
      <td><button class="nx-btn nx-btn-ghost nx-btn-xs text-danger" onclick="NX.removeDocItem(${i})"><i class="fas fa-times"></i></button></td>
    </tr>`).join('')}</tbody></table>`;
    this.calcDocTotals();
  },

  addDocItem() { this.docItems.push({ product_id:0, description:'', quantity:1, unit:'PZA', unit_price:0, tax_rate:16, discount_pct:0 }); this.renderDocItems(); },
  removeDocItem(i) { this.docItems.splice(i,1); this.renderDocItems(); },
  calcDocTotals() {
    let sub=0, tax=0;
    this.docItems.forEach(it => { const s=(it.quantity||1)*(it.unit_price||0)*(1-(it.discount_pct||0)/100); sub+=s; tax+=s*(it.tax_rate||16)/100; });
    const el = document.getElementById('mf_totals');
    if (el) el.innerHTML = `<div class="nx-items-total-row">Subtotal: <strong>${this.money(sub)}</strong></div><div class="nx-items-total-row">IVA: <strong>${this.money(tax)}</strong></div><div class="nx-items-total-row grand">Total: <strong>${this.money(sub+tax)}</strong></div>`;
  },

  async searchContactForDoc(q, type) {
    if (q.length<2){document.getElementById('mf_contact_results').innerHTML='';return;}
    const rows = await this.api('contacts_search', { q, type });
    document.getElementById('mf_contact_results').innerHTML = rows.map(r => `<div class="nx-cmd-item" onclick="document.getElementById('mf_contact_id').value='${r.id}';document.getElementById('mf_contact_search').value='${r.name}';document.getElementById('mf_contact_results').innerHTML=''"><i class="fas fa-user"></i><span>${r.name}</span><span class="nx-cmd-item-type">${r.rfc||''}</span></div>`).join('');
  },

  async convertDoc(id, toType) {
    if (!confirm('Convertir este documento?')) return;
    const r = await this.api('document_convert', { id, to_type: toType });
    this.toast(`Convertido a ${r.doc_number}`, 'success');
    this.renderPage(this.currentPage);
  },

  async changeDocStatus(id, status, type) {
    await this.api('document_status', { id, status });
    this.toast('Estado actualizado', 'success');
    this.renderPage(this.currentPage);
  },

  async deleteDoc(id, type) {
    if (!confirm('Eliminar documento?')) return;
    await this.api('document_delete', { id });
    this.toast('Documento eliminado', 'success');
    this.renderPage(this.currentPage);
  },

  /* ════════════════════════════════════════════════
     PAGE: BANKS
     ════════════════════════════════════════════════ */
  async pageBanks(c) {
    const banks = await this.api('banks_list');
    const total = banks.reduce((s,b) => s + Number(b.balance), 0);
    c.innerHTML = `<div class="nx-page">
      <div class="nx-kpi-grid" style="margin-bottom:20px">
        <div class="nx-kpi"><div class="nx-kpi-icon green"><i class="fas fa-building-columns"></i></div><div class="nx-kpi-info"><div class="nx-kpi-label">Saldo Total</div><div class="nx-kpi-value">${this.money(total)}</div></div></div>
        <div class="nx-kpi"><div class="nx-kpi-icon indigo"><i class="fas fa-credit-card"></i></div><div class="nx-kpi-info"><div class="nx-kpi-label">Cuentas Activas</div><div class="nx-kpi-value">${banks.length}</div></div></div>
      </div>
      <div class="nx-toolbar"><button class="nx-btn nx-btn-primary" style="margin-left:auto" onclick="NX.editBank()"><i class="fas fa-plus"></i> Nueva Cuenta</button></div>
      <div class="nx-card"><div class="nx-table-wrap"><table class="nx-table"><thead><tr><th>Cuenta</th><th>Banco</th><th>No. Cuenta</th><th>CLABE</th><th>Moneda</th><th>Saldo</th><th></th></tr></thead>
      <tbody>${banks.map(b => `<tr><td><strong>${b.name}</strong></td><td>${b.bank_name||'—'}</td><td>${b.account_num||'—'}</td><td>${b.clabe||'—'}</td><td>${b.currency}</td><td class="text-right fw-bold">${this.money(b.balance)}</td><td class="text-right"><button class="nx-btn nx-btn-ghost nx-btn-sm" onclick="NX.viewBankTxns(${b.id},'${b.name}')"><i class="fas fa-list"></i></button> <button class="nx-btn nx-btn-ghost nx-btn-sm" onclick="NX.addBankTxn(${b.id})"><i class="fas fa-plus"></i></button> <button class="nx-btn nx-btn-ghost nx-btn-sm" onclick="NX.editBank(${b.id})"><i class="fas fa-pen"></i></button></td></tr>`).join('')||'<tr><td colspan="7" class="text-center text-muted" style="padding:32px">Sin cuentas bancarias</td></tr>'}</tbody></table></div></div></div>`;
  },

  async editBank(id) {
    let r = { name:'',bank_name:'',account_num:'',clabe:'',currency:'MXN',balance:0 };
    if (id) { const banks = await this.api('banks_list'); r = banks.find(b=>b.id==id)||r; }
    this.openModal('Cuenta Bancaria', `
      <div class="nx-form-row"><div class="nx-form-group"><label class="nx-form-label">Nombre Cuenta *</label><input class="nx-input" id="mf_name" value="${r.name}"></div>
      <div class="nx-form-group"><label class="nx-form-label">Banco</label><input class="nx-input" id="mf_bank" value="${r.bank_name||''}"></div></div>
      <div class="nx-form-row"><div class="nx-form-group"><label class="nx-form-label">No. Cuenta</label><input class="nx-input" id="mf_acct" value="${r.account_num||''}"></div>
      <div class="nx-form-group"><label class="nx-form-label">CLABE</label><input class="nx-input" id="mf_clabe" value="${r.clabe||''}"></div></div>
      <div class="nx-form-row"><div class="nx-form-group"><label class="nx-form-label">Moneda</label><select class="nx-select" id="mf_cur"><option ${r.currency==='MXN'?'selected':''}>MXN</option><option ${r.currency==='USD'?'selected':''}>USD</option></select></div>
      <div class="nx-form-group"><label class="nx-form-label">Saldo Inicial</label><input class="nx-input" id="mf_bal" type="number" step="0.01" value="${r.balance||0}"></div></div>
    `, async () => {
      await this.api('bank_save', { id:id||'', name:document.getElementById('mf_name').value, bank_name:document.getElementById('mf_bank').value, account_num:document.getElementById('mf_acct').value, clabe:document.getElementById('mf_clabe').value, currency:document.getElementById('mf_cur').value, balance:document.getElementById('mf_bal').value });
      this.toast('Cuenta guardada', 'success'); this.closeModal(); this.pageBanks(document.getElementById('nxContent'));
    });
  },

  async addBankTxn(bankId) {
    this.openModal('Nuevo Movimiento', `
      <div class="nx-form-row"><div class="nx-form-group"><label class="nx-form-label">Tipo</label><select class="nx-select" id="mf_type"><option value="deposit">Deposito</option><option value="withdrawal">Retiro</option><option value="transfer">Transferencia</option><option value="fee">Comision</option></select></div>
      <div class="nx-form-group"><label class="nx-form-label">Monto</label><input class="nx-input" id="mf_amount" type="number" step="0.01"></div></div>
      <div class="nx-form-row"><div class="nx-form-group"><label class="nx-form-label">Fecha</label><input class="nx-input" id="mf_date" type="date" value="${new Date().toISOString().split('T')[0]}"></div>
      <div class="nx-form-group"><label class="nx-form-label">Referencia</label><input class="nx-input" id="mf_ref"></div></div>
      <div class="nx-form-group"><label class="nx-form-label">Descripcion</label><input class="nx-input" id="mf_desc"></div>
    `, async () => {
      await this.api('bank_txn_save', { bank_id:bankId, type:document.getElementById('mf_type').value, amount:document.getElementById('mf_amount').value, txn_date:document.getElementById('mf_date').value, reference:document.getElementById('mf_ref').value, description:document.getElementById('mf_desc').value });
      this.toast('Movimiento registrado', 'success'); this.closeModal(); this.pageBanks(document.getElementById('nxContent'));
    });
  },

  async viewBankTxns(bankId, bankName) {
    const txns = await this.api('bank_txns_list', { bank_id: bankId });
    const typeLabels = { deposit:'Deposito', withdrawal:'Retiro', transfer:'Transferencia', fee:'Comision', interest:'Interes' };
    this.openModal(`Movimientos — ${bankName}`, `
      <div class="nx-table-wrap"><table class="nx-table"><thead><tr><th>Fecha</th><th>Tipo</th><th>Monto</th><th>Saldo</th><th>Referencia</th><th>Descripcion</th></tr></thead>
      <tbody>${txns.map(t => `<tr><td>${this.date(t.txn_date)}</td><td>${typeLabels[t.type]||t.type}</td><td class="text-right ${['withdrawal','fee'].includes(t.type)?'text-danger':'text-success'} fw-bold">${['withdrawal','fee'].includes(t.type)?'-':''}${this.money(t.amount)}</td><td class="text-right">${this.money(t.balance_after)}</td><td>${t.reference||''}</td><td>${t.description||''}</td></tr>`).join('')||'<tr><td colspan="6" class="text-center text-muted">Sin movimientos</td></tr>'}</tbody></table></div>
    `, null, 'nx-modal-lg');
  },

  /* ════════════════════════════════════════════════
     PAGE: ACCOUNTING
     ════════════════════════════════════════════════ */
  acctTab: 'accounts',
  async pageAccounting(c) {
    const tab = this.acctTab;
    c.innerHTML = `<div class="nx-page">
      <div class="nx-tabs">
        <button class="nx-tab ${tab==='accounts'?'active':''}" onclick="NX.acctTab='accounts';NX.pageAccounting(document.getElementById('nxContent'))">Plan de Cuentas</button>
        <button class="nx-tab ${tab==='journal'?'active':''}" onclick="NX.acctTab='journal';NX.pageAccounting(document.getElementById('nxContent'))">Polizas</button>
        <button class="nx-tab ${tab==='trial'?'active':''}" onclick="NX.acctTab='trial';NX.pageAccounting(document.getElementById('nxContent'))">Balanza</button>
      </div>
      <div id="acctContent"></div>
    </div>`;
    const ac = document.getElementById('acctContent');
    if (tab === 'accounts') {
      const rows = await this.api('accounts_list');
      const typeLabels = { asset:'Activo', liability:'Pasivo', equity:'Capital', revenue:'Ingreso', expense:'Gasto' };
      ac.innerHTML = `<div class="nx-toolbar"><button class="nx-btn nx-btn-primary" style="margin-left:auto" onclick="NX.editAccount()"><i class="fas fa-plus"></i> Nueva Cuenta</button></div>
        <div class="nx-card"><div class="nx-table-wrap"><table class="nx-table"><thead><tr><th>Codigo</th><th>Nombre</th><th>Tipo</th><th>Saldo</th><th></th></tr></thead>
        <tbody>${rows.map(r => `<tr><td><code>${r.code}</code></td><td>${r.name}</td><td>${typeLabels[r.type]||r.type}</td><td class="text-right">${this.money(r.balance)}</td><td>${!r.is_system?`<button class="nx-btn nx-btn-ghost nx-btn-sm" onclick="NX.editAccount(${r.id})"><i class="fas fa-pen"></i></button>`:''}</td></tr>`).join('')}</tbody></table></div></div>`;
    } else if (tab === 'journal') {
      const data = await this.api('journal_list');
      ac.innerHTML = `<div class="nx-toolbar"><button class="nx-btn nx-btn-primary" style="margin-left:auto" onclick="NX.editJournal()"><i class="fas fa-plus"></i> Nueva Poliza</button></div>
        <div class="nx-card"><div class="nx-table-wrap"><table class="nx-table"><thead><tr><th>Fecha</th><th>Referencia</th><th>Descripcion</th><th>Debe</th><th>Haber</th><th>Estado</th><th></th></tr></thead>
        <tbody>${data.rows.map(r => `<tr><td>${this.date(r.entry_date)}</td><td>${r.reference}</td><td>${r.description||''}</td><td class="text-right">${this.money(r.total_debit)}</td><td class="text-right">${this.money(r.total_credit)}</td><td>${this.badge(r.status)}</td><td><button class="nx-btn nx-btn-ghost nx-btn-sm" onclick="NX.viewJournal(${r.id})"><i class="fas fa-eye"></i></button></td></tr>`).join('')||'<tr><td colspan="7" class="text-center text-muted">Sin polizas</td></tr>'}</tbody></table></div></div>`;
    } else if (tab === 'trial') {
      const rows = await this.api('trial_balance');
      let tDebit=0, tCredit=0;
      rows.forEach(r => { tDebit+=Number(r.total_debit); tCredit+=Number(r.total_credit); });
      ac.innerHTML = `<div class="nx-card"><div class="nx-card-header"><div class="nx-card-title">Balanza de Comprobacion</div></div><div class="nx-table-wrap"><table class="nx-table"><thead><tr><th>Codigo</th><th>Cuenta</th><th>Tipo</th><th>Debe</th><th>Haber</th><th>Saldo</th></tr></thead>
        <tbody>${rows.map(r => `<tr><td><code>${r.code}</code></td><td>${r.name}</td><td>${r.type}</td><td class="text-right">${this.money(r.total_debit)}</td><td class="text-right">${this.money(r.total_credit)}</td><td class="text-right fw-bold">${this.money(r.balance)}</td></tr>`).join('')}
        <tr style="font-weight:800;background:var(--bg-table-header)"><td colspan="3">TOTALES</td><td class="text-right">${this.money(tDebit)}</td><td class="text-right">${this.money(tCredit)}</td><td class="text-right">${this.money(tDebit-tCredit)}</td></tr></tbody></table></div></div>`;
    }
  },

  async editAccount(id) {
    let r = { code:'',name:'',type:'asset' };
    if (id) { const rows = await this.api('accounts_list'); r = rows.find(a=>a.id==id)||r; }
    this.openModal('Cuenta Contable', `
      <div class="nx-form-row"><div class="nx-form-group"><label class="nx-form-label">Codigo *</label><input class="nx-input" id="mf_code" value="${r.code}"></div>
      <div class="nx-form-group"><label class="nx-form-label">Nombre *</label><input class="nx-input" id="mf_name" value="${r.name}"></div></div>
      <div class="nx-form-group"><label class="nx-form-label">Tipo</label><select class="nx-select" id="mf_type"><option value="asset" ${r.type==='asset'?'selected':''}>Activo</option><option value="liability" ${r.type==='liability'?'selected':''}>Pasivo</option><option value="equity" ${r.type==='equity'?'selected':''}>Capital</option><option value="revenue" ${r.type==='revenue'?'selected':''}>Ingreso</option><option value="expense" ${r.type==='expense'?'selected':''}>Gasto</option></select></div>
    `, async () => {
      await this.api('account_save', { id:id||'', code:document.getElementById('mf_code').value, name:document.getElementById('mf_name').value, type:document.getElementById('mf_type').value });
      this.toast('Cuenta guardada', 'success'); this.closeModal(); this.pageAccounting(document.getElementById('nxContent'));
    });
  },

  journalLines: [],
  async editJournal() {
    const accounts = await this.api('accounts_list');
    this._accts = accounts;
    this.journalLines = [{ account_id:'', debit:0, credit:0, memo:'' }, { account_id:'', debit:0, credit:0, memo:'' }];
    this.openModal('Nueva Poliza', `
      <div class="nx-form-row"><div class="nx-form-group"><label class="nx-form-label">Fecha</label><input class="nx-input" id="mf_date" type="date" value="${new Date().toISOString().split('T')[0]}"></div>
      <div class="nx-form-group"><label class="nx-form-label">Referencia</label><input class="nx-input" id="mf_ref"></div></div>
      <div class="nx-form-group"><label class="nx-form-label">Descripcion</label><input class="nx-input" id="mf_desc"></div>
      <div class="nx-form-group"><label class="nx-form-label">Lineas</label><div id="mf_jlines"></div>
      <button class="nx-btn nx-btn-secondary nx-btn-sm mt-1" onclick="NX.addJournalLine()"><i class="fas fa-plus"></i> Agregar Linea</button></div>
      <div id="mf_jbalance"></div>
    `, async () => {
      await this.api('journal_save', { entry_date:document.getElementById('mf_date').value, reference:document.getElementById('mf_ref').value, description:document.getElementById('mf_desc').value, status:'posted', lines:this.journalLines });
      this.toast('Poliza registrada', 'success'); this.closeModal(); this.pageAccounting(document.getElementById('nxContent'));
    }, 'nx-modal-lg');
    this.renderJournalLines();
  },

  renderJournalLines() {
    const acctOpts = (this._accts||[]).map(a => `<option value="${a.id}">${a.code} - ${a.name}</option>`).join('');
    const ct = document.getElementById('mf_jlines');
    if (!ct) return;
    ct.innerHTML = `<table class="nx-items-table"><thead><tr><th>Cuenta</th><th>Debe</th><th>Haber</th><th>Memo</th><th></th></tr></thead>
    <tbody>${this.journalLines.map((l,i) => `<tr><td><select onchange="NX.journalLines[${i}].account_id=this.value" style="width:100%;padding:6px;border:1px solid var(--border);border-radius:6px;font-size:12px"><option value="">Seleccionar...</option>${acctOpts.replace(`value="${l.account_id}"`, `value="${l.account_id}" selected`)}</select></td>
    <td style="width:100px"><input type="number" value="${l.debit||0}" step="0.01" onchange="NX.journalLines[${i}].debit=parseFloat(this.value);NX.journalLines[${i}].credit=0;NX.renderJournalBalance()"></td>
    <td style="width:100px"><input type="number" value="${l.credit||0}" step="0.01" onchange="NX.journalLines[${i}].credit=parseFloat(this.value);NX.journalLines[${i}].debit=0;NX.renderJournalBalance()"></td>
    <td><input value="${l.memo||''}" onchange="NX.journalLines[${i}].memo=this.value"></td>
    <td><button class="nx-btn nx-btn-ghost nx-btn-xs text-danger" onclick="NX.journalLines.splice(${i},1);NX.renderJournalLines()"><i class="fas fa-times"></i></button></td></tr>`).join('')}</tbody></table>`;
    this.renderJournalBalance();
  },
  addJournalLine() { this.journalLines.push({ account_id:'', debit:0, credit:0, memo:'' }); this.renderJournalLines(); },
  renderJournalBalance() {
    let d=0, c=0; this.journalLines.forEach(l => { d+=Number(l.debit||0); c+=Number(l.credit||0); });
    const bal = document.getElementById('mf_jbalance');
    if (bal) bal.innerHTML = `<div class="nx-items-total-row">Debe: <strong>${this.money(d)}</strong> &nbsp;|&nbsp; Haber: <strong>${this.money(c)}</strong> &nbsp;|&nbsp; <span class="${Math.abs(d-c)<0.01?'text-success':'text-danger'}">${Math.abs(d-c)<0.01?'Cuadra':'Diferencia: '+this.money(Math.abs(d-c))}</span></div>`;
  },

  async viewJournal(id) {
    const r = await this.api('journal_get', { id });
    this.openModal(`Poliza — ${r.entry.reference||'S/R'}`, `
      <div class="nx-form-row mb-2"><div><strong>Fecha:</strong> ${this.date(r.entry.entry_date)}</div><div><strong>Estado:</strong> ${this.badge(r.entry.status)}</div></div>
      <div class="mb-2"><strong>Descripcion:</strong> ${r.entry.description||'—'}</div>
      <table class="nx-table"><thead><tr><th>Cuenta</th><th>Debe</th><th>Haber</th><th>Memo</th></tr></thead>
      <tbody>${r.lines.map(l => `<tr><td>${l.account_code} - ${l.account_name}</td><td class="text-right">${this.money(l.debit)}</td><td class="text-right">${this.money(l.credit)}</td><td>${l.memo||''}</td></tr>`).join('')}
      <tr style="font-weight:800"><td>TOTAL</td><td class="text-right">${this.money(r.entry.total_debit)}</td><td class="text-right">${this.money(r.entry.total_credit)}</td><td></td></tr></tbody></table>
    `, null, 'nx-modal-lg');
  },

  /* ════════════════════════════════════════════════
     PAGE: EMPLOYEES
     ════════════════════════════════════════════════ */
  async pageEmployees(c) {
    const data = await this.api('employees_list');
    c.innerHTML = `<div class="nx-page">
      <div class="nx-toolbar">
        <div class="nx-toolbar-search"><i class="fas fa-search"></i><input placeholder="Buscar empleado..." onkeyup="if(event.key==='Enter')NX.searchEmps(this.value)"></div>
        <button class="nx-btn nx-btn-primary" style="margin-left:auto" onclick="NX.editEmployee()"><i class="fas fa-plus"></i> Nuevo Empleado</button>
      </div>
      <div class="nx-card"><div class="nx-table-wrap"><table class="nx-table"><thead><tr><th>#</th><th>Nombre</th><th>Departamento</th><th>Puesto</th><th>Email</th><th>Salario</th><th>Estado</th><th></th></tr></thead>
      <tbody>${data.map(e => `<tr><td>${e.employee_num||e.id}</td><td><strong>${e.first_name} ${e.last_name||''}</strong></td><td>${e.department||'—'}</td><td>${e.position||'—'}</td><td>${e.email||'—'}</td><td class="text-right">${this.money(e.salary)}</td><td>${this.badge(e.status)}</td><td class="text-right"><button class="nx-btn nx-btn-ghost nx-btn-sm" onclick="NX.editEmployee(${e.id})"><i class="fas fa-pen"></i></button></td></tr>`).join('')||'<tr><td colspan="8" class="text-center text-muted" style="padding:32px">Sin empleados</td></tr>'}</tbody></table></div></div></div>`;
  },

  async searchEmps(q) {
    const data = await this.api('employees_list', { search: q });
    document.querySelector('.nx-table tbody').innerHTML = data.map(e => `<tr><td>${e.employee_num||e.id}</td><td><strong>${e.first_name} ${e.last_name||''}</strong></td><td>${e.department||'—'}</td><td>${e.position||'—'}</td><td>${e.email||'—'}</td><td class="text-right">${this.money(e.salary)}</td><td>${this.badge(e.status)}</td><td><button class="nx-btn nx-btn-ghost nx-btn-sm" onclick="NX.editEmployee(${e.id})"><i class="fas fa-pen"></i></button></td></tr>`).join('');
  },

  async editEmployee(id) {
    let r = { employee_num:'',first_name:'',last_name:'',rfc:'',curp:'',nss:'',email:'',phone:'',department:'',position:'',hire_date:'',birth_date:'',salary:0,salary_type:'monthly',bank_account:'',emergency_contact:'',status:'active' };
    if (id) r = await this.api('employee_get', { id });
    this.openModal('Empleado', `
      <div class="nx-form-row-3"><div class="nx-form-group"><label class="nx-form-label">No. Empleado</label><input class="nx-input" id="mf_num" value="${r.employee_num||''}"></div>
      <div class="nx-form-group"><label class="nx-form-label">Nombre *</label><input class="nx-input" id="mf_fname" value="${r.first_name}"></div>
      <div class="nx-form-group"><label class="nx-form-label">Apellido</label><input class="nx-input" id="mf_lname" value="${r.last_name||''}"></div></div>
      <div class="nx-form-row-3"><div class="nx-form-group"><label class="nx-form-label">RFC</label><input class="nx-input" id="mf_rfc" value="${r.rfc||''}"></div>
      <div class="nx-form-group"><label class="nx-form-label">CURP</label><input class="nx-input" id="mf_curp" value="${r.curp||''}"></div>
      <div class="nx-form-group"><label class="nx-form-label">NSS</label><input class="nx-input" id="mf_nss" value="${r.nss||''}"></div></div>
      <div class="nx-form-row"><div class="nx-form-group"><label class="nx-form-label">Email</label><input class="nx-input" id="mf_email" value="${r.email||''}"></div>
      <div class="nx-form-group"><label class="nx-form-label">Telefono</label><input class="nx-input" id="mf_phone" value="${r.phone||''}"></div></div>
      <div class="nx-form-row"><div class="nx-form-group"><label class="nx-form-label">Departamento</label><input class="nx-input" id="mf_dept" value="${r.department||''}"></div>
      <div class="nx-form-group"><label class="nx-form-label">Puesto</label><input class="nx-input" id="mf_pos" value="${r.position||''}"></div></div>
      <div class="nx-form-row-3"><div class="nx-form-group"><label class="nx-form-label">Fecha Ingreso</label><input class="nx-input" id="mf_hire" type="date" value="${r.hire_date||''}"></div>
      <div class="nx-form-group"><label class="nx-form-label">Salario</label><input class="nx-input" id="mf_salary" type="number" step="0.01" value="${r.salary||0}"></div>
      <div class="nx-form-group"><label class="nx-form-label">Tipo Salario</label><select class="nx-select" id="mf_stype"><option value="monthly" ${r.salary_type==='monthly'?'selected':''}>Mensual</option><option value="biweekly" ${r.salary_type==='biweekly'?'selected':''}>Quincenal</option><option value="weekly" ${r.salary_type==='weekly'?'selected':''}>Semanal</option></select></div></div>
    `, async () => {
      await this.api('employee_save', { id:id||'', employee_num:document.getElementById('mf_num').value, first_name:document.getElementById('mf_fname').value, last_name:document.getElementById('mf_lname').value, rfc:document.getElementById('mf_rfc').value, curp:document.getElementById('mf_curp').value, nss:document.getElementById('mf_nss').value, email:document.getElementById('mf_email').value, phone:document.getElementById('mf_phone').value, department:document.getElementById('mf_dept').value, position:document.getElementById('mf_pos').value, hire_date:document.getElementById('mf_hire').value, salary:document.getElementById('mf_salary').value, salary_type:document.getElementById('mf_stype').value });
      this.toast('Empleado guardado', 'success'); this.closeModal(); this.pageEmployees(document.getElementById('nxContent'));
    }, 'nx-modal-lg');
  },

  /* ════════════════════════════════════════════════
     PAGE: PAYROLL
     ════════════════════════════════════════════════ */
  async pagePayroll(c) {
    const data = await this.api('payroll_list');
    c.innerHTML = `<div class="nx-page">
      <div class="nx-toolbar"><button class="nx-btn nx-btn-primary" style="margin-left:auto" onclick="NX.calcPayroll()"><i class="fas fa-calculator"></i> Calcular Nomina</button></div>
      <div class="nx-card"><div class="nx-table-wrap"><table class="nx-table"><thead><tr><th>Periodo</th><th>Empleados</th><th>Bruto</th><th>Deducciones</th><th>Neto</th><th>Estado</th><th></th></tr></thead>
      <tbody>${data.map(p => `<tr><td>${this.date(p.period_start)} — ${this.date(p.period_end)}</td><td class="text-center">${p.employee_count}</td><td class="text-right">${this.money(p.total_gross)}</td><td class="text-right text-danger">${this.money(p.total_deductions)}</td><td class="text-right fw-bold">${this.money(p.total_net)}</td><td>${this.badge(p.status)}</td><td><button class="nx-btn nx-btn-ghost nx-btn-sm" onclick="NX.viewPayroll(${p.id})"><i class="fas fa-eye"></i></button></td></tr>`).join('')||'<tr><td colspan="7" class="text-center text-muted" style="padding:32px">Sin nominas</td></tr>'}</tbody></table></div></div></div>`;
  },

  async calcPayroll() {
    const today = new Date();
    const start = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().split('T')[0];
    const end = new Date(today.getFullYear(), today.getMonth()+1, 0).toISOString().split('T')[0];
    this.openModal('Calcular Nomina', `
      <div class="nx-form-row"><div class="nx-form-group"><label class="nx-form-label">Inicio Periodo</label><input class="nx-input" id="mf_start" type="date" value="${start}"></div>
      <div class="nx-form-group"><label class="nx-form-label">Fin Periodo</label><input class="nx-input" id="mf_end" type="date" value="${end}"></div></div>
      <p class="text-muted" style="font-size:12px;margin-top:8px">Se calculara la nomina para todos los empleados activos.</p>
    `, async () => {
      await this.api('payroll_calculate', { period_start:document.getElementById('mf_start').value, period_end:document.getElementById('mf_end').value });
      this.toast('Nomina calculada', 'success'); this.closeModal(); this.pagePayroll(document.getElementById('nxContent'));
    });
  },

  async viewPayroll(id) {
    const r = await this.api('payroll_detail', { id });
    this.openModal(`Nomina — ${this.date(r.payroll.period_start)} a ${this.date(r.payroll.period_end)}`, `
      <div class="nx-kpi-grid" style="margin-bottom:16px">
        <div class="nx-kpi"><div class="nx-kpi-icon green"><i class="fas fa-money-bill"></i></div><div class="nx-kpi-info"><div class="nx-kpi-label">Bruto</div><div class="nx-kpi-value">${this.money(r.payroll.total_gross)}</div></div></div>
        <div class="nx-kpi"><div class="nx-kpi-icon red"><i class="fas fa-minus-circle"></i></div><div class="nx-kpi-info"><div class="nx-kpi-label">Deducciones</div><div class="nx-kpi-value">${this.money(r.payroll.total_deductions)}</div></div></div>
        <div class="nx-kpi"><div class="nx-kpi-icon indigo"><i class="fas fa-hand-holding-dollar"></i></div><div class="nx-kpi-info"><div class="nx-kpi-label">Neto</div><div class="nx-kpi-value">${this.money(r.payroll.total_net)}</div></div></div>
      </div>
      <table class="nx-table"><thead><tr><th>Empleado</th><th>Depto</th><th>Bruto</th><th>ISR</th><th>IMSS</th><th>Neto</th></tr></thead>
      <tbody>${r.items.map(i => `<tr><td>${i.employee_name}</td><td>${i.department||'—'}</td><td class="text-right">${this.money(i.gross_pay)}</td><td class="text-right text-danger">${this.money(i.isr)}</td><td class="text-right text-danger">${this.money(i.imss)}</td><td class="text-right fw-bold">${this.money(i.net_pay)}</td></tr>`).join('')}</tbody></table>
    `, null, 'nx-modal-lg');
  },

  /* ════════════════════════════════════════════════
     PAGE: PROJECTS
     ════════════════════════════════════════════════ */
  async pageProjects(c) {
    const data = await this.api('projects_list');
    c.innerHTML = `<div class="nx-page">
      <div class="nx-toolbar"><button class="nx-btn nx-btn-primary" style="margin-left:auto" onclick="NX.editProject()"><i class="fas fa-plus"></i> Nuevo Proyecto</button></div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:16px">
        ${data.map(p => {
          const pct = p.task_count > 0 ? Math.round(p.done_count / p.task_count * 100) : 0;
          return `<div class="nx-card" style="cursor:pointer" onclick="NX.viewProject(${p.id},'${p.name.replace(/'/g,"\\'")}')">
            <div class="nx-card-body">
              <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px"><span style="width:10px;height:10px;border-radius:50%;background:${p.color||'#6366f1'}"></span><strong style="font-size:15px">${p.name}</strong></div>
              <p class="text-muted" style="font-size:12px;margin-bottom:12px">${p.description||'Sin descripcion'}</p>
              <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:8px"><span>${p.done_count||0}/${p.task_count||0} tareas</span><span>${pct}%</span></div>
              <div style="height:6px;background:#e2e8f0;border-radius:3px;overflow:hidden"><div style="height:100%;width:${pct}%;background:${p.color||'#6366f1'};border-radius:3px;transition:width 0.3s"></div></div>
              <div style="display:flex;justify-content:space-between;margin-top:10px;font-size:11px;color:var(--text-muted)"><span>${this.badge(p.status)}</span><span>Presupuesto: ${this.money(p.budget)}</span></div>
            </div>
          </div>`;
        }).join('')||'<div class="nx-empty" style="grid-column:1/-1"><i class="fas fa-diagram-project"></i><p>Sin proyectos</p></div>'}
      </div></div>`;
  },

  async editProject(id) {
    let r = { name:'',description:'',budget:0,start_date:'',end_date:'',status:'planning',color:'#6366f1' };
    this.openModal('Proyecto', `
      <div class="nx-form-group"><label class="nx-form-label">Nombre *</label><input class="nx-input" id="mf_name" value="${r.name}"></div>
      <div class="nx-form-group"><label class="nx-form-label">Descripcion</label><textarea class="nx-textarea" id="mf_desc" rows="2">${r.description||''}</textarea></div>
      <div class="nx-form-row-3"><div class="nx-form-group"><label class="nx-form-label">Presupuesto</label><input class="nx-input" id="mf_budget" type="number" value="${r.budget||0}"></div>
      <div class="nx-form-group"><label class="nx-form-label">Inicio</label><input class="nx-input" id="mf_start" type="date" value="${r.start_date||''}"></div>
      <div class="nx-form-group"><label class="nx-form-label">Fin</label><input class="nx-input" id="mf_end" type="date" value="${r.end_date||''}"></div></div>
      <div class="nx-form-row"><div class="nx-form-group"><label class="nx-form-label">Color</label><input class="nx-input" id="mf_color" type="color" value="${r.color||'#6366f1'}"></div>
      <div class="nx-form-group"><label class="nx-form-label">Estado</label><select class="nx-select" id="mf_status"><option value="planning">Planeacion</option><option value="active">Activo</option><option value="paused">Pausado</option><option value="completed">Completado</option></select></div></div>
    `, async () => {
      await this.api('project_save', { name:document.getElementById('mf_name').value, description:document.getElementById('mf_desc').value, budget:document.getElementById('mf_budget').value, start_date:document.getElementById('mf_start').value, end_date:document.getElementById('mf_end').value, color:document.getElementById('mf_color').value, status:document.getElementById('mf_status').value });
      this.toast('Proyecto guardado', 'success'); this.closeModal(); this.pageProjects(document.getElementById('nxContent'));
    });
  },

  async viewProject(id, name) {
    const tasks = await this.api('tasks_list', { project_id: id });
    const cols = ['backlog','todo','in_progress','review','done'];
    const colLabels = { backlog:'Backlog', todo:'Por Hacer', in_progress:'En Progreso', review:'Revision', done:'Hecho' };
    const colColors = { backlog:'#94a3b8', todo:'#6366f1', in_progress:'#f59e0b', review:'#06b6d4', done:'#10b981' };

    const content = document.getElementById('nxContent');
    content.innerHTML = `<div class="nx-page">
      <div class="nx-toolbar">
        <button class="nx-btn nx-btn-ghost" onclick="NX.navigate('projects')"><i class="fas fa-arrow-left"></i> Volver</button>
        <strong style="font-size:16px">${name}</strong>
        <button class="nx-btn nx-btn-primary" style="margin-left:auto" onclick="NX.addTask(${id})"><i class="fas fa-plus"></i> Nueva Tarea</button>
      </div>
      <div class="nx-kanban">
        ${cols.map(col => `<div class="nx-kanban-col" data-status="${col}">
          <div class="nx-kanban-col-header"><span style="width:8px;height:8px;border-radius:50%;background:${colColors[col]}"></span> ${colLabels[col]} <span class="count">${tasks.filter(t=>t.status===col).length}</span></div>
          <div class="nx-kanban-col-body" ondrop="NX.dropTask(event,'${col}')" ondragover="event.preventDefault()">
            ${tasks.filter(t=>t.status===col).map(t => `<div class="nx-kanban-card" draggable="true" ondragstart="NX.dragTask(event,${t.id})">
              <div class="nx-kanban-card-title">${t.title}</div>
              <div class="nx-kanban-card-meta">
                <span class="nx-badge nx-badge-${t.priority==='urgent'?'overdue':t.priority==='high'?'overdue':t.priority==='medium'?'partial':'draft'}">${t.priority}</span>
                ${t.due_date ? `<span><i class="fas fa-calendar"></i> ${this.date(t.due_date)}</span>` : ''}
                ${t.assigned_name ? `<span><i class="fas fa-user"></i> ${t.assigned_name}</span>` : ''}
              </div>
            </div>`).join('')}
          </div>
        </div>`).join('')}
      </div></div>`;
    this._currentProjectId = id;
  },

  dragTask(e, taskId) { e.dataTransfer.setData('taskId', taskId); },
  async dropTask(e, status) {
    e.preventDefault();
    const taskId = e.dataTransfer.getData('taskId');
    await this.api('task_move', { id: taskId, status });
    this.viewProject(this._currentProjectId, document.querySelector('.nx-toolbar strong').textContent);
  },

  async addTask(projectId) {
    this.openModal('Nueva Tarea', `
      <div class="nx-form-group"><label class="nx-form-label">Titulo *</label><input class="nx-input" id="mf_title"></div>
      <div class="nx-form-group"><label class="nx-form-label">Descripcion</label><textarea class="nx-textarea" id="mf_desc" rows="2"></textarea></div>
      <div class="nx-form-row-3"><div class="nx-form-group"><label class="nx-form-label">Prioridad</label><select class="nx-select" id="mf_prio"><option value="low">Baja</option><option value="medium" selected>Media</option><option value="high">Alta</option><option value="urgent">Urgente</option></select></div>
      <div class="nx-form-group"><label class="nx-form-label">Estado</label><select class="nx-select" id="mf_status"><option value="backlog">Backlog</option><option value="todo" selected>Por Hacer</option><option value="in_progress">En Progreso</option></select></div>
      <div class="nx-form-group"><label class="nx-form-label">Fecha Limite</label><input class="nx-input" id="mf_due" type="date"></div></div>
    `, async () => {
      await this.api('task_save', { project_id:projectId, title:document.getElementById('mf_title').value, description:document.getElementById('mf_desc').value, priority:document.getElementById('mf_prio').value, status:document.getElementById('mf_status').value, due_date:document.getElementById('mf_due').value });
      this.toast('Tarea creada', 'success'); this.closeModal();
      this.viewProject(projectId, document.querySelector('.nx-toolbar strong')?.textContent || '');
    });
  },

  /* ════════════════════════════════════════════════
     PAGE: REPORTS
     ════════════════════════════════════════════════ */
  async pageReports(c) {
    c.innerHTML = `<div class="nx-page">
      <div class="nx-tabs">
        <button class="nx-tab active" onclick="NX.loadReport('sales',this)">Ventas</button>
        <button class="nx-tab" onclick="NX.loadReport('inventory',this)">Inventario</button>
        <button class="nx-tab" onclick="NX.loadReport('financial',this)">Financiero</button>
      </div>
      <div id="reportContent"><div class="nx-loading"><div class="nx-spinner"></div></div></div>
    </div>`;
    this.loadReport('sales');
  },

  async loadReport(type, tabEl) {
    if (tabEl) { document.querySelectorAll('.nx-tab').forEach(t=>t.classList.remove('active')); tabEl.classList.add('active'); }
    const rc = document.getElementById('reportContent');
    rc.innerHTML = '<div class="nx-loading"><div class="nx-spinner"></div></div>';
    if (type === 'sales') {
      const data = await this.api('report_sales');
      rc.innerHTML = `<div class="nx-chart-grid">
        <div class="nx-chart-card"><div class="nx-chart-title">Ventas Diarias</div><canvas id="nxChartRptSales" style="height:250px"></canvas></div>
        <div class="nx-chart-card"><div class="nx-chart-title">Top Clientes</div>
          ${(data.by_client||[]).map(c => `<div class="nx-stat-row"><span>${c.contact_name||'Sin nombre'}</span><strong>${this.money(c.total)}</strong></div>`).join('')||'<p class="text-muted text-center">Sin datos</p>'}
        </div></div>`;
      if (data.daily?.length) {
        new Chart(document.getElementById('nxChartRptSales'), {
          type:'line', data:{ labels:data.daily.map(d=>d.day), datasets:[{ label:'Ventas', data:data.daily.map(d=>d.total), borderColor:'#6366f1', backgroundColor:'rgba(99,102,241,0.1)', fill:true, tension:0.3 }] },
          options:{ responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}}, scales:{y:{beginAtZero:true}} }
        });
      }
    } else if (type === 'inventory') {
      const data = await this.api('report_inventory');
      const totalVal = data.reduce((s,r)=>s+Number(r.stock_value||0),0);
      rc.innerHTML = `<div class="nx-kpi-grid mb-2"><div class="nx-kpi"><div class="nx-kpi-icon indigo"><i class="fas fa-dollar-sign"></i></div><div class="nx-kpi-info"><div class="nx-kpi-label">Valor Total Inventario</div><div class="nx-kpi-value">${this.money(totalVal)}</div></div></div></div>
      <div class="nx-card"><div class="nx-table-wrap"><table class="nx-table"><thead><tr><th>SKU</th><th>Producto</th><th>Stock</th><th>Costo</th><th>Valor</th></tr></thead>
      <tbody>${data.map(r=>`<tr><td><code>${r.sku||'—'}</code></td><td>${r.name}</td><td class="text-right">${this.num(r.stock_qty)}</td><td class="text-right">${this.money(r.cost)}</td><td class="text-right fw-bold">${this.money(r.stock_value)}</td></tr>`).join('')}</tbody></table></div></div>`;
    } else if (type === 'financial') {
      const data = await this.api('report_financial');
      rc.innerHTML = `<div class="nx-kpi-grid">
        <div class="nx-kpi"><div class="nx-kpi-icon green"><i class="fas fa-arrow-up"></i></div><div class="nx-kpi-info"><div class="nx-kpi-label">Ingresos</div><div class="nx-kpi-value">${this.money(data.revenue)}</div></div></div>
        <div class="nx-kpi"><div class="nx-kpi-icon red"><i class="fas fa-arrow-down"></i></div><div class="nx-kpi-info"><div class="nx-kpi-label">Gastos</div><div class="nx-kpi-value">${this.money(data.expenses)}</div></div></div>
        <div class="nx-kpi"><div class="nx-kpi-icon indigo"><i class="fas fa-chart-line"></i></div><div class="nx-kpi-info"><div class="nx-kpi-label">Utilidad</div><div class="nx-kpi-value ${data.profit>=0?'text-success':'text-danger'}">${this.money(data.profit)}</div></div></div>
      </div>
      <div class="nx-chart-grid">
        <div class="nx-chart-card"><div class="nx-chart-title">Balance General</div>
          <div class="nx-stat-row"><span>Activos</span><strong>${this.money(data.assets)}</strong></div>
          <div class="nx-stat-row"><span>Pasivos</span><strong class="text-danger">${this.money(data.liabilities)}</strong></div>
          <div class="nx-stat-row"><span>Capital</span><strong>${this.money(data.equity)}</strong></div>
        </div>
        <div class="nx-chart-card"><canvas id="nxChartFinancial" style="height:200px"></canvas></div>
      </div>`;
      new Chart(document.getElementById('nxChartFinancial'), {
        type:'doughnut', data:{ labels:['Ingresos','Gastos'], datasets:[{ data:[data.revenue,data.expenses], backgroundColor:['#10b981','#ef4444'] }] },
        options:{ responsive:true, maintainAspectRatio:false }
      });
    }
  },

  /* ════════════════════════════════════════════════
     PAGE: SETTINGS
     ════════════════════════════════════════════════ */
  async pageSettings(c) {
    const co = await this.api('company_get');
    c.innerHTML = `<div class="nx-page">
      <div class="nx-card"><div class="nx-card-header"><div class="nx-card-title">Datos de la Empresa</div></div><div class="nx-card-body">
        <div class="nx-form-row"><div class="nx-form-group"><label class="nx-form-label">Nombre *</label><input class="nx-input" id="sf_name" value="${co?.name||''}"></div>
        <div class="nx-form-group"><label class="nx-form-label">RFC</label><input class="nx-input" id="sf_rfc" value="${co?.rfc||''}"></div></div>
        <div class="nx-form-row"><div class="nx-form-group"><label class="nx-form-label">Email</label><input class="nx-input" id="sf_email" value="${co?.email||''}"></div>
        <div class="nx-form-group"><label class="nx-form-label">Telefono</label><input class="nx-input" id="sf_phone" value="${co?.phone||''}"></div></div>
        <div class="nx-form-group"><label class="nx-form-label">Direccion</label><textarea class="nx-textarea" id="sf_address" rows="2">${co?.address||''}</textarea></div>
        <div class="nx-form-row"><div class="nx-form-group"><label class="nx-form-label">Moneda</label><select class="nx-select" id="sf_cur"><option ${co?.currency==='MXN'?'selected':''}>MXN</option><option ${co?.currency==='USD'?'selected':''}>USD</option></select></div>
        <div class="nx-form-group"><label class="nx-form-label">IVA por defecto (%)</label><input class="nx-input" id="sf_tax" type="number" value="${co?.tax_rate||16}"></div></div>
        <div style="margin-top:16px"><button class="nx-btn nx-btn-primary" onclick="NX.saveSettings()"><i class="fas fa-save"></i> Guardar</button></div>
      </div></div></div>`;
  },

  async saveSettings() {
    await this.api('company_save', { name:document.getElementById('sf_name').value, rfc:document.getElementById('sf_rfc').value, email:document.getElementById('sf_email').value, phone:document.getElementById('sf_phone').value, address:document.getElementById('sf_address').value, currency:document.getElementById('sf_cur').value, tax_rate:document.getElementById('sf_tax').value });
    this.toast('Configuracion guardada', 'success');
  },

  /* ════════════════════════════════════════════════
     PAGE: ACTIVITY LOG
     ════════════════════════════════════════════════ */
  async pageActivity(c) {
    const data = await this.api('activity_list');
    c.innerHTML = `<div class="nx-page"><div class="nx-card"><div class="nx-card-header"><div class="nx-card-title">Registro de Actividad</div></div>
      <div class="nx-table-wrap"><table class="nx-table"><thead><tr><th>Fecha</th><th>Usuario</th><th>Accion</th><th>Modulo</th><th>Descripcion</th><th>IP</th></tr></thead>
      <tbody>${data.map(a => `<tr><td style="white-space:nowrap;font-size:11px">${a.created_at}</td><td>${a.user_name}</td><td><code>${a.action}</code></td><td>${a.module}</td><td>${a.description}</td><td style="font-size:11px;color:var(--text-muted)">${a.ip_address}</td></tr>`).join('')||'<tr><td colspan="6" class="text-center text-muted" style="padding:32px">Sin actividad</td></tr>'}</tbody></table></div></div></div>`;
  },

  /* ════════════════════════════════════════════════
     MODAL SYSTEM
     ════════════════════════════════════════════════ */
  openModal(title, bodyHtml, onSave, extraClass) {
    const existing = document.querySelector('.nx-modal-overlay');
    if (existing) existing.remove();
    const overlay = document.createElement('div');
    overlay.className = 'nx-modal-overlay';
    overlay.innerHTML = `<div class="nx-modal ${extraClass||''}">
      <div class="nx-modal-header"><div class="nx-modal-title">${title}</div><button class="nx-modal-close" onclick="NX.closeModal()">&times;</button></div>
      <div class="nx-modal-body">${bodyHtml}</div>
      ${onSave ? '<div class="nx-modal-footer"><button class="nx-btn nx-btn-secondary" onclick="NX.closeModal()">Cancelar</button><button class="nx-btn nx-btn-primary" id="nxModalSave"><i class="fas fa-save"></i> Guardar</button></div>' : '<div class="nx-modal-footer"><button class="nx-btn nx-btn-secondary" onclick="NX.closeModal()">Cerrar</button></div>'}
    </div>`;
    document.body.appendChild(overlay);
    overlay.addEventListener('click', e => { if (e.target === overlay) NX.closeModal(); });
    if (onSave) {
      document.getElementById('nxModalSave').addEventListener('click', async function() {
        this.disabled = true; this.innerHTML = '<div class="nx-spinner" style="width:16px;height:16px;border-width:2px"></div>';
        try { await onSave(); } catch(e) {} finally { this.disabled = false; this.innerHTML = '<i class="fas fa-save"></i> Guardar'; }
      });
    }
  },
  closeModal() { document.querySelector('.nx-modal-overlay')?.remove(); },

  /* ════════════════════════════════════════════════
     COMMAND PALETTE
     ════════════════════════════════════════════════ */
  openCommandPalette() {
    const overlay = document.createElement('div');
    overlay.className = 'nx-cmd-overlay';
    overlay.id = 'nxCmdPalette';
    overlay.innerHTML = `<div class="nx-cmd-box">
      <div class="nx-cmd-input-wrap"><i class="fas fa-search"></i><input class="nx-cmd-input" id="nxCmdInput" placeholder="Buscar en todo el sistema..." autofocus></div>
      <div class="nx-cmd-results" id="nxCmdResults">
        <div class="nx-cmd-item" onclick="NX.navigate('dashboard');NX.closeCmdPalette()"><i class="fas fa-th-large"></i><span>Dashboard</span></div>
        <div class="nx-cmd-item" onclick="NX.navigate('contacts');NX.closeCmdPalette()"><i class="fas fa-address-book"></i><span>Contactos</span></div>
        <div class="nx-cmd-item" onclick="NX.navigate('products');NX.closeCmdPalette()"><i class="fas fa-boxes-stacked"></i><span>Productos</span></div>
        <div class="nx-cmd-item" onclick="NX.navigate('invoices');NX.closeCmdPalette()"><i class="fas fa-file-invoice-dollar"></i><span>Facturas</span></div>
        <div class="nx-cmd-item" onclick="NX.navigate('banks');NX.closeCmdPalette()"><i class="fas fa-building-columns"></i><span>Bancos</span></div>
        <div class="nx-cmd-item" onclick="NX.navigate('projects');NX.closeCmdPalette()"><i class="fas fa-diagram-project"></i><span>Proyectos</span></div>
        <div class="nx-cmd-item" onclick="NX.navigate('reports');NX.closeCmdPalette()"><i class="fas fa-chart-pie"></i><span>Reportes</span></div>
      </div>
    </div>`;
    document.body.appendChild(overlay);
    overlay.addEventListener('click', e => { if (e.target === overlay) NX.closeCmdPalette(); });
    const input = document.getElementById('nxCmdInput');
    input.focus();
    let debounce;
    input.addEventListener('input', () => {
      clearTimeout(debounce);
      debounce = setTimeout(async () => {
        const q = input.value.trim();
        if (q.length < 2) return;
        try {
          const results = await NX.api('global_search', { q });
          const icons = { contact:'fa-user', product:'fa-box', document:'fa-file-alt' };
          document.getElementById('nxCmdResults').innerHTML = results.map(r =>
            `<div class="nx-cmd-item" onclick="NX.handleSearchResult('${r.entity}',${r.id});NX.closeCmdPalette()"><i class="fas ${icons[r.entity]||'fa-circle'}"></i><span class="nx-cmd-item-label">${r.name}</span><span class="nx-cmd-item-type">${r.type||r.entity}</span></div>`
          ).join('') || '<div class="nx-cmd-item"><span class="text-muted">Sin resultados</span></div>';
        } catch(e) {}
      }, 300);
    });
  },
  closeCmdPalette() { document.getElementById('nxCmdPalette')?.remove(); },

  handleSearchResult(entity, id) {
    if (entity === 'contact') { this.navigate('contacts'); setTimeout(()=>this.editContact(id),300); }
    else if (entity === 'product') { this.navigate('products'); setTimeout(()=>this.editProduct(id),300); }
    else if (entity === 'document') { this.navigate('invoices'); setTimeout(()=>this.editDocument(id,'invoice'),300); }
  },

  /* ─── NOTIFICATIONS ─── */
  async toggleNotifications() {
    const data = await this.api('notifications_list');
    if (!data.length) { this.toast('Sin notificaciones', 'info'); return; }
    this.openModal('Notificaciones', data.map(n => `<div class="nx-stat-row"><span><i class="fas fa-bell ${n.is_read?'text-muted':'text-accent'}"></i> ${n.title}</span><span style="font-size:11px;color:var(--text-muted)">${n.created_at}</span></div>`).join(''));
  },

  /* ─── MOBILE ─── */
  closeMobile() {
    document.getElementById('nxSidebar').classList.remove('open');
    document.getElementById('nxOverlay').classList.remove('show');
  }
};

/* ─── EVENT LISTENERS ─── */
document.addEventListener('DOMContentLoaded', () => {
  /* Nav clicks */
  document.querySelectorAll('.nx-nav-item[data-page]').forEach(item => {
    item.addEventListener('click', () => NX.navigate(item.dataset.page));
  });

  /* Mobile menu */
  document.getElementById('nxMenuBtn').addEventListener('click', () => {
    document.getElementById('nxSidebar').classList.toggle('open');
    document.getElementById('nxOverlay').classList.toggle('show');
  });
  document.getElementById('nxOverlay').addEventListener('click', () => NX.closeMobile());

  /* Command palette */
  document.getElementById('nxSearchTrigger').addEventListener('click', () => NX.openCommandPalette());
  document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') { e.preventDefault(); NX.openCommandPalette(); }
    if (e.key === 'Escape') { NX.closeCmdPalette(); NX.closeModal(); }
  });

  /* Initial load */
  NX.navigate('dashboard');
});
</script>
</body>
</html>

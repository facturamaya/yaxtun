<?php

if(!defined('ABSPATH')) exit;

/*
====================================================
ERP YAXTUN MAIN
====================================================
*/

if(!function_exists('nxerp_yaxtun_menu')){

    function nxerp_yaxtun_menu(){

        add_menu_page(

            'ERP Yaxtun',
            'ERP Yaxtun',
            'manage_options',
            'nxerp-yaxtun',
            'nxerp_yaxtun_dashboard',
            'dashicons-building',
            3

        );

    }

    add_action('admin_menu', 'nxerp_yaxtun_menu');

}

function nxerp_yaxtun_dashboard(){

    echo '

    <div class="wrap">

        <h1>ERP Yaxtun</h1>

        <p>
            ERP fiscal inteligente activo.
        </p>

    </div>

    ';

}
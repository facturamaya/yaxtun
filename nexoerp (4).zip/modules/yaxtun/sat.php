<?php

if(!defined('ABSPATH')) exit;

/*
====================================================
SAT MODULE
====================================================
*/

if(!function_exists('nxerp_yaxtun_sat_menu')){

    function nxerp_yaxtun_sat_menu(){

        add_submenu_page(

            'nxerp-yaxtun',
            'SAT',
            'SAT',
            'manage_options',
            'nxerp-yaxtun-sat',
            'nxerp_yaxtun_sat_page'

        );

    }

    add_action('admin_menu', 'nxerp_yaxtun_sat_menu');

}

function nxerp_yaxtun_sat_page(){

    echo '

    <div class="wrap">

        <h1>Motor SAT</h1>

        <form method="post" enctype="multipart/form-data">

            <table class="form-table">

                <tr>
                    <th>Archivo CER</th>
                    <td>
                        <input type="file" name="cer">
                    </td>
                </tr>

                <tr>
                    <th>Archivo KEY</th>
                    <td>
                        <input type="file" name="key">
                    </td>
                </tr>

                <tr>
                    <th>Contraseña FIEL</th>
                    <td>
                        <input type="password" name="fiel_password">
                    </td>
                </tr>

            </table>

            <p>

                <button class="button button-primary">

                    Guardar FIEL

                </button>

            </p>

        </form>

    </div>

    ';

}
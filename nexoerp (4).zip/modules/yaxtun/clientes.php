<?php

if(!defined('ABSPATH')) exit;

/*
====================================================
CLIENTES MODULE
====================================================
*/

if(!function_exists('nxerp_yaxtun_clientes_menu')){

    function nxerp_yaxtun_clientes_menu(){

        add_submenu_page(

            'nxerp-yaxtun',
            'Clientes',
            'Clientes',
            'manage_options',
            'nxerp-yaxtun-clientes',
            'nxerp_yaxtun_clientes_page'

        );

    }

    add_action('admin_menu', 'nxerp_yaxtun_clientes_menu');

}

function nxerp_yaxtun_clientes_page(){

    echo '

    <div class="wrap">

        <h1>Clientes ERP Yaxtun</h1>

        <form>

            <table class="form-table">

                <tr>
                    <th>RFC</th>
                    <td>
                        <input type="text">
                    </td>
                </tr>

                <tr>
                    <th>Razón Social</th>
                    <td>
                        <input type="text">
                    </td>
                </tr>

                <tr>
                    <th>Constancia Fiscal</th>
                    <td>
                        <input type="file">
                    </td>
                </tr>

            </table>

        </form>

    </div>

    ';

}
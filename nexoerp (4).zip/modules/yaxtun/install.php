<?php

if(!defined('ABSPATH')) exit;

/*
====================================================
ERP YAXTUN AUTO LOADER
====================================================
*/

if(!function_exists('nxerp_yaxtun_loader')){

    function nxerp_yaxtun_loader(){

        $base = NXERP_DIR . 'modules/yaxtun/';

        /*
        ====================================================
        MODULES
        ====================================================
        */

        $modules = [

            'ERP-Yaxtun.php',
            'sat.php',
            'clientes.php',
            'xml.php',
            'polizas.php',
            'finanzas.php',
            'scheduler.php'

        ];

        /*
        ====================================================
        AUTO CREATE FILES
        ====================================================
        */

        foreach($modules as $module){

            $path = $base . $module;

            if(!file_exists($path)){

                file_put_contents(

                    $path,

                    "<?php\n\nif(!defined('ABSPATH')) exit;"

                );

            }

        }

        /*
        ====================================================
        LOAD MODULES
        ====================================================
        */

        foreach($modules as $module){

            $path = $base . $module;

            if(file_exists($path)){

                require_once $path;

            }

        }

    }

    add_action('plugins_loaded', 'nxerp_yaxtun_loader');

}
<?php
/*
Plugin Name: NexoERP — Sistema Empresarial Inteligente
Plugin URI:  https://nexoerp.dev
Description: ERP integral: Dashboard, CRM, Inventario, Ventas, Compras, Contabilidad, Tesoreria, RRHH, Proyectos y Reportes.
Version:     1.0.0
Author:      NexoERP
License:     GPLv2 or later
Text Domain: nexoerp
Requires PHP: 7.4
Requires at least: 5.8
*/

if (!defined('ABSPATH')) exit;

/* ─── CONSTANTS ─── */
define('NXERP_VER',   '1.0.0');
define('NXERP_DIR',   plugin_dir_path(__FILE__));
define('NXERP_URL',   plugin_dir_url(__FILE__));
define('NXERP_BRAND', 'NexoERP');
define('NXERP_PREFIX','nxerp_');
/*

====================================================

ERP YAXTUN

====================================================

*/

require_once NXERP_DIR . 'modules/yaxtun/install.php';

/* ════════════════════════════════════════════════════
   1.  DATABASE INSTALLATION
   ════════════════════════════════════════════════════ */
function nxerp_install() {
    global $wpdb;
    $c = $wpdb->charset ? "DEFAULT CHARACTER SET {$wpdb->charset}" : '';
    $p = $wpdb->prefix . NXERP_PREFIX;

    $sqls = array(
        /* Company / Branch */
        "CREATE TABLE IF NOT EXISTS {$p}companies (
            id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            name       VARCHAR(200) NOT NULL,
            rfc        VARCHAR(20) DEFAULT '',
            address    TEXT,
            phone      VARCHAR(30) DEFAULT '',
            email      VARCHAR(120) DEFAULT '',
            logo_url   VARCHAR(500) DEFAULT '',
            currency   VARCHAR(5) DEFAULT 'MXN',
            tax_rate   DECIMAL(5,2) DEFAULT 16.00,
            is_default TINYINT(1) DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) {$c}",

        /* Contacts: clients, suppliers, leads */
        "CREATE TABLE IF NOT EXISTS {$p}contacts (
            id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            company_id   BIGINT UNSIGNED DEFAULT 1,
            type         ENUM('client','supplier','lead') DEFAULT 'client',
            name         VARCHAR(200) NOT NULL,
            rfc          VARCHAR(20) DEFAULT '',
            email        VARCHAR(120) DEFAULT '',
            phone        VARCHAR(30) DEFAULT '',
            address      TEXT,
            city         VARCHAR(100) DEFAULT '',
            state        VARCHAR(100) DEFAULT '',
            zip          VARCHAR(10) DEFAULT '',
            country      VARCHAR(60) DEFAULT 'Mexico',
            credit_limit DECIMAL(14,2) DEFAULT 0,
            balance      DECIMAL(14,2) DEFAULT 0,
            lead_stage   VARCHAR(30) DEFAULT '',
            lead_value   DECIMAL(14,2) DEFAULT 0,
            notes        TEXT,
            tags         VARCHAR(500) DEFAULT '',
            status       ENUM('active','inactive','blocked') DEFAULT 'active',
            created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at   DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_type (type),
            INDEX idx_status (status)
        ) {$c}",

        /* Product categories */
        "CREATE TABLE IF NOT EXISTS {$p}categories (
            id        BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            name      VARCHAR(150) NOT NULL,
            parent_id BIGINT UNSIGNED DEFAULT 0,
            color     VARCHAR(10) DEFAULT '#6366f1',
            icon      VARCHAR(50) DEFAULT 'box',
            sort_ord  INT DEFAULT 0
        ) {$c}",

        /* Products / Services */
        "CREATE TABLE IF NOT EXISTS {$p}products (
            id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            company_id   BIGINT UNSIGNED DEFAULT 1,
            sku          VARCHAR(50) DEFAULT '',
            barcode      VARCHAR(50) DEFAULT '',
            name         VARCHAR(250) NOT NULL,
            description  TEXT,
            category_id  BIGINT UNSIGNED DEFAULT 0,
            type         ENUM('product','service') DEFAULT 'product',
            unit         VARCHAR(20) DEFAULT 'PZA',
            cost         DECIMAL(14,4) DEFAULT 0,
            price        DECIMAL(14,4) DEFAULT 0,
            tax_rate     DECIMAL(5,2) DEFAULT 16.00,
            min_stock    INT DEFAULT 0,
            max_stock    INT DEFAULT 0,
            image_url    VARCHAR(500) DEFAULT '',
            status       ENUM('active','inactive') DEFAULT 'active',
            created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at   DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_sku (sku),
            INDEX idx_cat (category_id)
        ) {$c}",

        /* Warehouses */
        "CREATE TABLE IF NOT EXISTS {$p}warehouses (
            id        BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            name      VARCHAR(150) NOT NULL,
            location  VARCHAR(300) DEFAULT '',
            manager   VARCHAR(100) DEFAULT '',
            is_default TINYINT(1) DEFAULT 0
        ) {$c}",

        /* Stock per product per warehouse */
        "CREATE TABLE IF NOT EXISTS {$p}stock (
            id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            product_id   BIGINT UNSIGNED NOT NULL,
            warehouse_id BIGINT UNSIGNED DEFAULT 1,
            quantity     DECIMAL(14,4) DEFAULT 0,
            reserved     DECIMAL(14,4) DEFAULT 0,
            UNIQUE KEY uk_pw (product_id, warehouse_id)
        ) {$c}",

        /* Stock movements */
        "CREATE TABLE IF NOT EXISTS {$p}stock_moves (
            id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            product_id   BIGINT UNSIGNED NOT NULL,
            warehouse_id BIGINT UNSIGNED DEFAULT 1,
            type         ENUM('in','out','adjust','transfer') DEFAULT 'in',
            quantity     DECIMAL(14,4) NOT NULL,
            reference    VARCHAR(100) DEFAULT '',
            doc_id       BIGINT UNSIGNED DEFAULT 0,
            notes        VARCHAR(500) DEFAULT '',
            user_id      BIGINT UNSIGNED DEFAULT 0,
            created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_prod (product_id)
        ) {$c}",

        /* Documents: quotes, orders, invoices, purchase orders, credit notes */
        "CREATE TABLE IF NOT EXISTS {$p}documents (
            id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            company_id   BIGINT UNSIGNED DEFAULT 1,
            type         ENUM('quote','order','invoice','credit_note','purchase_order','purchase_receipt') DEFAULT 'invoice',
            doc_number   VARCHAR(30) NOT NULL,
            contact_id   BIGINT UNSIGNED DEFAULT 0,
            contact_name VARCHAR(200) DEFAULT '',
            date_issued  DATE,
            date_due     DATE,
            currency     VARCHAR(5) DEFAULT 'MXN',
            exchange_rate DECIMAL(10,4) DEFAULT 1,
            subtotal     DECIMAL(14,2) DEFAULT 0,
            tax_total    DECIMAL(14,2) DEFAULT 0,
            discount     DECIMAL(14,2) DEFAULT 0,
            total        DECIMAL(14,2) DEFAULT 0,
            amount_paid  DECIMAL(14,2) DEFAULT 0,
            status       ENUM('draft','sent','approved','paid','partial','overdue','cancelled','received') DEFAULT 'draft',
            notes        TEXT,
            terms        TEXT,
            cfdi_uuid    VARCHAR(80) DEFAULT '',
            user_id      BIGINT UNSIGNED DEFAULT 0,
            converted_from BIGINT UNSIGNED DEFAULT 0,
            created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at   DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_type (type),
            INDEX idx_contact (contact_id),
            INDEX idx_status (status)
        ) {$c}",

        /* Document line items */
        "CREATE TABLE IF NOT EXISTS {$p}doc_items (
            id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            doc_id      BIGINT UNSIGNED NOT NULL,
            product_id  BIGINT UNSIGNED DEFAULT 0,
            description VARCHAR(500) DEFAULT '',
            quantity    DECIMAL(14,4) DEFAULT 1,
            unit        VARCHAR(20) DEFAULT 'PZA',
            unit_price  DECIMAL(14,4) DEFAULT 0,
            discount_pct DECIMAL(5,2) DEFAULT 0,
            tax_rate    DECIMAL(5,2) DEFAULT 16.00,
            subtotal    DECIMAL(14,2) DEFAULT 0,
            tax_amount  DECIMAL(14,2) DEFAULT 0,
            total       DECIMAL(14,2) DEFAULT 0,
            INDEX idx_doc (doc_id)
        ) {$c}",

        /* Chart of accounts */
        "CREATE TABLE IF NOT EXISTS {$p}accounts (
            id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            code        VARCHAR(20) NOT NULL,
            name        VARCHAR(200) NOT NULL,
            type        ENUM('asset','liability','equity','revenue','expense') DEFAULT 'asset',
            parent_id   BIGINT UNSIGNED DEFAULT 0,
            balance     DECIMAL(14,2) DEFAULT 0,
            is_system   TINYINT(1) DEFAULT 0,
            status      ENUM('active','inactive') DEFAULT 'active',
            UNIQUE KEY uk_code (code)
        ) {$c}",

        /* Journal entries */
        "CREATE TABLE IF NOT EXISTS {$p}journal (
            id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            entry_date  DATE NOT NULL,
            reference   VARCHAR(100) DEFAULT '',
            description VARCHAR(500) DEFAULT '',
            doc_id      BIGINT UNSIGNED DEFAULT 0,
            total_debit DECIMAL(14,2) DEFAULT 0,
            total_credit DECIMAL(14,2) DEFAULT 0,
            status      ENUM('draft','posted','voided') DEFAULT 'draft',
            user_id     BIGINT UNSIGNED DEFAULT 0,
            created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
        ) {$c}",

        /* Journal lines */
        "CREATE TABLE IF NOT EXISTS {$p}journal_lines (
            id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            journal_id BIGINT UNSIGNED NOT NULL,
            account_id BIGINT UNSIGNED NOT NULL,
            debit      DECIMAL(14,2) DEFAULT 0,
            credit     DECIMAL(14,2) DEFAULT 0,
            memo       VARCHAR(300) DEFAULT '',
            INDEX idx_journal (journal_id),
            INDEX idx_account (account_id)
        ) {$c}",

        /* Bank accounts */
        "CREATE TABLE IF NOT EXISTS {$p}bank_accounts (
            id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            name         VARCHAR(150) NOT NULL,
            bank_name    VARCHAR(100) DEFAULT '',
            account_num  VARCHAR(30) DEFAULT '',
            clabe        VARCHAR(20) DEFAULT '',
            currency     VARCHAR(5) DEFAULT 'MXN',
            balance      DECIMAL(14,2) DEFAULT 0,
            account_id   BIGINT UNSIGNED DEFAULT 0,
            status       ENUM('active','inactive') DEFAULT 'active'
        ) {$c}",

        /* Bank transactions */
        "CREATE TABLE IF NOT EXISTS {$p}bank_txns (
            id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            bank_id      BIGINT UNSIGNED NOT NULL,
            type         ENUM('deposit','withdrawal','transfer','fee','interest') DEFAULT 'deposit',
            amount       DECIMAL(14,2) NOT NULL,
            balance_after DECIMAL(14,2) DEFAULT 0,
            reference    VARCHAR(150) DEFAULT '',
            description  VARCHAR(500) DEFAULT '',
            contact_id   BIGINT UNSIGNED DEFAULT 0,
            doc_id       BIGINT UNSIGNED DEFAULT 0,
            reconciled   TINYINT(1) DEFAULT 0,
            txn_date     DATE,
            created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_bank (bank_id)
        ) {$c}",

        /* Employees */
        "CREATE TABLE IF NOT EXISTS {$p}employees (
            id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            company_id   BIGINT UNSIGNED DEFAULT 1,
            employee_num VARCHAR(20) DEFAULT '',
            first_name   VARCHAR(100) NOT NULL,
            last_name    VARCHAR(100) DEFAULT '',
            rfc          VARCHAR(20) DEFAULT '',
            curp         VARCHAR(20) DEFAULT '',
            nss          VARCHAR(15) DEFAULT '',
            email        VARCHAR(120) DEFAULT '',
            phone        VARCHAR(30) DEFAULT '',
            department   VARCHAR(100) DEFAULT '',
            position     VARCHAR(100) DEFAULT '',
            hire_date    DATE,
            birth_date   DATE,
            salary       DECIMAL(14,2) DEFAULT 0,
            salary_type  ENUM('monthly','biweekly','weekly') DEFAULT 'monthly',
            bank_account VARCHAR(30) DEFAULT '',
            emergency_contact VARCHAR(200) DEFAULT '',
            status       ENUM('active','inactive','vacation','leave') DEFAULT 'active',
            wp_user_id   BIGINT UNSIGNED DEFAULT 0,
            created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at   DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) {$c}",

        /* Payroll */
        "CREATE TABLE IF NOT EXISTS {$p}payroll (
            id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            period_start DATE,
            period_end   DATE,
            pay_date     DATE,
            total_gross  DECIMAL(14,2) DEFAULT 0,
            total_deductions DECIMAL(14,2) DEFAULT 0,
            total_net    DECIMAL(14,2) DEFAULT 0,
            employee_count INT DEFAULT 0,
            status       ENUM('draft','calculated','approved','paid') DEFAULT 'draft',
            created_at   DATETIME DEFAULT CURRENT_TIMESTAMP
        ) {$c}",

        /* Payroll items */
        "CREATE TABLE IF NOT EXISTS {$p}payroll_items (
            id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            payroll_id  BIGINT UNSIGNED NOT NULL,
            employee_id BIGINT UNSIGNED NOT NULL,
            gross_pay   DECIMAL(14,2) DEFAULT 0,
            isr         DECIMAL(14,2) DEFAULT 0,
            imss        DECIMAL(14,2) DEFAULT 0,
            other_ded   DECIMAL(14,2) DEFAULT 0,
            net_pay     DECIMAL(14,2) DEFAULT 0,
            INDEX idx_payroll (payroll_id)
        ) {$c}",

        /* Projects */
        "CREATE TABLE IF NOT EXISTS {$p}projects (
            id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            name        VARCHAR(200) NOT NULL,
            description TEXT,
            client_id   BIGINT UNSIGNED DEFAULT 0,
            budget      DECIMAL(14,2) DEFAULT 0,
            spent       DECIMAL(14,2) DEFAULT 0,
            start_date  DATE,
            end_date    DATE,
            status      ENUM('planning','active','paused','completed','cancelled') DEFAULT 'planning',
            color       VARCHAR(10) DEFAULT '#6366f1',
            manager_id  BIGINT UNSIGNED DEFAULT 0,
            created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
        ) {$c}",

        /* Tasks */
        "CREATE TABLE IF NOT EXISTS {$p}tasks (
            id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            project_id  BIGINT UNSIGNED NOT NULL,
            title       VARCHAR(300) NOT NULL,
            description TEXT,
            assigned_to BIGINT UNSIGNED DEFAULT 0,
            priority    ENUM('low','medium','high','urgent') DEFAULT 'medium',
            status      ENUM('backlog','todo','in_progress','review','done') DEFAULT 'todo',
            due_date    DATE,
            estimated_hours DECIMAL(6,1) DEFAULT 0,
            actual_hours DECIMAL(6,1) DEFAULT 0,
            sort_order  INT DEFAULT 0,
            created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_project (project_id),
            INDEX idx_status (status)
        ) {$c}",

        /* Activity log */
        "CREATE TABLE IF NOT EXISTS {$p}activity (
            id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id     BIGINT UNSIGNED DEFAULT 0,
            user_name   VARCHAR(100) DEFAULT '',
            action      VARCHAR(50) NOT NULL,
            module      VARCHAR(50) DEFAULT '',
            entity_type VARCHAR(50) DEFAULT '',
            entity_id   BIGINT UNSIGNED DEFAULT 0,
            description VARCHAR(500) DEFAULT '',
            ip_address  VARCHAR(45) DEFAULT '',
            created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_module (module)
        ) {$c}",

        /* Notifications */
        "CREATE TABLE IF NOT EXISTS {$p}notifications (
            id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id     BIGINT UNSIGNED NOT NULL,
            title       VARCHAR(200) NOT NULL,
            message     VARCHAR(500) DEFAULT '',
            type        ENUM('info','success','warning','error') DEFAULT 'info',
            module      VARCHAR(50) DEFAULT '',
            link        VARCHAR(300) DEFAULT '',
            is_read     TINYINT(1) DEFAULT 0,
            created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_user (user_id)
        ) {$c}"
    );

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    foreach ($sqls as $sql) {
        dbDelta($sql);
    }

    /* Seed default data */
    nxerp_seed_defaults();

    update_option('nxerp_db_version', NXERP_VER);
}
register_activation_hook(__FILE__, 'nxerp_install');

/* ─── SEED DEFAULTS ─── */
function nxerp_seed_defaults() {
    global $wpdb;
    $p = $wpdb->prefix . NXERP_PREFIX;

    /* Default company */
    $has = $wpdb->get_var("SELECT COUNT(*) FROM {$p}companies");
    if (!$has) {
        $wpdb->insert("{$p}companies", array(
            'name'       => get_bloginfo('name') ?: 'Mi Empresa',
            'email'      => get_option('admin_email'),
            'currency'   => 'MXN',
            'tax_rate'   => 16.00,
            'is_default' => 1
        ));
    }

    /* Default warehouse */
    $has = $wpdb->get_var("SELECT COUNT(*) FROM {$p}warehouses");
    if (!$has) {
        $wpdb->insert("{$p}warehouses", array('name' => 'Almacen Principal', 'is_default' => 1));
    }

    /* Default chart of accounts */
    $has = $wpdb->get_var("SELECT COUNT(*) FROM {$p}accounts");
    if (!$has) {
        $accts = array(
            array('1000','Caja','asset'),
            array('1010','Bancos','asset'),
            array('1020','Cuentas por Cobrar','asset'),
            array('1030','Inventario','asset'),
            array('1040','IVA Acreditable','asset'),
            array('1100','Activos Fijos','asset'),
            array('1110','Depreciacion Acumulada','asset'),
            array('2000','Cuentas por Pagar','liability'),
            array('2010','IVA Trasladado','liability'),
            array('2020','ISR por Pagar','liability'),
            array('2030','IMSS por Pagar','liability'),
            array('2040','Prestamos por Pagar','liability'),
            array('3000','Capital Social','equity'),
            array('3010','Utilidades Retenidas','equity'),
            array('3020','Resultado del Ejercicio','equity'),
            array('4000','Ventas','revenue'),
            array('4010','Otros Ingresos','revenue'),
            array('4020','Devoluciones sobre Ventas','revenue'),
            array('5000','Costo de Ventas','expense'),
            array('5010','Sueldos y Salarios','expense'),
            array('5020','Gastos Generales','expense'),
            array('5030','Renta','expense'),
            array('5040','Servicios','expense'),
            array('5050','Depreciacion','expense'),
            array('5060','Impuestos y Derechos','expense'),
            array('5070','Gastos Financieros','expense'),
        );
        foreach ($accts as $a) {
            $wpdb->insert("{$p}accounts", array(
                'code' => $a[0], 'name' => $a[1], 'type' => $a[2], 'is_system' => 1
            ));
        }
    }

    /* Default categories */
    $has = $wpdb->get_var("SELECT COUNT(*) FROM {$p}categories");
    if (!$has) {
        $cats = array(
            array('General', '#6366f1', 'box'),
            array('Servicios', '#06b6d4', 'wrench'),
            array('Materia Prima', '#f59e0b', 'flask'),
            array('Producto Terminado', '#10b981', 'check-circle'),
        );
        foreach ($cats as $i => $c) {
            $wpdb->insert("{$p}categories", array('name'=>$c[0],'color'=>$c[1],'icon'=>$c[2],'sort_ord'=>$i));
        }
    }
}

/* ════════════════════════════════════════════════════
   2.  SHORTCODE & PAGE RENDERING
   ════════════════════════════════════════════════════ */
add_shortcode('nexoerp', 'nxerp_render_app');
function nxerp_render_app($atts) {
    if (!is_user_logged_in()) {
        return '<div style="padding:40px;text-align:center"><h2>Inicia sesion para acceder al sistema</h2><p><a href="' . esc_url(wp_login_url(get_permalink())) . '">Iniciar Sesion</a></p></div>';
    }
    ob_start();
    include NXERP_DIR . 'templates/app.php';
    return ob_get_clean();
}

/* Full-page template override */
add_filter('template_include', function($template) {
    global $post;
    if ($post && has_shortcode($post->post_content, 'nexoerp')) {
        $custom = NXERP_DIR . 'templates/app.php';
        if (file_exists($custom)) {
            /* We need to wrap it properly */
            return $custom;
        }
    }
    return $template;
});

/* Admin menu for settings */
add_action('admin_menu', function() {
    add_options_page(
        'NexoERP Configuracion',
        'NexoERP',
        'manage_options',
        'nexoerp-settings',
        'nxerp_settings_page'
    );
});

function nxerp_settings_page() {
    echo '<div class="wrap"><h1>NexoERP - Configuracion</h1>';
    echo '<p>Usa el shortcode <code>[nexoerp]</code> en cualquier pagina para mostrar el ERP.</p>';
    echo '<p>Version: ' . NXERP_VER . '</p></div>';
}

/* ════════════════════════════════════════════════════
   3.  AJAX HANDLER (unified)
   ════════════════════════════════════════════════════ */
add_action('wp_ajax_nxerp', 'nxerp_ajax_handler');
function nxerp_ajax_handler() {
    /* Verify nonce */
    if (!check_ajax_referer('nxerp_nonce', '_nonce', false)) {
        wp_send_json_error('Sesion expirada. Recarga la pagina.', 403);
    }
    if (!is_user_logged_in()) {
        wp_send_json_error('No autenticado', 401);
    }

    global $wpdb;
    $p      = $wpdb->prefix . NXERP_PREFIX;
    $action = sanitize_text_field($_POST['do'] ?? '');
    $uid    = get_current_user_id();
    $uname  = wp_get_current_user()->display_name;
    $is_admin = current_user_can('manage_options');

    /* Helper: log activity */
    $log = function($act, $mod, $desc='', $eid=0) use ($wpdb, $p, $uid, $uname) {
        $wpdb->insert("{$p}activity", array(
            'user_id'=>$uid, 'user_name'=>$uname, 'action'=>$act,
            'module'=>$mod, 'entity_id'=>$eid, 'description'=>$desc,
            'ip_address'=> sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? '')
        ));
    };

    /* Helper: sanitize array of post data */
    $d = function($key, $default='') {
        $v = $_POST[$key] ?? $default;
        return is_array($v) ? array_map('sanitize_text_field', $v) : sanitize_text_field($v);
    };

    $fn = function($key, $default=0) {
        return floatval($_POST[$key] ?? $default);
    };

    $in = function($key, $default=0) {
        return intval($_POST[$key] ?? $default);
    };

    switch ($action) {

    /* ─── DASHBOARD ─── */
    case 'dashboard_stats':
        $stats = array();

        /* Sales this month */
        $m1 = date('Y-m-01');
        $m2 = date('Y-m-t');
        $stats['sales_month'] = (float) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(total),0) FROM {$p}documents WHERE type IN ('invoice','order') AND status NOT IN ('cancelled','draft') AND date_issued BETWEEN %s AND %s", $m1, $m2
        ));

        /* Sales last month */
        $lm1 = date('Y-m-01', strtotime('-1 month'));
        $lm2 = date('Y-m-t', strtotime('-1 month'));
        $stats['sales_last_month'] = (float) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(total),0) FROM {$p}documents WHERE type IN ('invoice','order') AND status NOT IN ('cancelled','draft') AND date_issued BETWEEN %s AND %s", $lm1, $lm2
        ));

        /* Receivables */
        $stats['receivables'] = (float) $wpdb->get_var(
            "SELECT COALESCE(SUM(total - amount_paid),0) FROM {$p}documents WHERE type='invoice' AND status IN ('sent','approved','partial','overdue')"
        );

        /* Payables */
        $stats['payables'] = (float) $wpdb->get_var(
            "SELECT COALESCE(SUM(total - amount_paid),0) FROM {$p}documents WHERE type='purchase_order' AND status IN ('approved','partial','overdue')"
        );

        /* Clients count */
        $stats['clients'] = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$p}contacts WHERE type='client' AND status='active'");
        $stats['suppliers'] = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$p}contacts WHERE type='supplier' AND status='active'");
        $stats['products'] = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$p}products WHERE status='active'");
        $stats['employees'] = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$p}employees WHERE status='active'");

        /* Low stock alerts */
        $stats['low_stock'] = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$p}products pr LEFT JOIN {$p}stock s ON s.product_id=pr.id WHERE pr.status='active' AND pr.type='product' AND pr.min_stock > 0 AND COALESCE(s.quantity,0) <= pr.min_stock"
        );

        /* Overdue invoices */
        $stats['overdue_invoices'] = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$p}documents WHERE type='invoice' AND status IN ('sent','approved','partial') AND date_due < %s", date('Y-m-d')
        ));

        /* Monthly sales chart (last 6 months) */
        $chart = array();
        for ($i=5; $i>=0; $i--) {
            $ms = date('Y-m-01', strtotime("-{$i} months"));
            $me = date('Y-m-t', strtotime("-{$i} months"));
            $v = (float) $wpdb->get_var($wpdb->prepare(
                "SELECT COALESCE(SUM(total),0) FROM {$p}documents WHERE type IN ('invoice','order') AND status NOT IN ('cancelled','draft') AND date_issued BETWEEN %s AND %s", $ms, $me
            ));
            $chart[] = array('month' => date('M Y', strtotime($ms)), 'value' => $v);
        }
        $stats['sales_chart'] = $chart;

        /* Recent activity */
        $stats['recent_activity'] = $wpdb->get_results(
            "SELECT * FROM {$p}activity ORDER BY created_at DESC LIMIT 10", ARRAY_A
        );

        /* Top 5 products by sales */
        $stats['top_products'] = $wpdb->get_results(
            "SELECT di.description as name, SUM(di.quantity) as qty, SUM(di.total) as revenue
             FROM {$p}doc_items di JOIN {$p}documents d ON d.id=di.doc_id
             WHERE d.type IN ('invoice','order') AND d.status NOT IN ('cancelled','draft')
             GROUP BY di.product_id ORDER BY revenue DESC LIMIT 5", ARRAY_A
        );

        /* Bank balances */
        $stats['bank_total'] = (float) $wpdb->get_var("SELECT COALESCE(SUM(balance),0) FROM {$p}bank_accounts WHERE status='active'");

        /* Active projects */
        $stats['active_projects'] = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$p}projects WHERE status='active'");

        /* Pending tasks */
        $stats['pending_tasks'] = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$p}tasks WHERE status IN ('todo','in_progress')");

        wp_send_json_success($stats);
        break;

    /* ─── CONTACTS CRUD ─── */
    case 'contacts_list':
        $type   = $d('type', 'client');
        $search = $d('search');
        $status = $d('status', '');
        $page   = max(1, $in('page', 1));
        $per    = 25;
        $offset = ($page-1) * $per;

        $where = $wpdb->prepare("type=%s", $type);
        if ($status) $where .= $wpdb->prepare(" AND status=%s", $status);
        if ($search) $where .= $wpdb->prepare(" AND (name LIKE %s OR rfc LIKE %s OR email LIKE %s)",
            "%{$search}%", "%{$search}%", "%{$search}%");

        $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$p}contacts WHERE {$where}");
        $rows  = $wpdb->get_results("SELECT * FROM {$p}contacts WHERE {$where} ORDER BY name ASC LIMIT {$per} OFFSET {$offset}", ARRAY_A);

        wp_send_json_success(array('rows'=>$rows, 'total'=>$total, 'pages'=>ceil($total/$per)));
        break;

    case 'contact_save':
        $id   = $in('id');
        $data = array(
            'type'         => $d('type','client'),
            'name'         => $d('name'),
            'rfc'          => strtoupper($d('rfc')),
            'email'        => sanitize_email($_POST['email'] ?? ''),
            'phone'        => $d('phone'),
            'address'      => sanitize_textarea_field($_POST['address'] ?? ''),
            'city'         => $d('city'),
            'state'        => $d('state'),
            'zip'          => $d('zip'),
            'credit_limit' => $fn('credit_limit'),
            'lead_stage'   => $d('lead_stage'),
            'lead_value'   => $fn('lead_value'),
            'notes'        => sanitize_textarea_field($_POST['notes'] ?? ''),
            'tags'         => $d('tags'),
            'status'       => $d('status','active'),
        );
        if (!$data['name']) wp_send_json_error('El nombre es obligatorio');

        if ($id) {
            $wpdb->update("{$p}contacts", $data, array('id'=>$id));
            $log('update','contacts',"Contacto actualizado: {$data['name']}", $id);
        } else {
            $wpdb->insert("{$p}contacts", $data);
            $id = $wpdb->insert_id;
            $log('create','contacts',"Contacto creado: {$data['name']}", $id);
        }
        wp_send_json_success(array('id'=>$id));
        break;

    case 'contact_get':
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$p}contacts WHERE id=%d", $in('id')), ARRAY_A);
        wp_send_json_success($row);
        break;

    case 'contact_delete':
        $id = $in('id');
        $wpdb->delete("{$p}contacts", array('id'=>$id));
        $log('delete','contacts',"Contacto eliminado ID:{$id}", $id);
        wp_send_json_success(true);
        break;

    /* ─── PRODUCTS CRUD ─── */
    case 'products_list':
        $search = $d('search');
        $cat    = $in('category_id');
        $page   = max(1, $in('page', 1));
        $per    = 25;
        $offset = ($page-1) * $per;

        $where = "pr.status='active'";
        if ($search) $where .= $wpdb->prepare(" AND (pr.name LIKE %s OR pr.sku LIKE %s)", "%{$search}%", "%{$search}%");
        if ($cat) $where .= $wpdb->prepare(" AND pr.category_id=%d", $cat);

        $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$p}products pr WHERE {$where}");
        $rows  = $wpdb->get_results(
            "SELECT pr.*, COALESCE(s.quantity,0) as stock_qty, c.name as category_name, c.color as category_color
             FROM {$p}products pr
             LEFT JOIN {$p}stock s ON s.product_id=pr.id
             LEFT JOIN {$p}categories c ON c.id=pr.category_id
             WHERE {$where} ORDER BY pr.name ASC LIMIT {$per} OFFSET {$offset}", ARRAY_A
        );

        wp_send_json_success(array('rows'=>$rows, 'total'=>$total, 'pages'=>ceil($total/$per)));
        break;

    case 'product_save':
        $id = $in('id');
        $data = array(
            'sku'         => $d('sku'),
            'barcode'     => $d('barcode'),
            'name'        => $d('name'),
            'description' => sanitize_textarea_field($_POST['description'] ?? ''),
            'category_id' => $in('category_id'),
            'type'        => $d('type','product'),
            'unit'        => $d('unit','PZA'),
            'cost'        => $fn('cost'),
            'price'       => $fn('price'),
            'tax_rate'    => $fn('tax_rate', 16),
            'min_stock'   => $in('min_stock'),
            'max_stock'   => $in('max_stock'),
            'status'      => $d('status','active'),
        );
        if (!$data['name']) wp_send_json_error('El nombre es obligatorio');

        if ($id) {
            $wpdb->update("{$p}products", $data, array('id'=>$id));
            $log('update','products',"Producto actualizado: {$data['name']}", $id);
        } else {
            $wpdb->insert("{$p}products", $data);
            $id = $wpdb->insert_id;
            /* Create stock record */
            $def_wh = $wpdb->get_var("SELECT id FROM {$p}warehouses WHERE is_default=1 LIMIT 1") ?: 1;
            $wpdb->insert("{$p}stock", array('product_id'=>$id, 'warehouse_id'=>$def_wh, 'quantity'=>0));
            $log('create','products',"Producto creado: {$data['name']}", $id);
        }
        wp_send_json_success(array('id'=>$id));
        break;

    case 'product_get':
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT pr.*, COALESCE(s.quantity,0) as stock_qty FROM {$p}products pr LEFT JOIN {$p}stock s ON s.product_id=pr.id WHERE pr.id=%d", $in('id')
        ), ARRAY_A);
        wp_send_json_success($row);
        break;

    case 'product_delete':
        $id = $in('id');
        $wpdb->update("{$p}products", array('status'=>'inactive'), array('id'=>$id));
        $log('delete','products',"Producto desactivado ID:{$id}", $id);
        wp_send_json_success(true);
        break;

    /* ─── CATEGORIES ─── */
    case 'categories_list':
        $rows = $wpdb->get_results("SELECT * FROM {$p}categories ORDER BY sort_ord, name", ARRAY_A);
        wp_send_json_success($rows);
        break;

    case 'category_save':
        $id = $in('id');
        $data = array('name'=>$d('name'), 'color'=>$d('color','#6366f1'), 'icon'=>$d('icon','box'));
        if ($id) { $wpdb->update("{$p}categories", $data, array('id'=>$id)); }
        else { $wpdb->insert("{$p}categories", $data); $id=$wpdb->insert_id; }
        wp_send_json_success(array('id'=>$id));
        break;

    /* ─── STOCK MOVEMENTS ─── */
    case 'stock_adjust':
        $pid = $in('product_id');
        $qty = $fn('quantity');
        $type = $d('move_type','in');
        $notes = $d('notes');
        $wh = $in('warehouse_id') ?: ($wpdb->get_var("SELECT id FROM {$p}warehouses WHERE is_default=1") ?: 1);

        /* Update stock */
        $current = (float) $wpdb->get_var($wpdb->prepare(
            "SELECT quantity FROM {$p}stock WHERE product_id=%d AND warehouse_id=%d", $pid, $wh
        ));
        if ($current === null || $current === false) {
            $wpdb->insert("{$p}stock", array('product_id'=>$pid, 'warehouse_id'=>$wh, 'quantity'=>0));
            $current = 0;
        }

        $new_qty = ($type === 'in' || $type === 'adjust') ? $current + $qty : $current - $qty;
        if ($new_qty < 0 && $type === 'out') wp_send_json_error('Stock insuficiente');

        $wpdb->update("{$p}stock", array('quantity'=>$new_qty), array('product_id'=>$pid, 'warehouse_id'=>$wh));
        $wpdb->insert("{$p}stock_moves", array(
            'product_id'=>$pid, 'warehouse_id'=>$wh, 'type'=>$type,
            'quantity'=>$qty, 'notes'=>$notes, 'user_id'=>$uid
        ));
        $pname = $wpdb->get_var($wpdb->prepare("SELECT name FROM {$p}products WHERE id=%d", $pid));
        $log('stock_move','inventory', "{$type} {$qty} - {$pname}", $pid);
        wp_send_json_success(array('new_qty'=>$new_qty));
        break;

    case 'stock_moves_list':
        $pid = $in('product_id');
        $where = $pid ? $wpdb->prepare("sm.product_id=%d", $pid) : "1=1";
        $rows = $wpdb->get_results(
            "SELECT sm.*, pr.name as product_name FROM {$p}stock_moves sm
             LEFT JOIN {$p}products pr ON pr.id=sm.product_id
             WHERE {$where} ORDER BY sm.created_at DESC LIMIT 50", ARRAY_A
        );
        wp_send_json_success($rows);
        break;

    /* ─── DOCUMENTS (Sales & Purchases) ─── */
    case 'documents_list':
        $type   = $d('type','invoice');
        $status = $d('status');
        $search = $d('search');
        $page   = max(1, $in('page', 1));
        $per    = 25;
        $offset = ($page-1)*$per;

        $where = $wpdb->prepare("d.type=%s", $type);
        if ($status) $where .= $wpdb->prepare(" AND d.status=%s", $status);
        if ($search) $where .= $wpdb->prepare(" AND (d.doc_number LIKE %s OR d.contact_name LIKE %s)", "%{$search}%", "%{$search}%");

        $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$p}documents d WHERE {$where}");
        $rows  = $wpdb->get_results("SELECT d.* FROM {$p}documents d WHERE {$where} ORDER BY d.date_issued DESC, d.id DESC LIMIT {$per} OFFSET {$offset}", ARRAY_A);
        wp_send_json_success(array('rows'=>$rows, 'total'=>$total, 'pages'=>ceil($total/$per)));
        break;

    case 'document_save':
        $id    = $in('id');
        $items = json_decode(stripslashes($_POST['items'] ?? '[]'), true);
        if (!is_array($items)) $items = array();

        /* Calculate totals */
        $subtotal = 0; $tax_total = 0;
        foreach ($items as &$it) {
            $it['quantity']   = floatval($it['quantity'] ?? 1);
            $it['unit_price'] = floatval($it['unit_price'] ?? 0);
            $it['tax_rate']   = floatval($it['tax_rate'] ?? 16);
            $it['discount_pct'] = floatval($it['discount_pct'] ?? 0);
            $line_sub   = $it['quantity'] * $it['unit_price'] * (1 - $it['discount_pct']/100);
            $line_tax   = $line_sub * $it['tax_rate'] / 100;
            $it['subtotal']   = round($line_sub, 2);
            $it['tax_amount'] = round($line_tax, 2);
            $it['total']      = round($line_sub + $line_tax, 2);
            $subtotal += $it['subtotal'];
            $tax_total += $it['tax_amount'];
        }
        unset($it);

        $dtype = $d('type','invoice');

        /* Generate doc number */
        $doc_num = $d('doc_number');
        if (!$doc_num) {
            $prefix_map = array('quote'=>'COT','order'=>'PED','invoice'=>'FAC','credit_note'=>'NC','purchase_order'=>'OC','purchase_receipt'=>'REC');
            $prefix = $prefix_map[$dtype] ?? 'DOC';
            $last = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*)+1 FROM {$p}documents WHERE type=%s", $dtype
            ));
            $doc_num = $prefix . '-' . str_pad($last, 5, '0', STR_PAD_LEFT);
        }

        $data = array(
            'type'         => $dtype,
            'doc_number'   => $doc_num,
            'contact_id'   => $in('contact_id'),
            'contact_name' => $d('contact_name'),
            'date_issued'  => $d('date_issued') ?: date('Y-m-d'),
            'date_due'     => $d('date_due') ?: date('Y-m-d', strtotime('+30 days')),
            'subtotal'     => round($subtotal, 2),
            'tax_total'    => round($tax_total, 2),
            'discount'     => $fn('discount'),
            'total'        => round($subtotal + $tax_total - $fn('discount'), 2),
            'status'       => $d('status','draft'),
            'notes'        => sanitize_textarea_field($_POST['notes'] ?? ''),
            'terms'        => sanitize_textarea_field($_POST['terms'] ?? ''),
            'user_id'      => $uid,
        );

        if ($id) {
            $wpdb->update("{$p}documents", $data, array('id'=>$id));
            $wpdb->delete("{$p}doc_items", array('doc_id'=>$id));
        } else {
            $wpdb->insert("{$p}documents", $data);
            $id = $wpdb->insert_id;
        }

        foreach ($items as $it) {
            $wpdb->insert("{$p}doc_items", array(
                'doc_id'      => $id,
                'product_id'  => intval($it['product_id'] ?? 0),
                'description' => sanitize_text_field($it['description'] ?? ''),
                'quantity'    => $it['quantity'],
                'unit'        => sanitize_text_field($it['unit'] ?? 'PZA'),
                'unit_price'  => $it['unit_price'],
                'discount_pct'=> $it['discount_pct'],
                'tax_rate'    => $it['tax_rate'],
                'subtotal'    => $it['subtotal'],
                'tax_amount'  => $it['tax_amount'],
                'total'       => $it['total'],
            ));
        }

        $log('save','documents',"{$dtype} {$doc_num}", $id);
        wp_send_json_success(array('id'=>$id, 'doc_number'=>$doc_num));
        break;

    case 'document_get':
        $id  = $in('id');
        $doc = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$p}documents WHERE id=%d", $id), ARRAY_A);
        $items = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$p}doc_items WHERE doc_id=%d", $id), ARRAY_A);
        wp_send_json_success(array('doc'=>$doc, 'items'=>$items));
        break;

    case 'document_status':
        $id     = $in('id');
        $status = $d('status');
        $wpdb->update("{$p}documents", array('status'=>$status), array('id'=>$id));

        /* If invoice marked as paid, update stock */
        $doc = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$p}documents WHERE id=%d", $id), ARRAY_A);
        if ($status === 'paid' && in_array($doc['type'], array('invoice','order'))) {
            $items = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$p}doc_items WHERE doc_id=%d", $id), ARRAY_A);
            $wh = $wpdb->get_var("SELECT id FROM {$p}warehouses WHERE is_default=1") ?: 1;
            foreach ($items as $it) {
                if ($it['product_id']) {
                    $cur = (float)$wpdb->get_var($wpdb->prepare("SELECT quantity FROM {$p}stock WHERE product_id=%d AND warehouse_id=%d", $it['product_id'], $wh));
                    $wpdb->update("{$p}stock", array('quantity'=>$cur - $it['quantity']), array('product_id'=>$it['product_id'], 'warehouse_id'=>$wh));
                    $wpdb->insert("{$p}stock_moves", array('product_id'=>$it['product_id'],'warehouse_id'=>$wh,'type'=>'out','quantity'=>$it['quantity'],'reference'=>$doc['doc_number'],'doc_id'=>$id,'user_id'=>$uid));
                }
            }
            $wpdb->update("{$p}documents", array('amount_paid'=>$doc['total']), array('id'=>$id));
        }

        $log('status_change','documents',"{$doc['doc_number']} -> {$status}", $id);
        wp_send_json_success(true);
        break;

    case 'document_delete':
        $id = $in('id');
        $wpdb->delete("{$p}doc_items", array('doc_id'=>$id));
        $wpdb->delete("{$p}documents", array('id'=>$id));
        $log('delete','documents',"Documento eliminado ID:{$id}", $id);
        wp_send_json_success(true);
        break;

    /* Convert document (quote -> order -> invoice) */
    case 'document_convert':
        $src_id = $in('id');
        $to_type = $d('to_type');
        $src = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$p}documents WHERE id=%d", $src_id), ARRAY_A);
        if (!$src) wp_send_json_error('Documento no encontrado');

        $prefix_map = array('quote'=>'COT','order'=>'PED','invoice'=>'FAC','credit_note'=>'NC','purchase_order'=>'OC');
        $prefix = $prefix_map[$to_type] ?? 'DOC';
        $num = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*)+1 FROM {$p}documents WHERE type=%s", $to_type));
        $new_num = $prefix . '-' . str_pad($num, 5, '0', STR_PAD_LEFT);

        $new_data = $src;
        unset($new_data['id'], $new_data['created_at'], $new_data['updated_at']);
        $new_data['type'] = $to_type;
        $new_data['doc_number'] = $new_num;
        $new_data['status'] = 'draft';
        $new_data['converted_from'] = $src_id;
        $new_data['date_issued'] = date('Y-m-d');
        $new_data['user_id'] = $uid;

        $wpdb->insert("{$p}documents", $new_data);
        $new_id = $wpdb->insert_id;

        /* Copy items */
        $items = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$p}doc_items WHERE doc_id=%d", $src_id), ARRAY_A);
        foreach ($items as $it) {
            unset($it['id']);
            $it['doc_id'] = $new_id;
            $wpdb->insert("{$p}doc_items", $it);
        }

        $wpdb->update("{$p}documents", array('status'=>'approved'), array('id'=>$src_id));
        $log('convert','documents',"{$src['doc_number']} -> {$new_num}", $new_id);
        wp_send_json_success(array('id'=>$new_id, 'doc_number'=>$new_num));
        break;

    /* ─── ACCOUNTING ─── */
    case 'accounts_list':
        $rows = $wpdb->get_results("SELECT * FROM {$p}accounts WHERE status='active' ORDER BY code", ARRAY_A);
        wp_send_json_success($rows);
        break;

    case 'account_save':
        $id = $in('id');
        $data = array('code'=>$d('code'),'name'=>$d('name'),'type'=>$d('type','asset'),'parent_id'=>$in('parent_id'));
        if ($id) { $wpdb->update("{$p}accounts", $data, array('id'=>$id)); }
        else { $wpdb->insert("{$p}accounts", $data); $id=$wpdb->insert_id; }
        wp_send_json_success(array('id'=>$id));
        break;

    case 'journal_list':
        $page = max(1,$in('page',1));
        $per = 25; $offset=($page-1)*$per;
        $total = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$p}journal");
        $rows = $wpdb->get_results("SELECT * FROM {$p}journal ORDER BY entry_date DESC, id DESC LIMIT {$per} OFFSET {$offset}", ARRAY_A);
        wp_send_json_success(array('rows'=>$rows,'total'=>$total,'pages'=>ceil($total/$per)));
        break;

    case 'journal_save':
        $id    = $in('id');
        $lines = json_decode(stripslashes($_POST['lines'] ?? '[]'), true);
        $td = 0; $tc = 0;
        foreach ($lines as $l) { $td += floatval($l['debit']??0); $tc += floatval($l['credit']??0); }
        if (abs($td - $tc) > 0.01) wp_send_json_error('Debe y Haber no cuadran');

        $data = array(
            'entry_date'  => $d('entry_date') ?: date('Y-m-d'),
            'reference'   => $d('reference'),
            'description' => $d('description'),
            'total_debit' => round($td,2),
            'total_credit'=> round($tc,2),
            'status'      => $d('status','draft'),
            'user_id'     => $uid,
        );

        if ($id) {
            $wpdb->update("{$p}journal", $data, array('id'=>$id));
            $wpdb->delete("{$p}journal_lines", array('journal_id'=>$id));
        } else {
            $wpdb->insert("{$p}journal", $data);
            $id = $wpdb->insert_id;
        }

        foreach ($lines as $l) {
            $wpdb->insert("{$p}journal_lines", array(
                'journal_id'=>$id,
                'account_id'=>intval($l['account_id']??0),
                'debit'=>round(floatval($l['debit']??0),2),
                'credit'=>round(floatval($l['credit']??0),2),
                'memo'=>sanitize_text_field($l['memo']??''),
            ));
        }

        /* Update account balances if posted */
        if ($data['status'] === 'posted') {
            foreach ($lines as $l) {
                $aid = intval($l['account_id']??0);
                $acct = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$p}accounts WHERE id=%d", $aid));
                if ($acct) {
                    $delta = floatval($l['debit']??0) - floatval($l['credit']??0);
                    if (in_array($acct->type, array('liability','equity','revenue'))) $delta = -$delta;
                    $wpdb->query($wpdb->prepare("UPDATE {$p}accounts SET balance=balance+%f WHERE id=%d", $delta, $aid));
                }
            }
        }

        $log('save','accounting',"Poliza {$data['reference']}", $id);
        wp_send_json_success(array('id'=>$id));
        break;

    case 'journal_get':
        $id = $in('id');
        $entry = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$p}journal WHERE id=%d", $id), ARRAY_A);
        $lines = $wpdb->get_results($wpdb->prepare(
            "SELECT jl.*, a.code as account_code, a.name as account_name FROM {$p}journal_lines jl LEFT JOIN {$p}accounts a ON a.id=jl.account_id WHERE jl.journal_id=%d", $id
        ), ARRAY_A);
        wp_send_json_success(array('entry'=>$entry, 'lines'=>$lines));
        break;

    case 'trial_balance':
        $rows = $wpdb->get_results(
            "SELECT a.code, a.name, a.type, a.balance,
                    COALESCE(SUM(jl.debit),0) as total_debit,
                    COALESCE(SUM(jl.credit),0) as total_credit
             FROM {$p}accounts a
             LEFT JOIN {$p}journal_lines jl ON jl.account_id=a.id
             LEFT JOIN {$p}journal j ON j.id=jl.journal_id AND j.status='posted'
             WHERE a.status='active'
             GROUP BY a.id ORDER BY a.code", ARRAY_A
        );
        wp_send_json_success($rows);
        break;

    /* ─── BANK / TREASURY ─── */
    case 'banks_list':
        $rows = $wpdb->get_results("SELECT * FROM {$p}bank_accounts ORDER BY name", ARRAY_A);
        wp_send_json_success($rows);
        break;

    case 'bank_save':
        $id = $in('id');
        $data = array(
            'name'=>$d('name'), 'bank_name'=>$d('bank_name'),
            'account_num'=>$d('account_num'), 'clabe'=>$d('clabe'),
            'currency'=>$d('currency','MXN'), 'balance'=>$fn('balance'),
        );
        if ($id) { $wpdb->update("{$p}bank_accounts", $data, array('id'=>$id)); }
        else { $wpdb->insert("{$p}bank_accounts", $data); $id=$wpdb->insert_id; }
        wp_send_json_success(array('id'=>$id));
        break;

    case 'bank_txns_list':
        $bid = $in('bank_id');
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$p}bank_txns WHERE bank_id=%d ORDER BY txn_date DESC, id DESC LIMIT 100", $bid
        ), ARRAY_A);
        wp_send_json_success($rows);
        break;

    case 'bank_txn_save':
        $data = array(
            'bank_id'    => $in('bank_id'),
            'type'       => $d('type','deposit'),
            'amount'     => $fn('amount'),
            'reference'  => $d('reference'),
            'description'=> $d('description'),
            'contact_id' => $in('contact_id'),
            'txn_date'   => $d('txn_date') ?: date('Y-m-d'),
        );
        /* Update bank balance */
        $bank = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$p}bank_accounts WHERE id=%d", $data['bank_id']));
        $new_bal = $bank->balance;
        if (in_array($data['type'], array('deposit','interest'))) $new_bal += $data['amount'];
        else $new_bal -= $data['amount'];
        $data['balance_after'] = $new_bal;

        $wpdb->insert("{$p}bank_txns", $data);
        $wpdb->update("{$p}bank_accounts", array('balance'=>$new_bal), array('id'=>$data['bank_id']));
        $log('create','treasury',"Movimiento bancario: {$data['type']} \${$data['amount']}", $data['bank_id']);
        wp_send_json_success(array('balance'=>$new_bal));
        break;

    /* ─── EMPLOYEES / HR ─── */
    case 'employees_list':
        $search = $d('search');
        $where = "1=1";
        if ($search) $where .= $wpdb->prepare(" AND (first_name LIKE %s OR last_name LIKE %s OR department LIKE %s)", "%{$search}%", "%{$search}%", "%{$search}%");
        $rows = $wpdb->get_results("SELECT * FROM {$p}employees WHERE {$where} ORDER BY first_name, last_name", ARRAY_A);
        wp_send_json_success($rows);
        break;

    case 'employee_save':
        $id = $in('id');
        $data = array(
            'employee_num' => $d('employee_num'),
            'first_name'   => $d('first_name'),
            'last_name'    => $d('last_name'),
            'rfc'          => strtoupper($d('rfc')),
            'curp'         => strtoupper($d('curp')),
            'nss'          => $d('nss'),
            'email'        => sanitize_email($_POST['email']??''),
            'phone'        => $d('phone'),
            'department'   => $d('department'),
            'position'     => $d('position'),
            'hire_date'    => $d('hire_date'),
            'birth_date'   => $d('birth_date'),
            'salary'       => $fn('salary'),
            'salary_type'  => $d('salary_type','monthly'),
            'bank_account' => $d('bank_account'),
            'emergency_contact' => $d('emergency_contact'),
            'status'       => $d('status','active'),
        );
        if ($id) { $wpdb->update("{$p}employees", $data, array('id'=>$id)); }
        else { $wpdb->insert("{$p}employees", $data); $id=$wpdb->insert_id; }
        $log('save','hr',"{$data['first_name']} {$data['last_name']}", $id);
        wp_send_json_success(array('id'=>$id));
        break;

    case 'employee_get':
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$p}employees WHERE id=%d", $in('id')), ARRAY_A);
        wp_send_json_success($row);
        break;

    case 'employee_delete':
        $wpdb->update("{$p}employees", array('status'=>'inactive'), array('id'=>$in('id')));
        wp_send_json_success(true);
        break;

    /* ─── PAYROLL ─── */
    case 'payroll_calculate':
        $period_start = $d('period_start');
        $period_end   = $d('period_end');
        $emps = $wpdb->get_results("SELECT * FROM {$p}employees WHERE status='active'", ARRAY_A);

        $wpdb->insert("{$p}payroll", array(
            'period_start'=>$period_start, 'period_end'=>$period_end,
            'status'=>'calculated', 'employee_count'=>count($emps)
        ));
        $payroll_id = $wpdb->insert_id;

        $total_gross=0; $total_ded=0; $total_net=0;
        foreach ($emps as $emp) {
            $salary = floatval($emp['salary']);
            /* Calculate proportional salary based on period */
            $days = max(1, (strtotime($period_end) - strtotime($period_start)) / 86400 + 1);
            if ($emp['salary_type'] === 'monthly') $gross = $salary * ($days/30);
            elseif ($emp['salary_type'] === 'biweekly') $gross = $salary;
            else $gross = $salary * ($days/7);

            /* Simple ISR estimation (simplified brackets) */
            $monthly = $gross * (30/$days);
            if ($monthly <= 7735) $isr_rate = 0.064;
            elseif ($monthly <= 13271) $isr_rate = 0.1088;
            elseif ($monthly <= 24222) $isr_rate = 0.16;
            elseif ($monthly <= 46666) $isr_rate = 0.2136;
            else $isr_rate = 0.30;
            $isr = round($gross * $isr_rate, 2);

            /* IMSS employee contribution (approx 2.775%) */
            $imss = round($gross * 0.02775, 2);

            $net = round($gross - $isr - $imss, 2);

            $wpdb->insert("{$p}payroll_items", array(
                'payroll_id'=>$payroll_id, 'employee_id'=>$emp['id'],
                'gross_pay'=>round($gross,2), 'isr'=>$isr, 'imss'=>$imss, 'net_pay'=>$net
            ));

            $total_gross += $gross;
            $total_ded += $isr + $imss;
            $total_net += $net;
        }

        $wpdb->update("{$p}payroll", array(
            'total_gross'=>round($total_gross,2),
            'total_deductions'=>round($total_ded,2),
            'total_net'=>round($total_net,2)
        ), array('id'=>$payroll_id));

        $log('create','payroll',"Nomina calculada: {$period_start} - {$period_end}", $payroll_id);
        wp_send_json_success(array('id'=>$payroll_id));
        break;

    case 'payroll_list':
        $rows = $wpdb->get_results("SELECT * FROM {$p}payroll ORDER BY period_start DESC LIMIT 50", ARRAY_A);
        wp_send_json_success($rows);
        break;

    case 'payroll_detail':
        $id = $in('id');
        $payroll = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$p}payroll WHERE id=%d", $id), ARRAY_A);
        $items = $wpdb->get_results($wpdb->prepare(
            "SELECT pi.*, CONCAT(e.first_name,' ',e.last_name) as employee_name, e.department
             FROM {$p}payroll_items pi LEFT JOIN {$p}employees e ON e.id=pi.employee_id WHERE pi.payroll_id=%d", $id
        ), ARRAY_A);
        wp_send_json_success(array('payroll'=>$payroll, 'items'=>$items));
        break;

    /* ─── PROJECTS ─── */
    case 'projects_list':
        $rows = $wpdb->get_results("SELECT p.*, (SELECT COUNT(*) FROM {$p}tasks t WHERE t.project_id=p.id) as task_count,
            (SELECT COUNT(*) FROM {$p}tasks t WHERE t.project_id=p.id AND t.status='done') as done_count
            FROM {$p}projects p ORDER BY p.created_at DESC", ARRAY_A);
        wp_send_json_success($rows);
        break;

    case 'project_save':
        $id = $in('id');
        $data = array(
            'name'=>$d('name'), 'description'=>sanitize_textarea_field($_POST['description']??''),
            'client_id'=>$in('client_id'), 'budget'=>$fn('budget'),
            'start_date'=>$d('start_date'), 'end_date'=>$d('end_date'),
            'status'=>$d('status','planning'), 'color'=>$d('color','#6366f1'),
        );
        if ($id) { $wpdb->update("{$p}projects", $data, array('id'=>$id)); }
        else { $wpdb->insert("{$p}projects", $data); $id=$wpdb->insert_id; }
        wp_send_json_success(array('id'=>$id));
        break;

    case 'tasks_list':
        $pid = $in('project_id');
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT t.*, CONCAT(e.first_name,' ',e.last_name) as assigned_name
             FROM {$p}tasks t LEFT JOIN {$p}employees e ON e.id=t.assigned_to
             WHERE t.project_id=%d ORDER BY t.sort_order, t.id", $pid
        ), ARRAY_A);
        wp_send_json_success($rows);
        break;

    case 'task_save':
        $id = $in('id');
        $data = array(
            'project_id'=>$in('project_id'), 'title'=>$d('title'),
            'description'=>sanitize_textarea_field($_POST['description']??''),
            'assigned_to'=>$in('assigned_to'), 'priority'=>$d('priority','medium'),
            'status'=>$d('status','todo'), 'due_date'=>$d('due_date'),
            'estimated_hours'=>$fn('estimated_hours'),
        );
        if ($id) { $wpdb->update("{$p}tasks", $data, array('id'=>$id)); }
        else { $wpdb->insert("{$p}tasks", $data); $id=$wpdb->insert_id; }
        wp_send_json_success(array('id'=>$id));
        break;

    case 'task_move':
        $wpdb->update("{$p}tasks", array('status'=>$d('status')), array('id'=>$in('id')));
        wp_send_json_success(true);
        break;

    /* ─── REPORTS ─── */
    case 'report_sales':
        $from = $d('from', date('Y-m-01'));
        $to   = $d('to', date('Y-m-d'));
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT DATE(date_issued) as day, SUM(total) as total, COUNT(*) as count
             FROM {$p}documents WHERE type IN ('invoice','order') AND status NOT IN ('cancelled','draft')
             AND date_issued BETWEEN %s AND %s GROUP BY DATE(date_issued) ORDER BY day", $from, $to
        ), ARRAY_A);
        $by_client = $wpdb->get_results($wpdb->prepare(
            "SELECT contact_name, SUM(total) as total, COUNT(*) as count
             FROM {$p}documents WHERE type IN ('invoice','order') AND status NOT IN ('cancelled','draft')
             AND date_issued BETWEEN %s AND %s GROUP BY contact_id ORDER BY total DESC LIMIT 10", $from, $to
        ), ARRAY_A);
        wp_send_json_success(array('daily'=>$rows, 'by_client'=>$by_client));
        break;

    case 'report_inventory':
        $rows = $wpdb->get_results(
            "SELECT pr.id, pr.sku, pr.name, pr.cost, pr.price, pr.min_stock, pr.unit,
                    COALESCE(s.quantity,0) as stock_qty,
                    (COALESCE(s.quantity,0) * pr.cost) as stock_value,
                    c.name as category_name
             FROM {$p}products pr
             LEFT JOIN {$p}stock s ON s.product_id=pr.id
             LEFT JOIN {$p}categories c ON c.id=pr.category_id
             WHERE pr.status='active' AND pr.type='product'
             ORDER BY pr.name", ARRAY_A
        );
        wp_send_json_success($rows);
        break;

    case 'report_financial':
        $revenue = (float)$wpdb->get_var("SELECT COALESCE(SUM(balance),0) FROM {$p}accounts WHERE type='revenue'");
        $expenses = (float)$wpdb->get_var("SELECT COALESCE(SUM(balance),0) FROM {$p}accounts WHERE type='expense'");
        $assets = (float)$wpdb->get_var("SELECT COALESCE(SUM(balance),0) FROM {$p}accounts WHERE type='asset'");
        $liabilities = (float)$wpdb->get_var("SELECT COALESCE(SUM(balance),0) FROM {$p}accounts WHERE type='liability'");
        $equity = (float)$wpdb->get_var("SELECT COALESCE(SUM(balance),0) FROM {$p}accounts WHERE type='equity'");
        wp_send_json_success(array(
            'revenue'=>$revenue, 'expenses'=>$expenses, 'profit'=>$revenue-$expenses,
            'assets'=>$assets, 'liabilities'=>$liabilities, 'equity'=>$equity
        ));
        break;

    /* ─── ACTIVITY LOG ─── */
    case 'activity_list':
        $rows = $wpdb->get_results("SELECT * FROM {$p}activity ORDER BY created_at DESC LIMIT 100", ARRAY_A);
        wp_send_json_success($rows);
        break;

    /* ─── NOTIFICATIONS ─── */
    case 'notifications_list':
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$p}notifications WHERE user_id=%d ORDER BY created_at DESC LIMIT 20", $uid
        ), ARRAY_A);
        wp_send_json_success($rows);
        break;

    case 'notification_read':
        $wpdb->update("{$p}notifications", array('is_read'=>1), array('id'=>$in('id'), 'user_id'=>$uid));
        wp_send_json_success(true);
        break;

    /* ─── COMPANY SETTINGS ─── */
    case 'company_get':
        $row = $wpdb->get_row("SELECT * FROM {$p}companies WHERE is_default=1 LIMIT 1", ARRAY_A);
        wp_send_json_success($row);
        break;

    case 'company_save':
        $data = array(
            'name'=>$d('name'), 'rfc'=>strtoupper($d('rfc')),
            'address'=>sanitize_textarea_field($_POST['address']??''),
            'phone'=>$d('phone'), 'email'=>sanitize_email($_POST['email']??''),
            'currency'=>$d('currency','MXN'), 'tax_rate'=>$fn('tax_rate',16),
        );
        $id = $wpdb->get_var("SELECT id FROM {$p}companies WHERE is_default=1 LIMIT 1");
        if ($id) { $wpdb->update("{$p}companies", $data, array('id'=>$id)); }
        else { $data['is_default']=1; $wpdb->insert("{$p}companies", $data); }
        $log('update','settings','Datos de empresa actualizados');
        wp_send_json_success(true);
        break;

    /* ─── WAREHOUSES ─── */
    case 'warehouses_list':
        $rows = $wpdb->get_results("SELECT * FROM {$p}warehouses ORDER BY name", ARRAY_A);
        wp_send_json_success($rows);
        break;

    case 'warehouse_save':
        $id = $in('id');
        $data = array('name'=>$d('name'), 'location'=>$d('location'), 'manager'=>$d('manager'));
        if ($id) { $wpdb->update("{$p}warehouses", $data, array('id'=>$id)); }
        else { $wpdb->insert("{$p}warehouses", $data); $id=$wpdb->insert_id; }
        wp_send_json_success(array('id'=>$id));
        break;

    /* ─── SEARCH GLOBAL ─── */
    case 'global_search':
        $q = $d('q');
        if (strlen($q) < 2) wp_send_json_success(array());
        $results = array();

        $contacts = $wpdb->get_results($wpdb->prepare(
            "SELECT id, name, type, 'contact' as entity FROM {$p}contacts WHERE name LIKE %s LIMIT 5", "%{$q}%"
        ), ARRAY_A);
        $products = $wpdb->get_results($wpdb->prepare(
            "SELECT id, name, sku as type, 'product' as entity FROM {$p}products WHERE (name LIKE %s OR sku LIKE %s) AND status='active' LIMIT 5", "%{$q}%", "%{$q}%"
        ), ARRAY_A);
        $docs = $wpdb->get_results($wpdb->prepare(
            "SELECT id, doc_number as name, type, 'document' as entity FROM {$p}documents WHERE doc_number LIKE %s OR contact_name LIKE %s LIMIT 5", "%{$q}%", "%{$q}%"
        ), ARRAY_A);

        wp_send_json_success(array_merge($contacts, $products, $docs));
        break;

    /* ─── PRODUCT SEARCH (for document items) ─── */
    case 'products_search':
        $q = $d('q');
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT id, sku, name, price, cost, tax_rate, unit FROM {$p}products WHERE status='active' AND (name LIKE %s OR sku LIKE %s) LIMIT 10", "%{$q}%", "%{$q}%"
        ), ARRAY_A);
        wp_send_json_success($rows);
        break;

    /* ─── CONTACTS SEARCH ─── */
    case 'contacts_search':
        $q = $d('q');
        $t = $d('type','');
        $w = $wpdb->prepare("(name LIKE %s OR rfc LIKE %s)", "%{$q}%", "%{$q}%");
        if ($t) $w .= $wpdb->prepare(" AND type=%s", $t);
        $rows = $wpdb->get_results("SELECT id, name, rfc, type FROM {$p}contacts WHERE {$w} AND status='active' LIMIT 10", ARRAY_A);
        wp_send_json_success($rows);
        break;

    default:
        wp_send_json_error('Accion no reconocida: ' . $action);
    }

    wp_die();
}

/* ─── Check for overdue invoices daily ─── */
add_action('init', function() {
    if (!wp_next_scheduled('nxerp_daily_check')) {
        wp_schedule_event(time(), 'daily', 'nxerp_daily_check');
    }
});
add_action('nxerp_daily_check', function() {
    global $wpdb;
    $p = $wpdb->prefix . NXERP_PREFIX;
    $wpdb->query($wpdb->prepare(
        "UPDATE {$p}documents SET status='overdue' WHERE type='invoice' AND status IN ('sent','approved','partial') AND date_due < %s",
        date('Y-m-d')
    ));
});

/* Deactivation cleanup */
register_deactivation_hook(__FILE__, function() {
    wp_clear_scheduled_hook('nxerp_daily_check');
});

<?php
/* MayaERP — clean uninstall: drops its own tables and options. */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) { exit; }
global $wpdb;
$p = $wpdb->prefix . 'mayaerp_';
$tables = array(
    'companies','users','branches','contacts','issuers','products','categories',
    'warehouses','stock_moves','documents','document_items','payments',
    'chart_accounts','journal_entries','journal_lines','bank_accounts','bank_transactions',
    'employees','payroll','payroll_details','fixed_assets','depreciation_schedule',
    'amortizations','amortization_schedule','projects','tasks','tax_tables',
    'notifications','activity_log','plans','antifraud_alerts','ai_chats'
);
foreach ( $tables as $t ) {
    $wpdb->query( "DROP TABLE IF EXISTS {$p}{$t}" );
}
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE 'mayaerp\\_%'" );

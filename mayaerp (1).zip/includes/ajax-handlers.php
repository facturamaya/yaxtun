<?php
if(!defined('ABSPATH'))exit;
/* Variables inherited from mayaerp_ajax(): $wpdb, $p, $act, $uid, $cid */

switch($act){

/* ═══ SESSION RESUME (me) ═══ */
case 'me':
    if(empty($_SESSION['mayaerp_uid'])){wp_send_json_success(array('logged_in'=>false));}
    $u=$wpdb->get_row($wpdb->prepare("SELECT id,name,email,role,avatar_url,company_id FROM {$p}users WHERE id=%d",intval($_SESSION['mayaerp_uid'])));
    if(!$u){unset($_SESSION['mayaerp_uid'],$_SESSION['mayaerp_cid']);wp_send_json_success(array('logged_in'=>false));}
    $co=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$p}companies WHERE id=%d",$u->company_id));
    $nt=$co?(!$co->terms_accepted||!$co->privacy_accepted):false;
    wp_send_json_success(array('logged_in'=>true,'nonce'=>wp_create_nonce('mayaerp_nonce'),'needs_terms'=>$nt,
        'user'=>array('id'=>$u->id,'name'=>$u->name,'email'=>$u->email,'role'=>$u->role,'avatar'=>$u->avatar_url),
        'company'=>$co?array('id'=>$co->id,'name'=>$co->name,'plan'=>$co->plan_type,'plan_end'=>$co->plan_end,'stamps_total'=>$co->stamps_total,'stamps_used'=>$co->stamps_used,'is_multi'=>$co->is_multi_emisor,'antifraud'=>$co->antifraud_enabled):array()
    ));
    break;

/* ═══ REGISTER ═══ */
case 'register':
    $tk=sanitize_text_field($_POST['turnstile_token']??'');
    if(!mayaerp_verify_turnstile($tk))wp_send_json_error(array('msg'=>'Verificacion de seguridad fallida.'));
    $nm=sanitize_text_field($_POST['name']??'');
    $em=sanitize_email($_POST['email']??'');
    $rfc=strtoupper(sanitize_text_field($_POST['rfc']??''));
    $curp=strtoupper(sanitize_text_field($_POST['curp']??''));
    $ph=sanitize_text_field($_POST['phone']??'');
    $giro=sanitize_text_field($_POST['giro']??'');
    $pw=$_POST['password']??'';
    $pw2=$_POST['password2']??'';
    $multi=intval($_POST['is_multi_emisor']??0);
    if(empty($nm)||empty($em)||empty($pw))wp_send_json_error(array('msg'=>'Nombre, email y contrasena son obligatorios.'));
    if(strlen($pw)<8)wp_send_json_error(array('msg'=>'La contrasena debe tener minimo 8 caracteres.'));
    if($pw!==$pw2)wp_send_json_error(array('msg'=>'Las contrasenas no coinciden.'));
    if($rfc&&!preg_match('/^[A-Z&]{3,4}\d{6}[A-Z0-9]{3}$/',$rfc))wp_send_json_error(array('msg'=>'RFC invalido.'));
    if($wpdb->get_var($wpdb->prepare("SELECT id FROM {$p}users WHERE email=%s",$em)))wp_send_json_error(array('msg'=>'Ya existe una cuenta con este correo.'));
    $wpdb->insert("{$p}companies",array('name'=>$nm,'rfc'=>$rfc,'curp'=>$curp,'email'=>$em,'phone'=>$ph,'fiscal_activity'=>$giro,'is_multi_emisor'=>$multi,'plan_type'=>'trial','plan_start'=>current_time('Y-m-d'),'plan_end'=>date('Y-m-d',strtotime('+'.MAYAERP_TRIAL_DAYS.' days')),'stamps_total'=>MAYAERP_TRIAL_STAMPS,'status'=>'trial'));
    $nc=$wpdb->insert_id;
    $code=str_pad(random_int(100000,999999),6,'0',STR_PAD_LEFT);
    $wpdb->insert("{$p}users",array('company_id'=>$nc,'name'=>$nm,'email'=>$em,'password_hash'=>password_hash($pw,PASSWORD_BCRYPT),'rfc'=>$rfc,'curp'=>$curp,'phone'=>$ph,'role'=>'owner','verification_code'=>$code,'code_expires'=>date('Y-m-d H:i:s',strtotime('+2 minutes')),'status'=>'pending'));
    $nu=$wpdb->insert_id;
    $wpdb->update("{$p}companies",array('owner_user_id'=>$nu),array('id'=>$nc));
    $wpdb->insert("{$p}warehouses",array('company_id'=>$nc,'name'=>'Almacen Principal'));
    $body='<p style="font-size:15px;color:#334155">Hola <strong>'.$nm.'</strong>,</p><p style="color:#475569">Bienvenido a MayaERP. Usa este codigo para verificar tu cuenta:</p>';
    mayaerp_send_email($em,'Codigo de verificacion - MayaERP',mayaerp_email_tpl('Verificar tu Cuenta',$body,$code));
    wp_send_json_success(array('msg'=>'Cuenta creada. Revisa tu correo.','email'=>$em,'user_id'=>$nu));
    break;

/* ═══ VERIFY EMAIL ═══ */
case 'verify_email':
    $em=sanitize_email($_POST['email']??'');
    $cd=sanitize_text_field($_POST['code']??'');
    $u=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$p}users WHERE email=%s",$em));
    if(!$u)wp_send_json_error(array('msg'=>'Usuario no encontrado.'));
    if($u->email_verified)wp_send_json_error(array('msg'=>'Cuenta ya verificada.'));
    if($u->verification_code!==$cd)wp_send_json_error(array('msg'=>'Codigo incorrecto.'));
    if(strtotime($u->code_expires)<time())wp_send_json_error(array('msg'=>'Codigo expirado. Solicita uno nuevo.'));
    $wpdb->update("{$p}users",array('email_verified'=>1,'status'=>'active','verification_code'=>''),array('id'=>$u->id));
    $_SESSION['mayaerp_uid']=$u->id;$_SESSION['mayaerp_cid']=$u->company_id;
    $wpdb->update("{$p}users",array('last_login'=>current_time('mysql')),array('id'=>$u->id));
    wp_send_json_success(array('msg'=>'Cuenta verificada.','nonce'=>wp_create_nonce('mayaerp_nonce'),'user'=>array('id'=>$u->id,'name'=>$u->name,'email'=>$u->email,'role'=>$u->role)));
    break;

/* ═══ RESEND CODE ═══ */
case 'resend_code':
    $em=sanitize_email($_POST['email']??'');
    $u=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$p}users WHERE email=%s",$em));
    if(!$u)wp_send_json_error(array('msg'=>'Usuario no encontrado.'));
    $code=str_pad(random_int(100000,999999),6,'0',STR_PAD_LEFT);
    $wpdb->update("{$p}users",array('verification_code'=>$code,'code_expires'=>date('Y-m-d H:i:s',strtotime('+2 minutes'))),array('id'=>$u->id));
    $body='<p style="color:#475569">Tu nuevo codigo de verificacion:</p>';
    mayaerp_send_email($em,'Nuevo codigo - MayaERP',mayaerp_email_tpl('Codigo de Verificacion',$body,$code));
    wp_send_json_success(array('msg'=>'Codigo reenviado.'));
    break;

/* ═══ LOGIN ═══ */
case 'login':
    $tk=sanitize_text_field($_POST['turnstile_token']??'');
    if(!mayaerp_verify_turnstile($tk))wp_send_json_error(array('msg'=>'Verificacion de seguridad fallida.'));
    $em=sanitize_email($_POST['email']??'');
    $pw=$_POST['password']??'';
    $u=$wpdb->get_row($wpdb->prepare("SELECT u.*,c.status as co_st,c.plan_type,c.plan_end FROM {$p}users u LEFT JOIN {$p}companies c ON u.company_id=c.id WHERE u.email=%s",$em));
    if(!$u)wp_send_json_error(array('msg'=>'Credenciales incorrectas.'));
    if($u->locked_until&&strtotime($u->locked_until)>time()){$m=ceil((strtotime($u->locked_until)-time())/60);wp_send_json_error(array('msg'=>'Cuenta bloqueada. Intenta en '.$m.' min.'));}
    if(!password_verify($pw,$u->password_hash)){
        $att=$u->login_attempts+1;$lk=($att>=5)?date('Y-m-d H:i:s',strtotime('+15 minutes')):null;
        $wpdb->update("{$p}users",array('login_attempts'=>$att,'locked_until'=>$lk),array('id'=>$u->id));
        wp_send_json_error(array('msg'=>'Credenciales incorrectas. Intento '.$att.'/5'));
    }
    if(!$u->email_verified){
        $code=str_pad(random_int(100000,999999),6,'0',STR_PAD_LEFT);
        $wpdb->update("{$p}users",array('verification_code'=>$code,'code_expires'=>date('Y-m-d H:i:s',strtotime('+2 minutes'))),array('id'=>$u->id));
        mayaerp_send_email($em,'Verifica tu cuenta - MayaERP',mayaerp_email_tpl('Verificar Cuenta','<p style="color:#475569">Tu codigo:</p>',$code));
        wp_send_json_error(array('msg'=>'Cuenta no verificada. Codigo enviado.','code'=>'NEED_VERIFY','email'=>$em));
    }
    if($u->status!=='active')wp_send_json_error(array('msg'=>'Cuenta inactiva. Contacta soporte.'));
    $wpdb->update("{$p}users",array('login_attempts'=>0,'locked_until'=>null,'last_login'=>current_time('mysql')),array('id'=>$u->id));
    $_SESSION['mayaerp_uid']=$u->id;$_SESSION['mayaerp_cid']=$u->company_id;
    $co=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$p}companies WHERE id=%d",$u->company_id));
    $nt=(!$co->terms_accepted||!$co->privacy_accepted);
    wp_send_json_success(array('msg'=>'Bienvenido, '.$u->name,'nonce'=>wp_create_nonce('mayaerp_nonce'),'needs_terms'=>$nt,
        'user'=>array('id'=>$u->id,'name'=>$u->name,'email'=>$u->email,'role'=>$u->role,'avatar'=>$u->avatar_url),
        'company'=>array('id'=>$co->id,'name'=>$co->name,'plan'=>$co->plan_type,'plan_end'=>$co->plan_end,'stamps_total'=>$co->stamps_total,'stamps_used'=>$co->stamps_used,'is_multi'=>$co->is_multi_emisor,'antifraud'=>$co->antifraud_enabled)
    ));
    break;

/* ═══ FORGOT / RESET PASSWORD ═══ */
case 'forgot_password':
    $em=sanitize_email($_POST['email']??'');
    $u=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$p}users WHERE email=%s",$em));
    if($u){
        $tk=wp_generate_password(32,false);
        $wpdb->update("{$p}users",array('reset_token'=>$tk,'reset_expires'=>date('Y-m-d H:i:s',strtotime('+30 minutes'))),array('id'=>$u->id));
        $base=esc_url_raw($_POST['app_url']??'');
        if(!$base||strpos($base,home_url())!==0){$base=function_exists('mayaerp_app_url')?mayaerp_app_url():home_url('/');}
        $sep=(strpos($base,'?')!==false)?'&':'?';
        $lnk=$base.$sep.'mayaerp_reset='.$tk.'&email='.urlencode($em);
        $body='<p style="color:#475569">Hola '.$u->name.',</p><p style="color:#475569">Haz clic para restablecer tu contrasena (valido 30 minutos):</p><div style="text-align:center;margin:24px 0"><a href="'.$lnk.'" style="display:inline-block;background:linear-gradient(135deg,#0d3320,#1a5c38);color:#fff;padding:14px 40px;border-radius:10px;text-decoration:none;font-weight:600">Restablecer contrasena</a></div><p style="color:#94a3b8;font-size:12px">Si el boton no funciona, copia este enlace:<br>'.esc_html($lnk).'</p>';
        mayaerp_send_email($em,'Restablecer contrasena - MayaERP',mayaerp_email_tpl('Restablecer Contrasena',$body));
    }
    wp_send_json_success(array('msg'=>'Si el correo existe, recibiras instrucciones.'));
    break;

case 'reset_password':
    $tk=sanitize_text_field($_POST['token']??'');$em=sanitize_email($_POST['email']??'');
    $pw=$_POST['password']??'';$pw2=$_POST['password2']??'';
    if(strlen($pw)<8)wp_send_json_error(array('msg'=>'Minimo 8 caracteres.'));
    if($pw!==$pw2)wp_send_json_error(array('msg'=>'No coinciden.'));
    $u=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$p}users WHERE email=%s AND reset_token=%s",$em,$tk));
    if(!$u)wp_send_json_error(array('msg'=>'Enlace invalido.'));
    if(strtotime($u->reset_expires)<time())wp_send_json_error(array('msg'=>'Enlace expirado.'));
    $wpdb->update("{$p}users",array('password_hash'=>password_hash($pw,PASSWORD_BCRYPT),'reset_token'=>'','login_attempts'=>0,'locked_until'=>null),array('id'=>$u->id));
    wp_send_json_success(array('msg'=>'Contrasena actualizada.'));
    break;

case 'logout':
    unset($_SESSION['mayaerp_uid'],$_SESSION['mayaerp_cid']);session_destroy();
    wp_send_json_success(array('msg'=>'Sesion cerrada.'));
    break;

/* ═══ ACCEPT TERMS ═══ */
case 'accept_terms':
    $t=intval($_POST['terms']??0);$pr=intval($_POST['privacy']??0);
    $cf=intval($_POST['confidentiality']??0);$af=intval($_POST['antifraud']??0);
    if(!$t||!$pr)wp_send_json_error(array('msg'=>'Debes aceptar Terminos y Privacidad.'));
    $wpdb->update("{$p}companies",array('terms_accepted'=>$t,'privacy_accepted'=>$pr,'confidentiality_accepted'=>$cf,'antifraud_enabled'=>$af),array('id'=>$cid));
    wp_send_json_success(array('msg'=>'Aceptado.','antifraud'=>$af));
    break;

/* ═══ DASHBOARD ═══ */
case 'dashboard_stats':
    $ms=current_time('Y-m-01');
    $s=array(
        'total_clients'=>(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$p}contacts WHERE company_id=%d AND type='client' AND status='active'",$cid)),
        'total_suppliers'=>(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$p}contacts WHERE company_id=%d AND type='supplier' AND status='active'",$cid)),
        'total_products'=>(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$p}products WHERE company_id=%d AND is_active=1",$cid)),
        'month_sales'=>(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(total),0) FROM {$p}documents WHERE company_id=%d AND type='invoice' AND status IN('paid','partial','sent') AND date_issued>=%s",$cid,$ms)),
        'month_purchases'=>(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(total),0) FROM {$p}documents WHERE company_id=%d AND type='purchase_order' AND status IN('paid','partial','sent') AND date_issued>=%s",$cid,$ms)),
        'pending_invoices'=>(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$p}documents WHERE company_id=%d AND type='invoice' AND status IN('sent','overdue')",$cid)),
        'pending_amount'=>(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(total-amount_paid),0) FROM {$p}documents WHERE company_id=%d AND type='invoice' AND status IN('sent','partial','overdue')",$cid)),
        'total_employees'=>(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$p}employees WHERE company_id=%d AND status='active'",$cid)),
        'bank_balance'=>(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(balance),0) FROM {$p}bank_accounts WHERE company_id=%d AND status=1",$cid)),
        'low_stock'=>(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$p}products WHERE company_id=%d AND track_inventory=1 AND current_stock<=min_stock AND is_active=1",$cid)),
        'overdue_invoices'=>(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$p}documents WHERE company_id=%d AND type='invoice' AND status='overdue'",$cid)),
        'antifraud_alerts'=>(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$p}antifraud_alerts WHERE company_id=%d AND resolved=0",$cid)),
    );
    $chart=array();
    for($i=5;$i>=0;$i--){
        $m1=date('Y-m-01',strtotime("-{$i} months"));$m2=date('Y-m-t',strtotime("-{$i} months"));
        $chart[]=array('label'=>date('M Y',strtotime($m1)),
            'sales'=>(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(total),0) FROM {$p}documents WHERE company_id=%d AND type='invoice' AND status IN('paid','partial','sent') AND date_issued BETWEEN %s AND %s",$cid,$m1,$m2)),
            'expenses'=>(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(total),0) FROM {$p}documents WHERE company_id=%d AND type='purchase_order' AND status IN('paid','partial','sent') AND date_issued BETWEEN %s AND %s",$cid,$m1,$m2))
        );
    }
    $s['chart']=$chart;
    $s['recent_activity']=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$p}activity_log WHERE company_id=%d ORDER BY created_at DESC LIMIT 10",$cid));
    $s['notifications']=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$p}notifications WHERE company_id=%d AND(user_id=%d OR user_id=0) AND is_read=0 ORDER BY created_at DESC LIMIT 10",$cid,$uid));
    $s['company']=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$p}companies WHERE id=%d",$cid));
    $s['user']=$wpdb->get_row($wpdb->prepare("SELECT id,name,email,role,avatar_url FROM {$p}users WHERE id=%d",$uid));
    wp_send_json_success($s);
    break;

/* ═══ CONTACTS ═══ */
case 'contacts_list':
    $tp=sanitize_text_field($_POST['type']??'client');$sr=sanitize_text_field($_POST['search']??'');
    $pg=max(1,intval($_POST['page']??1));$pp=25;$of=($pg-1)*$pp;
    $w=$wpdb->prepare("company_id=%d AND type=%s",$cid,$tp);
    if($sr)$w.=$wpdb->prepare(" AND(name LIKE %s OR rfc LIKE %s OR email LIKE %s)","%{$sr}%","%{$sr}%","%{$sr}%");
    $tt=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$p}contacts WHERE {$w}");
    $rw=$wpdb->get_results("SELECT * FROM {$p}contacts WHERE {$w} ORDER BY name LIMIT {$pp} OFFSET {$of}");
    wp_send_json_success(array('rows'=>$rw,'total'=>$tt,'pages'=>ceil($tt/$pp)));
    break;

case 'contact_save':
    $id=intval($_POST['id']??0);
    $d=array('company_id'=>$cid,'type'=>sanitize_text_field($_POST['type']??'client'),'person_type'=>sanitize_text_field($_POST['person_type']??'fisica'),
        'name'=>sanitize_text_field($_POST['name']??''),'rfc'=>strtoupper(sanitize_text_field($_POST['rfc']??'')),'curp'=>strtoupper(sanitize_text_field($_POST['curp']??'')),
        'email'=>sanitize_email($_POST['email']??''),'phone'=>sanitize_text_field($_POST['phone']??''),
        'street'=>sanitize_text_field($_POST['street']??''),'ext_num'=>sanitize_text_field($_POST['ext_num']??''),'int_num'=>sanitize_text_field($_POST['int_num']??''),
        'colony'=>sanitize_text_field($_POST['colony']??''),'city'=>sanitize_text_field($_POST['city']??''),'municipality'=>sanitize_text_field($_POST['municipality']??''),
        'state'=>sanitize_text_field($_POST['state']??''),'zip'=>sanitize_text_field($_POST['zip']??''),
        'regimen_fiscal'=>sanitize_text_field($_POST['regimen_fiscal']??''),'uso_cfdi'=>sanitize_text_field($_POST['uso_cfdi']??'G03'),
        'credit_days'=>intval($_POST['credit_days']??0),'credit_limit'=>floatval($_POST['credit_limit']??0),
        'notes'=>sanitize_textarea_field($_POST['notes']??''),'tags'=>sanitize_text_field($_POST['tags']??''));
    if(empty($d['name']))wp_send_json_error(array('msg'=>'Nombre obligatorio.'));
    if($id>0){$wpdb->update("{$p}contacts",$d,array('id'=>$id,'company_id'=>$cid));$mg='Actualizado.';}
    else{$wpdb->insert("{$p}contacts",$d);$id=$wpdb->insert_id;$mg='Creado.';}
    $wpdb->insert("{$p}activity_log",array('company_id'=>$cid,'user_id'=>$uid,'action'=>'contact_save','entity'=>'contact','entity_id'=>$id,'detail'=>$d['name']));
    wp_send_json_success(array('msg'=>$mg,'id'=>$id));
    break;

case 'contact_get':
    $id=intval($_POST['id']??0);
    wp_send_json_success(array('row'=>$wpdb->get_row($wpdb->prepare("SELECT * FROM {$p}contacts WHERE id=%d AND company_id=%d",$id,$cid))));
    break;

case 'contact_delete':
    $wpdb->delete("{$p}contacts",array('id'=>intval($_POST['id']??0),'company_id'=>$cid));
    wp_send_json_success(array('msg'=>'Eliminado.'));
    break;

/* ═══ PRODUCTS ═══ */
case 'products_list':
    $sr=sanitize_text_field($_POST['search']??'');$pg=max(1,intval($_POST['page']??1));$pp=25;$of=($pg-1)*$pp;
    $w=$wpdb->prepare("company_id=%d",$cid);
    if($sr)$w.=$wpdb->prepare(" AND(name LIKE %s OR sku LIKE %s OR barcode LIKE %s)","%{$sr}%","%{$sr}%","%{$sr}%");
    $tt=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$p}products WHERE {$w}");
    $rw=$wpdb->get_results("SELECT * FROM {$p}products WHERE {$w} ORDER BY name LIMIT {$pp} OFFSET {$of}");
    wp_send_json_success(array('rows'=>$rw,'total'=>$tt,'pages'=>ceil($tt/$pp)));
    break;

case 'product_save':
    $id=intval($_POST['id']??0);
    $d=array('company_id'=>$cid,'sku'=>sanitize_text_field($_POST['sku']??''),'barcode'=>sanitize_text_field($_POST['barcode']??''),
        'sat_code'=>sanitize_text_field($_POST['sat_code']??''),'name'=>sanitize_text_field($_POST['name']??''),
        'description'=>sanitize_textarea_field($_POST['description']??''),'category_id'=>intval($_POST['category_id']??0),
        'type'=>sanitize_text_field($_POST['type']??'product'),'unit'=>sanitize_text_field($_POST['unit']??'PZA'),
        'sat_unit'=>sanitize_text_field($_POST['sat_unit']??'H87'),'cost'=>floatval($_POST['cost']??0),
        'price'=>floatval($_POST['price']??0),'tax_rate'=>floatval($_POST['tax_rate']??16),
        'ieps_rate'=>floatval($_POST['ieps_rate']??0),'retention_isr'=>floatval($_POST['retention_isr']??0),
        'retention_iva'=>floatval($_POST['retention_iva']??0),'min_stock'=>intval($_POST['min_stock']??0),
        'max_stock'=>intval($_POST['max_stock']??0),'track_inventory'=>intval($_POST['track_inventory']??1));
    if(empty($d['name']))wp_send_json_error(array('msg'=>'Nombre obligatorio.'));
    if($id>0)$wpdb->update("{$p}products",$d,array('id'=>$id,'company_id'=>$cid));
    else{$wpdb->insert("{$p}products",$d);$id=$wpdb->insert_id;}
    wp_send_json_success(array('msg'=>'Producto guardado.','id'=>$id));
    break;

case 'product_get':
    wp_send_json_success(array('row'=>$wpdb->get_row($wpdb->prepare("SELECT * FROM {$p}products WHERE id=%d AND company_id=%d",intval($_POST['id']??0),$cid))));
    break;

case 'product_delete':
    $wpdb->delete("{$p}products",array('id'=>intval($_POST['id']??0),'company_id'=>$cid));
    wp_send_json_success(array('msg'=>'Eliminado.'));
    break;

/* ═══ CATEGORIES ═══ */
case 'categories_list':
    wp_send_json_success(array('rows'=>$wpdb->get_results($wpdb->prepare("SELECT * FROM {$p}categories WHERE company_id IN(0,%d) ORDER BY name",$cid))));
    break;

case 'category_save':
    $d=array('company_id'=>$cid,'name'=>sanitize_text_field($_POST['name']??''),'parent_id'=>intval($_POST['parent_id']??0),'color'=>sanitize_text_field($_POST['color']??'#1a5c38'));
    $id=intval($_POST['id']??0);
    if($id>0)$wpdb->update("{$p}categories",$d,array('id'=>$id));
    else{$wpdb->insert("{$p}categories",$d);$id=$wpdb->insert_id;}
    wp_send_json_success(array('msg'=>'Categoria guardada.','id'=>$id));
    break;

/* ═══ STOCK ═══ */
case 'stock_adjust':
    $pid=intval($_POST['product_id']??0);$qty=floatval($_POST['qty']??0);$type=sanitize_text_field($_POST['move_type']??'in');
    $wpdb->insert("{$p}stock_moves",array('company_id'=>$cid,'product_id'=>$pid,'type'=>$type,'qty'=>$qty,'reference'=>sanitize_text_field($_POST['reference']??''),'notes'=>sanitize_text_field($_POST['notes']??''),'user_id'=>$uid));
    $cur=(float)$wpdb->get_var($wpdb->prepare("SELECT current_stock FROM {$p}products WHERE id=%d",$pid));
    $new=$type==='out'?$cur-$qty:$cur+$qty;
    $wpdb->update("{$p}products",array('current_stock'=>$new),array('id'=>$pid));
    wp_send_json_success(array('msg'=>'Stock actualizado.','new_stock'=>$new));
    break;

/* ═══ DOCUMENTS ═══ */
case 'documents_list':
    $tp=sanitize_text_field($_POST['type']??'invoice');$st=sanitize_text_field($_POST['status']??'');
    $sr=sanitize_text_field($_POST['search']??'');$pg=max(1,intval($_POST['page']??1));$pp=20;$of=($pg-1)*$pp;
    $w=$wpdb->prepare("company_id=%d AND type=%s",$cid,$tp);
    if($st)$w.=$wpdb->prepare(" AND status=%s",$st);
    if($sr)$w.=$wpdb->prepare(" AND(contact_name LIKE %s OR folio LIKE %s)","%{$sr}%","%{$sr}%");
    $tt=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$p}documents WHERE {$w}");
    $rw=$wpdb->get_results("SELECT * FROM {$p}documents WHERE {$w} ORDER BY id DESC LIMIT {$pp} OFFSET {$of}");
    wp_send_json_success(array('rows'=>$rw,'total'=>$tt,'pages'=>ceil($tt/$pp)));
    break;

case 'document_save':
    $id=intval($_POST['id']??0);$items=json_decode(stripslashes($_POST['items']??'[]'),true);
    $d=array('company_id'=>$cid,'issuer_id'=>intval($_POST['issuer_id']??0),'type'=>sanitize_text_field($_POST['type']??'invoice'),
        'series'=>sanitize_text_field($_POST['series']??'A'),'contact_id'=>intval($_POST['contact_id']??0),
        'contact_name'=>sanitize_text_field($_POST['contact_name']??''),'contact_rfc'=>sanitize_text_field($_POST['contact_rfc']??''),
        'date_issued'=>sanitize_text_field($_POST['date_issued']??current_time('Y-m-d')),
        'date_due'=>sanitize_text_field($_POST['date_due']??''),'currency'=>sanitize_text_field($_POST['currency']??'MXN'),
        'uso_cfdi'=>sanitize_text_field($_POST['uso_cfdi']??'G03'),'metodo_pago'=>sanitize_text_field($_POST['metodo_pago']??'PUE'),
        'forma_pago'=>sanitize_text_field($_POST['forma_pago']??'01'),
        'notes'=>sanitize_textarea_field($_POST['notes']??''),'status'=>sanitize_text_field($_POST['status']??'draft'),'created_by'=>$uid);
    $sub=0;$tiva=0;$tieps=0;$risr=0;$riva=0;$disc=0;
    foreach($items as $it){
        $q=floatval($it['quantity']??1);$pr=floatval($it['unit_price']??0);$ds=floatval($it['discount']??0);
        $ls=($q*$pr)-$ds;$sub+=$ls;$disc+=$ds;
        $tiva+=$ls*(floatval($it['tax_rate']??16)/100);
        $tieps+=$ls*(floatval($it['ieps_rate']??0)/100);
        $risr+=$ls*(floatval($it['retention_isr_rate']??0)/100);
        $riva+=$ls*(floatval($it['retention_iva_rate']??0)/100);
    }
    $d['subtotal']=round($sub,2);$d['discount']=round($disc,2);$d['tax_iva']=round($tiva,2);
    $d['tax_ieps']=round($tieps,2);$d['retention_isr']=round($risr,2);$d['retention_iva']=round($riva,2);
    $d['total']=round($sub+$tiva+$tieps-$risr-$riva,2);
    if($id>0){$wpdb->update("{$p}documents",$d,array('id'=>$id,'company_id'=>$cid));$wpdb->delete("{$p}document_items",array('document_id'=>$id));}
    else{$mf=(int)$wpdb->get_var($wpdb->prepare("SELECT MAX(folio) FROM {$p}documents WHERE company_id=%d AND type=%s AND series=%s",$cid,$d['type'],$d['series']));$d['folio']=$mf+1;$wpdb->insert("{$p}documents",$d);$id=$wpdb->insert_id;}
    foreach($items as $it){
        $q=floatval($it['quantity']??1);$pr=floatval($it['unit_price']??0);$ds=floatval($it['discount']??0);$ls=($q*$pr)-$ds;
        $wpdb->insert("{$p}document_items",array('document_id'=>$id,'product_id'=>intval($it['product_id']??0),
            'sat_code'=>sanitize_text_field($it['sat_code']??''),'description'=>sanitize_text_field($it['description']??''),
            'unit'=>sanitize_text_field($it['unit']??'PZA'),'sat_unit'=>sanitize_text_field($it['sat_unit']??'H87'),
            'quantity'=>$q,'unit_price'=>$pr,'discount'=>$ds,
            'tax_rate'=>floatval($it['tax_rate']??16),'tax_amount'=>round($ls*(floatval($it['tax_rate']??16)/100),2),
            'subtotal'=>round($ls,2),'total'=>round($ls+$ls*(floatval($it['tax_rate']??16)/100),2)));
    }
    if(($d['auto_poliza']??1)&&$d['status']!=='draft')mayaerp_auto_poliza($id,$cid,$uid);
    $wpdb->insert("{$p}activity_log",array('company_id'=>$cid,'user_id'=>$uid,'action'=>'doc_save','entity'=>$d['type'],'entity_id'=>$id,'detail'=>$d['type'].' #'.$d['series'].($d['folio']??'')));
    wp_send_json_success(array('msg'=>'Documento guardado.','id'=>$id,'folio'=>$d['folio']??0));
    break;

case 'document_get':
    $id=intval($_POST['id']??0);
    wp_send_json_success(array('doc'=>$wpdb->get_row($wpdb->prepare("SELECT * FROM {$p}documents WHERE id=%d AND company_id=%d",$id,$cid)),
        'items'=>$wpdb->get_results($wpdb->prepare("SELECT * FROM {$p}document_items WHERE document_id=%d",$id))));
    break;

case 'document_status':
    $id=intval($_POST['id']??0);$st=sanitize_text_field($_POST['status']??'');
    $wpdb->update("{$p}documents",array('status'=>$st),array('id'=>$id,'company_id'=>$cid));
    wp_send_json_success(array('msg'=>'Estado actualizado.'));
    break;

/* ═══ PAYMENTS ═══ */
case 'payment_save':
    $d=array('company_id'=>$cid,'document_id'=>intval($_POST['document_id']??0),'amount'=>floatval($_POST['amount']??0),
        'payment_date'=>sanitize_text_field($_POST['payment_date']??current_time('Y-m-d')),
        'method'=>sanitize_text_field($_POST['method']??'transfer'),'reference'=>sanitize_text_field($_POST['reference']??''),
        'bank_account_id'=>intval($_POST['bank_account_id']??0),'created_by'=>$uid);
    $wpdb->insert("{$p}payments",$d);
    $doc=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$p}documents WHERE id=%d",$d['document_id']));
    if($doc){$paid=$doc->amount_paid+$d['amount'];$st=$paid>=$doc->total?'paid':'partial';
        $wpdb->update("{$p}documents",array('amount_paid'=>$paid,'status'=>$st),array('id'=>$doc->id));}
    wp_send_json_success(array('msg'=>'Pago registrado.'));
    break;

/* ═══ ACCOUNTING ═══ */
case 'accounts_list':
    wp_send_json_success(array('rows'=>$wpdb->get_results($wpdb->prepare("SELECT * FROM {$p}chart_accounts WHERE company_id IN(0,%d) ORDER BY code",$cid))));
    break;

case 'account_save':
    $id=intval($_POST['id']??0);
    $d=array('company_id'=>$cid,'code'=>sanitize_text_field($_POST['code']??''),'name'=>sanitize_text_field($_POST['name']??''),
        'type'=>sanitize_text_field($_POST['type']??'asset'),'nature'=>sanitize_text_field($_POST['nature']??'debit'),
        'parent_id'=>intval($_POST['parent_id']??0),'level'=>intval($_POST['level']??1));
    if($id>0)$wpdb->update("{$p}chart_accounts",$d,array('id'=>$id));
    else{$wpdb->insert("{$p}chart_accounts",$d);$id=$wpdb->insert_id;}
    wp_send_json_success(array('msg'=>'Cuenta guardada.','id'=>$id));
    break;

case 'journal_list':
    $pg=max(1,intval($_POST['page']??1));$pp=20;$of=($pg-1)*$pp;
    $rw=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$p}journal_entries WHERE company_id=%d ORDER BY entry_date DESC,id DESC LIMIT {$pp} OFFSET {$of}",$cid));
    $tt=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$p}journal_entries WHERE company_id=%d",$cid));
    wp_send_json_success(array('rows'=>$rw,'total'=>$tt,'pages'=>ceil($tt/$pp)));
    break;

case 'journal_save':
    $id=intval($_POST['id']??0);$lines=json_decode(stripslashes($_POST['lines']??'[]'),true);
    $d=array('company_id'=>$cid,'entry_date'=>sanitize_text_field($_POST['entry_date']??current_time('Y-m-d')),
        'type'=>sanitize_text_field($_POST['type']??'diario'),'concept'=>sanitize_text_field($_POST['concept']??''),
        'reference'=>sanitize_text_field($_POST['reference']??''),'status'=>sanitize_text_field($_POST['status']??'draft'),'created_by'=>$uid);
    $td=0;$tc=0;foreach($lines as $l){$td+=floatval($l['debit']??0);$tc+=floatval($l['credit']??0);}
    if(abs($td-$tc)>0.01)wp_send_json_error(array('msg'=>'La poliza no cuadra. Cargo: $'.number_format($td,2).' Abono: $'.number_format($tc,2)));
    $d['total_debit']=round($td,2);$d['total_credit']=round($tc,2);
    if($id>0){$wpdb->update("{$p}journal_entries",$d,array('id'=>$id,'company_id'=>$cid));$wpdb->delete("{$p}journal_lines",array('entry_id'=>$id));}
    else{$mx=(int)$wpdb->get_var($wpdb->prepare("SELECT MAX(number) FROM {$p}journal_entries WHERE company_id=%d AND type=%s",$cid,$d['type']));$d['number']=$mx+1;$wpdb->insert("{$p}journal_entries",$d);$id=$wpdb->insert_id;}
    foreach($lines as $l){$wpdb->insert("{$p}journal_lines",array('entry_id'=>$id,'account_id'=>intval($l['account_id']??0),'description'=>sanitize_text_field($l['description']??''),'debit'=>round(floatval($l['debit']??0),2),'credit'=>round(floatval($l['credit']??0),2)));}
    wp_send_json_success(array('msg'=>'Poliza guardada.','id'=>$id));
    break;

case 'journal_get':
    $id=intval($_POST['id']??0);
    $en=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$p}journal_entries WHERE id=%d AND company_id=%d",$id,$cid));
    $ln=$wpdb->get_results($wpdb->prepare("SELECT jl.*,ca.code,ca.name as account_name FROM {$p}journal_lines jl LEFT JOIN {$p}chart_accounts ca ON jl.account_id=ca.id WHERE jl.entry_id=%d",$id));
    wp_send_json_success(array('entry'=>$en,'lines'=>$ln));
    break;

case 'trial_balance':
    $df=sanitize_text_field($_POST['date_from']??current_time('Y-01-01'));
    $dt=sanitize_text_field($_POST['date_to']??current_time('Y-m-d'));
    $rw=$wpdb->get_results($wpdb->prepare("SELECT ca.*,COALESCE(SUM(jl.debit),0) as total_debit,COALESCE(SUM(jl.credit),0) as total_credit FROM {$p}chart_accounts ca LEFT JOIN {$p}journal_lines jl ON jl.account_id=ca.id LEFT JOIN {$p}journal_entries je ON jl.entry_id=je.id AND je.status='posted' AND je.entry_date BETWEEN %s AND %s WHERE ca.company_id IN(0,%d) GROUP BY ca.id ORDER BY ca.code",$df,$dt,$cid));
    wp_send_json_success(array('rows'=>$rw));
    break;

/* ═══ BANKS ═══ */
case 'banks_list':
    wp_send_json_success(array('rows'=>$wpdb->get_results($wpdb->prepare("SELECT * FROM {$p}bank_accounts WHERE company_id=%d ORDER BY bank_name",$cid))));
    break;

case 'bank_save':
    $id=intval($_POST['id']??0);
    $d=array('company_id'=>$cid,'bank_name'=>sanitize_text_field($_POST['bank_name']??''),'account_number'=>sanitize_text_field($_POST['account_number']??''),'clabe'=>sanitize_text_field($_POST['clabe']??''),'currency'=>sanitize_text_field($_POST['currency']??'MXN'),'balance'=>floatval($_POST['balance']??0));
    if($id>0)$wpdb->update("{$p}bank_accounts",$d,array('id'=>$id,'company_id'=>$cid));
    else{$wpdb->insert("{$p}bank_accounts",$d);$id=$wpdb->insert_id;}
    wp_send_json_success(array('msg'=>'Banco guardado.','id'=>$id));
    break;

case 'bank_txns_list':
    $bk=intval($_POST['bank_id']??0);$pg=max(1,intval($_POST['page']??1));
    $rw=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$p}bank_transactions WHERE company_id=%d AND bank_account_id=%d ORDER BY date_txn DESC LIMIT 30 OFFSET %d",$cid,$bk,($pg-1)*30));
    wp_send_json_success(array('rows'=>$rw));
    break;

case 'bank_txn_save':
    $d=array('company_id'=>$cid,'bank_account_id'=>intval($_POST['bank_account_id']??0),
        'type'=>sanitize_text_field($_POST['txn_type']??'deposit'),'amount'=>floatval($_POST['amount']??0),
        'date_txn'=>sanitize_text_field($_POST['date_txn']??current_time('Y-m-d')),
        'reference'=>sanitize_text_field($_POST['reference']??''),'description'=>sanitize_text_field($_POST['description']??''));
    $bk=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$p}bank_accounts WHERE id=%d",$d['bank_account_id']));
    if($bk){$nb=($d['type']==='withdrawal'||$d['type']==='commission')?$bk->balance-$d['amount']:$bk->balance+$d['amount'];
        $d['balance_after']=$nb;$wpdb->update("{$p}bank_accounts",array('balance'=>$nb),array('id'=>$bk->id));}
    $wpdb->insert("{$p}bank_transactions",$d);
    wp_send_json_success(array('msg'=>'Movimiento registrado.'));
    break;

/* ═══ EMPLOYEES ═══ */
case 'employees_list':
    $sr=sanitize_text_field($_POST['search']??'');$w=$wpdb->prepare("company_id=%d",$cid);
    if($sr)$w.=$wpdb->prepare(" AND(name LIKE %s OR rfc LIKE %s)","%{$sr}%","%{$sr}%");
    wp_send_json_success(array('rows'=>$wpdb->get_results("SELECT * FROM {$p}employees WHERE {$w} ORDER BY name")));
    break;

case 'employee_save':
    $id=intval($_POST['id']??0);
    $d=array('company_id'=>$cid,'employee_number'=>sanitize_text_field($_POST['employee_number']??''),
        'name'=>sanitize_text_field($_POST['name']??''),'rfc'=>strtoupper(sanitize_text_field($_POST['rfc']??'')),
        'curp'=>strtoupper(sanitize_text_field($_POST['curp']??'')),'nss'=>sanitize_text_field($_POST['nss']??''),
        'email'=>sanitize_email($_POST['email']??''),'phone'=>sanitize_text_field($_POST['phone']??''),
        'department'=>sanitize_text_field($_POST['department']??''),'position'=>sanitize_text_field($_POST['position']??''),
        'hire_date'=>sanitize_text_field($_POST['hire_date']??''),'contract_type'=>sanitize_text_field($_POST['contract_type']??'indefinido'),
        'work_shift'=>sanitize_text_field($_POST['work_shift']??'diurna'),
        'salary_daily'=>floatval($_POST['salary_daily']??0),'salary_monthly'=>floatval($_POST['salary_monthly']??0),
        'bank_name'=>sanitize_text_field($_POST['bank_name']??''),'bank_account'=>sanitize_text_field($_POST['bank_account']??''),
        'bank_clabe'=>sanitize_text_field($_POST['bank_clabe']??''),'status'=>sanitize_text_field($_POST['status']??'active'));
    if(empty($d['name']))wp_send_json_error(array('msg'=>'Nombre obligatorio.'));
    if($d['salary_daily']>0&&$d['salary_monthly']==0)$d['salary_monthly']=round($d['salary_daily']*30.4,2);
    if($d['salary_monthly']>0&&$d['salary_daily']==0)$d['salary_daily']=round($d['salary_monthly']/30.4,2);
    $d['integrated_salary']=round($d['salary_daily']*1.0493,2);
    if($id>0)$wpdb->update("{$p}employees",$d,array('id'=>$id,'company_id'=>$cid));
    else{$wpdb->insert("{$p}employees",$d);$id=$wpdb->insert_id;}
    wp_send_json_success(array('msg'=>'Empleado guardado.','id'=>$id));
    break;

case 'employee_get':
    wp_send_json_success(array('row'=>$wpdb->get_row($wpdb->prepare("SELECT * FROM {$p}employees WHERE id=%d AND company_id=%d",intval($_POST['id']??0),$cid))));
    break;

/* ═══ PAYROLL ═══ */
case 'payroll_calculate':
    $ps=sanitize_text_field($_POST['period_start']??'');$pe=sanitize_text_field($_POST['period_end']??'');
    $pt=sanitize_text_field($_POST['payroll_type']??'quincenal');
    $days=($pt==='quincenal')?15:(($pt==='semanal')?7:30);
    $emps=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$p}employees WHERE company_id=%d AND status='active'",$cid));
    $isr_t=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$p}tax_tables WHERE type='isr_monthly' AND year=%d ORDER BY lower_limit",date('Y')));
    $dets=array();$tg=0;$td=0;$tn=0;$te=0;
    foreach($emps as $e){
        $daily=floatval($e->salary_daily);$gross=round($daily*$days,2);
        $mb=$gross*(30/$days);$isrm=0;
        foreach($isr_t as $r){if($mb>=$r->lower_limit&&$mb<=$r->upper_limit){$isrm=round($r->fixed_fee+(($mb-$r->lower_limit)*$r->rate/100),2);break;}}
        $isr=round($isrm*$days/30,2);
        $sdi=floatval($e->integrated_salary);$imss_e=round($sdi*$days*0.02375,2);
        $tde=$isr+$imss_e;$net=round($gross-$tde,2);
        $imss_p=round($sdi*$days*0.13895,2);$rcv=round($sdi*$days*0.0515,2);
        $inf=round($sdi*$days*0.05,2);$isn=round($gross*0.03,2);$ec=$imss_p+$rcv+$inf+$isn;
        $dets[]=array('employee_id'=>$e->id,'employee_name'=>$e->name,'days_worked'=>$days,
            'salary_base'=>$gross,'gross_pay'=>$gross,'isr'=>$isr,'imss_employee'=>$imss_e,
            'total_deductions'=>round($tde,2),'net_pay'=>$net,
            'imss_employer'=>$imss_p,'rcv'=>$rcv,'infonavit'=>$inf,'payroll_tax'=>$isn,
            'total_employer_cost'=>round($ec,2));
        $tg+=$gross;$td+=$tde;$tn+=$net;$te+=$ec;
    }
    wp_send_json_success(array('details'=>$dets,'summary'=>array('total_gross'=>round($tg,2),'total_deductions'=>round($td,2),'total_net'=>round($tn,2),'total_employer'=>round($te,2)),'period'=>array('start'=>$ps,'end'=>$pe,'type'=>$pt)));
    break;

case 'payroll_save':
    $data=json_decode(stripslashes($_POST['payroll_data']??'{}'),true);
    if(empty($data))wp_send_json_error(array('msg'=>'Sin datos.'));
    $wpdb->insert("{$p}payroll",array('company_id'=>$cid,'period_start'=>$data['period']['start']??'','period_end'=>$data['period']['end']??'','type'=>$data['period']['type']??'quincenal','total_gross'=>$data['summary']['total_gross']??0,'total_deductions'=>$data['summary']['total_deductions']??0,'total_net'=>$data['summary']['total_net']??0,'total_employer'=>$data['summary']['total_employer']??0,'status'=>'calculated','created_by'=>$uid));
    $pid=$wpdb->insert_id;
    foreach(($data['details']??array()) as $det){
        $wpdb->insert("{$p}payroll_details",array('payroll_id'=>$pid,'employee_id'=>$det['employee_id'],'days_worked'=>$det['days_worked'],'salary_base'=>$det['salary_base'],'gross_pay'=>$det['gross_pay'],'isr'=>$det['isr'],'imss_employee'=>$det['imss_employee'],'total_deductions'=>$det['total_deductions'],'net_pay'=>$det['net_pay'],'imss_employer'=>$det['imss_employer'],'rcv'=>$det['rcv'],'infonavit'=>$det['infonavit'],'payroll_tax'=>$det['payroll_tax'],'total_employer_cost'=>$det['total_employer_cost']));
    }
    wp_send_json_success(array('msg'=>'Nomina guardada.','id'=>$pid));
    break;

case 'payroll_list':
    wp_send_json_success(array('rows'=>$wpdb->get_results($wpdb->prepare("SELECT * FROM {$p}payroll WHERE company_id=%d ORDER BY period_start DESC",$cid))));
    break;

/* ═══ FIXED ASSETS ═══ */
case 'assets_list':
    wp_send_json_success(array('rows'=>$wpdb->get_results($wpdb->prepare("SELECT * FROM {$p}fixed_assets WHERE company_id=%d ORDER BY name",$cid))));
    break;

case 'asset_save':
    $id=intval($_POST['id']??0);
    $d=array('company_id'=>$cid,'name'=>sanitize_text_field($_POST['name']??''),'description'=>sanitize_textarea_field($_POST['description']??''),
        'category'=>sanitize_text_field($_POST['category']??''),'acquisition_date'=>sanitize_text_field($_POST['acquisition_date']??''),
        'acquisition_cost'=>floatval($_POST['acquisition_cost']??0),'salvage_value'=>floatval($_POST['salvage_value']??0),
        'useful_life_months'=>intval($_POST['useful_life_months']??60),
        'depreciation_method'=>sanitize_text_field($_POST['depreciation_method']??'straight_line'),
        'location'=>sanitize_text_field($_POST['location']??''),'serial_number'=>sanitize_text_field($_POST['serial_number']??''));
    $d['book_value']=$d['acquisition_cost'];
    if($d['useful_life_months']>0)$d['depreciation_rate']=round(($d['acquisition_cost']-$d['salvage_value'])/$d['useful_life_months'],4);
    if($id>0)$wpdb->update("{$p}fixed_assets",$d,array('id'=>$id,'company_id'=>$cid));
    else{$wpdb->insert("{$p}fixed_assets",$d);$id=$wpdb->insert_id;}
    $wpdb->delete("{$p}depreciation_schedule",array('asset_id'=>$id));
    $md=round(($d['acquisition_cost']-$d['salvage_value'])/max(1,$d['useful_life_months']),2);$acc=0;
    $sd=$d['acquisition_date']?:current_time('Y-m-d');
    for($m=1;$m<=$d['useful_life_months'];$m++){
        $pd=date('Y-m-d',strtotime($sd." +{$m} months"));$acc+=$md;$bv=max(0,$d['acquisition_cost']-$acc);
        $wpdb->insert("{$p}depreciation_schedule",array('asset_id'=>$id,'period_date'=>$pd,'depreciation_amount'=>$md,'accumulated'=>round($acc,2),'book_value'=>round($bv,2)));
    }
    wp_send_json_success(array('msg'=>'Activo fijo guardado.','id'=>$id));
    break;

case 'asset_schedule':
    wp_send_json_success(array('rows'=>$wpdb->get_results($wpdb->prepare("SELECT * FROM {$p}depreciation_schedule WHERE asset_id=%d ORDER BY period_date",intval($_POST['id']??0)))));
    break;

/* ═══ AMORTIZATIONS ═══ */
case 'amortizations_list':
    wp_send_json_success(array('rows'=>$wpdb->get_results($wpdb->prepare("SELECT * FROM {$p}amortizations WHERE company_id=%d ORDER BY name",$cid))));
    break;

case 'amortization_save':
    $id=intval($_POST['id']??0);
    $d=array('company_id'=>$cid,'name'=>sanitize_text_field($_POST['name']??''),'type'=>sanitize_text_field($_POST['amort_type']??'loan'),
        'original_amount'=>floatval($_POST['original_amount']??0),'interest_rate'=>floatval($_POST['interest_rate']??0),
        'term_months'=>intval($_POST['term_months']??12),'start_date'=>sanitize_text_field($_POST['start_date']??''));
    $P=$d['original_amount'];$r=$d['interest_rate']/100/12;$n=$d['term_months'];
    $d['monthly_payment']=($r>0)?round($P*($r*pow(1+$r,$n))/(pow(1+$r,$n)-1),2):round($P/max(1,$n),2);
    $d['balance']=$P;
    if($id>0)$wpdb->update("{$p}amortizations",$d,array('id'=>$id,'company_id'=>$cid));
    else{$wpdb->insert("{$p}amortizations",$d);$id=$wpdb->insert_id;}
    $wpdb->delete("{$p}amortization_schedule",array('amortization_id'=>$id));
    $bal=$P;
    for($i=1;$i<=$n;$i++){
        $int=round($bal*$r,2);$princ=round($d['monthly_payment']-$int,2);$bal=max(0,round($bal-$princ,2));
        $pd=date('Y-m-d',strtotime($d['start_date']." +{$i} months"));
        $wpdb->insert("{$p}amortization_schedule",array('amortization_id'=>$id,'payment_number'=>$i,'payment_date'=>$pd,'payment_amount'=>$d['monthly_payment'],'principal'=>$princ,'interest'=>$int,'balance'=>$bal));
    }
    wp_send_json_success(array('msg'=>'Amortizacion guardada.','id'=>$id));
    break;

case 'amortization_schedule':
    wp_send_json_success(array('rows'=>$wpdb->get_results($wpdb->prepare("SELECT * FROM {$p}amortization_schedule WHERE amortization_id=%d ORDER BY payment_number",intval($_POST['id']??0)))));
    break;

/* ═══ PROJECTS / TASKS ═══ */
case 'projects_list':
    wp_send_json_success(array('rows'=>$wpdb->get_results($wpdb->prepare("SELECT p.*,(SELECT COUNT(*) FROM {$p}tasks t WHERE t.project_id=p.id) as task_count FROM {$p}projects p WHERE p.company_id=%d ORDER BY p.name",$cid))));
    break;

case 'project_save':
    $id=intval($_POST['id']??0);
    $d=array('company_id'=>$cid,'name'=>sanitize_text_field($_POST['name']??''),'description'=>sanitize_textarea_field($_POST['description']??''),
        'client_id'=>intval($_POST['client_id']??0),'budget'=>floatval($_POST['budget']??0),
        'start_date'=>sanitize_text_field($_POST['start_date']??''),'end_date'=>sanitize_text_field($_POST['end_date']??''),
        'status'=>sanitize_text_field($_POST['status']??'planning'));
    if($id>0)$wpdb->update("{$p}projects",$d,array('id'=>$id,'company_id'=>$cid));
    else{$wpdb->insert("{$p}projects",$d);$id=$wpdb->insert_id;}
    wp_send_json_success(array('msg'=>'Proyecto guardado.','id'=>$id));
    break;

case 'tasks_list':
    wp_send_json_success(array('rows'=>$wpdb->get_results($wpdb->prepare("SELECT t.*,u.name as assigned_name FROM {$p}tasks t LEFT JOIN {$p}users u ON t.assigned_to=u.id WHERE t.project_id=%d ORDER BY t.sort_order",intval($_POST['project_id']??0)))));
    break;

case 'task_save':
    $id=intval($_POST['id']??0);
    $d=array('project_id'=>intval($_POST['project_id']??0),'title'=>sanitize_text_field($_POST['title']??''),
        'description'=>sanitize_textarea_field($_POST['description']??''),'assigned_to'=>intval($_POST['assigned_to']??0),
        'priority'=>sanitize_text_field($_POST['priority']??'medium'),'status'=>sanitize_text_field($_POST['status']??'todo'),
        'due_date'=>sanitize_text_field($_POST['due_date']??''));
    if($id>0)$wpdb->update("{$p}tasks",$d,array('id'=>$id));
    else{$wpdb->insert("{$p}tasks",$d);$id=$wpdb->insert_id;}
    wp_send_json_success(array('msg'=>'Tarea guardada.','id'=>$id));
    break;

case 'task_move':
    $wpdb->update("{$p}tasks",array('status'=>sanitize_text_field($_POST['status']??'todo')),array('id'=>intval($_POST['id']??0)));
    wp_send_json_success(array('msg'=>'OK'));
    break;

/* ═══ ISSUERS ═══ */
case 'issuers_list':
    wp_send_json_success(array('rows'=>$wpdb->get_results($wpdb->prepare("SELECT * FROM {$p}issuers WHERE company_id=%d ORDER BY name",$cid))));
    break;

case 'issuer_save':
    $id=intval($_POST['id']??0);
    $d=array('company_id'=>$cid,'name'=>sanitize_text_field($_POST['name']??''),'rfc'=>strtoupper(sanitize_text_field($_POST['rfc']??'')),
        'regimen_fiscal'=>sanitize_text_field($_POST['regimen_fiscal']??''),'address'=>sanitize_textarea_field($_POST['address']??''),
        'zip'=>sanitize_text_field($_POST['zip']??''));
    if($id>0)$wpdb->update("{$p}issuers",$d,array('id'=>$id,'company_id'=>$cid));
    else{$wpdb->insert("{$p}issuers",$d);$id=$wpdb->insert_id;}
    wp_send_json_success(array('msg'=>'Emisor guardado.','id'=>$id));
    break;

/* ═══ USERS ═══ */
case 'users_list':
    wp_send_json_success(array('rows'=>$wpdb->get_results($wpdb->prepare("SELECT id,name,email,role,status,last_login FROM {$p}users WHERE company_id=%d ORDER BY name",$cid))));
    break;

case 'user_save':
    $id=intval($_POST['id']??0);
    $d=array('company_id'=>$cid,'name'=>sanitize_text_field($_POST['name']??''),'email'=>sanitize_email($_POST['email']??''),
        'role'=>sanitize_text_field($_POST['role']??'employee'),'permissions'=>sanitize_text_field($_POST['permissions']??''));
    if(!empty($_POST['new_password']))$d['password_hash']=password_hash($_POST['new_password'],PASSWORD_BCRYPT);
    if($id>0)$wpdb->update("{$p}users",$d,array('id'=>$id,'company_id'=>$cid));
    else{if(empty($_POST['new_password']))wp_send_json_error(array('msg'=>'Contrasena obligatoria.'));
        $d['password_hash']=password_hash($_POST['new_password'],PASSWORD_BCRYPT);$d['email_verified']=1;$d['status']='active';
        $wpdb->insert("{$p}users",$d);$id=$wpdb->insert_id;}
    wp_send_json_success(array('msg'=>'Usuario guardado.','id'=>$id));
    break;

case 'change_password':
    $cu=$_POST['current_password']??'';$np=$_POST['new_password']??'';$np2=$_POST['new_password2']??'';
    $u=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$p}users WHERE id=%d",$uid));
    if(!password_verify($cu,$u->password_hash))wp_send_json_error(array('msg'=>'Contrasena actual incorrecta.'));
    if(strlen($np)<8)wp_send_json_error(array('msg'=>'Minimo 8 caracteres.'));
    if($np!==$np2)wp_send_json_error(array('msg'=>'No coinciden.'));
    $wpdb->update("{$p}users",array('password_hash'=>password_hash($np,PASSWORD_BCRYPT)),array('id'=>$uid));
    wp_send_json_success(array('msg'=>'Contrasena actualizada.'));
    break;

/* ═══ COMPANY ═══ */
case 'company_get':
    wp_send_json_success(array('row'=>$wpdb->get_row($wpdb->prepare("SELECT * FROM {$p}companies WHERE id=%d",$cid))));
    break;

case 'company_save':
    $d=array('name'=>sanitize_text_field($_POST['name']??''),'rfc'=>strtoupper(sanitize_text_field($_POST['rfc']??'')),
        'email'=>sanitize_email($_POST['email']??''),'phone'=>sanitize_text_field($_POST['phone']??''),
        'street'=>sanitize_text_field($_POST['street']??''),'ext_num'=>sanitize_text_field($_POST['ext_num']??''),
        'colony'=>sanitize_text_field($_POST['colony']??''),'city'=>sanitize_text_field($_POST['city']??''),
        'municipality'=>sanitize_text_field($_POST['municipality']??''),'state'=>sanitize_text_field($_POST['state']??''),
        'zip'=>sanitize_text_field($_POST['zip']??''),'regimen_fiscal'=>sanitize_text_field($_POST['regimen_fiscal']??''),
        'fiscal_activity'=>sanitize_text_field($_POST['fiscal_activity']??''));
    $wpdb->update("{$p}companies",$d,array('id'=>$cid));
    wp_send_json_success(array('msg'=>'Empresa actualizada.'));
    break;

/* ═══ FILE UPLOAD ═══ */
case 'upload_file':
    if(empty($_FILES['file']))wp_send_json_error(array('msg'=>'Sin archivo.'));
    $f=$_FILES['file'];$fd=sanitize_text_field($_POST['field']??'logo');
    $ext=strtolower(pathinfo($f['name'],PATHINFO_EXTENSION));
    if(!in_array($ext,array('jpg','jpeg','png','gif','pdf','cer','key')))wp_send_json_error(array('msg'=>'Tipo no permitido.'));
    $dir=mayaerp_uploads_dir().$cid.'/';if(!is_dir($dir))wp_mkdir_p($dir);
    $fn=$fd.'_'.time().'.'.$ext;
    if(!move_uploaded_file($f['tmp_name'],$dir.$fn))wp_send_json_error(array('msg'=>'Error al subir.'));
    $url=mayaerp_uploads_url().$cid.'/'.$fn;
    $ent=sanitize_text_field($_POST['entity']??'company');$eid=intval($_POST['entity_id']??$cid);
    if($ent==='company')$wpdb->update("{$p}companies",array($fd=>$url),array('id'=>$cid));
    elseif($ent==='issuer')$wpdb->update("{$p}issuers",array($fd=>$url),array('id'=>$eid,'company_id'=>$cid));
    wp_send_json_success(array('msg'=>'Archivo subido.','url'=>$url));
    break;

/* ═══ FACTURADOR BRIDGE ═══ */
case 'facturador_access':
    $em=$wpdb->get_var($wpdb->prepare("SELECT email FROM {$p}users WHERE id=%d",$uid));
    $tk=mayaerp_bridge_token($em,$cid);
    wp_send_json_success(array('url'=>home_url('/?factura_maya_bridge='.$tk),'token'=>$tk));
    break;

/* ═══ AI CHAT ═══ */
case 'ai_chat':
    $msg=sanitize_textarea_field($_POST['message']??'');
    if(empty($msg))wp_send_json_error(array('msg'=>'Escribe tu pregunta.'));
    $ak=mayaerp_decrypt(mayaerp_opt('anthropic_api_key'));
    if(empty($ak))wp_send_json_error(array('msg'=>'IA no configurada.'));
    $wpdb->insert("{$p}ai_chats",array('company_id'=>$cid,'user_id'=>$uid,'role'=>'user','message'=>$msg));
    $co=$wpdb->get_row($wpdb->prepare("SELECT name,rfc,fiscal_activity FROM {$p}companies WHERE id=%d",$cid));
    $ss=$wpdb->get_row($wpdb->prepare("SELECT (SELECT COUNT(*) FROM {$p}contacts WHERE company_id=%d AND type='client') as cli,(SELECT COUNT(*) FROM {$p}employees WHERE company_id=%d AND status='active') as emp,(SELECT COALESCE(SUM(total),0) FROM {$p}documents WHERE company_id=%d AND type='invoice' AND MONTH(date_issued)=MONTH(NOW())) as ms",$cid,$cid,$cid));
    $sys="Eres el asistente de MayaERP para {$co->name} (RFC:{$co->rfc}, Giro:{$co->fiscal_activity}). {$ss->cli} clientes, {$ss->emp} empleados, ventas mes: $".number_format($ss->ms,2).". Responde conciso en espanol con recomendaciones accionables.";
    $hist=$wpdb->get_results($wpdb->prepare("SELECT role,message FROM {$p}ai_chats WHERE company_id=%d AND user_id=%d ORDER BY id DESC LIMIT 10",$cid,$uid));
    $msgs=array();foreach(array_reverse($hist) as $h)$msgs[]=array('role'=>$h->role,'content'=>$h->message);
    $resp=wp_remote_post('https://api.anthropic.com/v1/messages',array('timeout'=>30,'headers'=>array('Content-Type'=>'application/json','x-api-key'=>$ak,'anthropic-version'=>'2023-06-01'),'body'=>wp_json_encode(array('model'=>'claude-sonnet-4-20250514','max_tokens'=>1024,'system'=>$sys,'messages'=>$msgs))));
    if(is_wp_error($resp))wp_send_json_error(array('msg'=>'Error de conexion.'));
    $bd=json_decode(wp_remote_retrieve_body($resp),true);$rp=$bd['content'][0]['text']??'Error al procesar.';
    $wpdb->insert("{$p}ai_chats",array('company_id'=>$cid,'user_id'=>$uid,'role'=>'assistant','message'=>$rp));
    wp_send_json_success(array('reply'=>$rp));
    break;

/* ═══ GLOBAL SEARCH ═══ */
case 'global_search':
    $q=sanitize_text_field($_POST['q']??'');
    if(strlen($q)<2)wp_send_json_success(array('results'=>array()));
    $lk="%{$q}%";$res=array();
    foreach($wpdb->get_results($wpdb->prepare("SELECT id,name,type,rfc FROM {$p}contacts WHERE company_id=%d AND(name LIKE %s OR rfc LIKE %s) LIMIT 5",$cid,$lk,$lk)) as $r)$res[]=array('type'=>'contact','id'=>$r->id,'title'=>$r->name,'sub'=>$r->type);
    foreach($wpdb->get_results($wpdb->prepare("SELECT id,name,sku FROM {$p}products WHERE company_id=%d AND(name LIKE %s OR sku LIKE %s) LIMIT 5",$cid,$lk,$lk)) as $r)$res[]=array('type'=>'product','id'=>$r->id,'title'=>$r->name,'sub'=>$r->sku);
    foreach($wpdb->get_results($wpdb->prepare("SELECT id,type,folio,contact_name FROM {$p}documents WHERE company_id=%d AND(contact_name LIKE %s) LIMIT 5",$cid,$lk)) as $r)$res[]=array('type'=>'document','id'=>$r->id,'title'=>$r->type.' #'.$r->folio,'sub'=>$r->contact_name);
    wp_send_json_success(array('results'=>$res));
    break;

/* ═══ REPORTS ═══ */
case 'report_financial':
    $df=sanitize_text_field($_POST['date_from']??current_time('Y-01-01'));$dt=sanitize_text_field($_POST['date_to']??current_time('Y-m-d'));
    $rev=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(jl.credit-jl.debit),0) FROM {$p}journal_lines jl JOIN {$p}journal_entries je ON jl.entry_id=je.id JOIN {$p}chart_accounts ca ON jl.account_id=ca.id WHERE je.company_id=%d AND je.status='posted' AND je.entry_date BETWEEN %s AND %s AND ca.type='revenue'",$cid,$df,$dt));
    $exp=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(jl.debit-jl.credit),0) FROM {$p}journal_lines jl JOIN {$p}journal_entries je ON jl.entry_id=je.id JOIN {$p}chart_accounts ca ON jl.account_id=ca.id WHERE je.company_id=%d AND je.status='posted' AND je.entry_date BETWEEN %s AND %s AND ca.type IN('expense')",$cid,$df,$dt));
    $cos=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(jl.debit-jl.credit),0) FROM {$p}journal_lines jl JOIN {$p}journal_entries je ON jl.entry_id=je.id JOIN {$p}chart_accounts ca ON jl.account_id=ca.id WHERE je.company_id=%d AND je.status='posted' AND je.entry_date BETWEEN %s AND %s AND ca.code LIKE '5%%'",$cid,$df,$dt));
    $ast=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(jl.debit-jl.credit),0) FROM {$p}journal_lines jl JOIN {$p}journal_entries je ON jl.entry_id=je.id JOIN {$p}chart_accounts ca ON jl.account_id=ca.id WHERE je.company_id=%d AND je.status='posted' AND je.entry_date<=%s AND ca.type='asset'",$cid,$dt));
    $lia=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(jl.credit-jl.debit),0) FROM {$p}journal_lines jl JOIN {$p}journal_entries je ON jl.entry_id=je.id JOIN {$p}chart_accounts ca ON jl.account_id=ca.id WHERE je.company_id=%d AND je.status='posted' AND je.entry_date<=%s AND ca.type='liability'",$cid,$dt));
    $equ=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(jl.credit-jl.debit),0) FROM {$p}journal_lines jl JOIN {$p}journal_entries je ON jl.entry_id=je.id JOIN {$p}chart_accounts ca ON jl.account_id=ca.id WHERE je.company_id=%d AND je.status='posted' AND je.entry_date<=%s AND ca.type='equity'",$cid,$dt));
    wp_send_json_success(array('income_statement'=>array('revenue'=>$rev,'costs'=>$cos,'gross_profit'=>$rev-$cos,'expenses'=>$exp,'net_income'=>$rev-$cos-$exp),'balance_sheet'=>array('assets'=>$ast,'liabilities'=>$lia,'equity'=>$equ),'period'=>array('from'=>$df,'to'=>$dt)));
    break;

case 'report_sales':
    $df=sanitize_text_field($_POST['date_from']??current_time('Y-m-01'));$dt=sanitize_text_field($_POST['date_to']??current_time('Y-m-d'));
    $rw=$wpdb->get_results($wpdb->prepare("SELECT contact_name,COUNT(*) as qty,SUM(subtotal) as subtotal,SUM(tax_iva) as iva,SUM(total) as total,SUM(amount_paid) as paid FROM {$p}documents WHERE company_id=%d AND type='invoice' AND date_issued BETWEEN %s AND %s GROUP BY contact_id ORDER BY total DESC",$cid,$df,$dt));
    $top=$wpdb->get_results($wpdb->prepare("SELECT di.description,SUM(di.quantity) as qty,SUM(di.total) as total FROM {$p}document_items di JOIN {$p}documents d ON di.document_id=d.id WHERE d.company_id=%d AND d.type='invoice' AND d.date_issued BETWEEN %s AND %s GROUP BY di.product_id ORDER BY total DESC LIMIT 10",$cid,$df,$dt));
    wp_send_json_success(array('by_client'=>$rw,'top_products'=>$top));
    break;

/* ═══ NOTIFICATIONS ═══ */
case 'notification_read':
    $id=intval($_POST['id']??0);
    if($id===0)$wpdb->query($wpdb->prepare("UPDATE {$p}notifications SET is_read=1 WHERE company_id=%d AND(user_id=%d OR user_id=0)",$cid,$uid));
    else $wpdb->update("{$p}notifications",array('is_read'=>1),array('id'=>$id));
    wp_send_json_success(array('msg'=>'OK'));
    break;

/* ═══ WAREHOUSES ═══ */
case 'warehouses_list':
    wp_send_json_success(array('rows'=>$wpdb->get_results($wpdb->prepare("SELECT * FROM {$p}warehouses WHERE company_id=%d ORDER BY name",$cid))));
    break;

case 'warehouse_save':
    $id=intval($_POST['id']??0);
    $d=array('company_id'=>$cid,'name'=>sanitize_text_field($_POST['name']??''),'address'=>sanitize_text_field($_POST['address']??''),'manager'=>sanitize_text_field($_POST['manager']??''));
    if($id>0)$wpdb->update("{$p}warehouses",$d,array('id'=>$id));
    else{$wpdb->insert("{$p}warehouses",$d);$id=$wpdb->insert_id;}
    wp_send_json_success(array('msg'=>'Almacen guardado.','id'=>$id));
    break;

case 'check_rfc':
    $rfc=strtoupper(sanitize_text_field($_POST['rfc']??''));
    wp_send_json_success(array('valid'=>preg_match('/^[A-Z&]{3,4}\d{6}[A-Z0-9]{3}$/',$rfc),'rfc'=>$rfc));
    break;

default:
    wp_send_json_error(array('msg'=>'Accion no reconocida: '.$act));
}

<?php
if(!defined('ABSPATH'))exit;
$ajax_url=admin_url('admin-ajax.php');
$ts_key=get_option('mayaerp_turnstile_site_key','');
if($ts_key)$ts_key=function_exists('mayaerp_decrypt')?mayaerp_decrypt($ts_key):$ts_key;
$reset_token=isset($_GET['mayaerp_reset'])?sanitize_text_field(wp_unslash($_GET['mayaerp_reset'])):'';
$reset_email=isset($_GET['email'])?sanitize_email(wp_unslash($_GET['email'])):'';
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<title>MayaERP — Sistema Empresarial Inteligente</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;0,9..40,800;1,9..40,400&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<?php if($ts_key): ?>
<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
<?php endif; ?>
<style>
:root{
--jade:#1a5c38;--jade-dark:#0d3320;--jade-light:#2d8a56;--jade-pale:#dcfce7;--jade-glow:#86efac;
--gold:#c8a84e;--gold-soft:#fef3c7;
--bg:#f0f4f1;--bg-card:#ffffff;--bg-sidebar:#0a1f14;--bg-sidebar-hover:rgba(134,239,172,0.08);
--bg-sidebar-active:rgba(26,92,56,0.25);--bg-input:#f8faf9;--bg-overlay:rgba(10,31,20,0.6);
--border:#d4ddd8;--border-focus:#1a5c38;
--text:#0f1f17;--text-sec:#4a6355;--text-muted:#8a9f93;--text-sidebar:#a3c4b3;--text-sidebar-active:#fff;
--accent:var(--jade);--accent-hover:var(--jade-dark);
--success:#10b981;--success-soft:#d1fae5;--warning:#f59e0b;--warning-soft:#fef3c7;
--danger:#ef4444;--danger-soft:#fee2e2;--info:#06b6d4;--info-soft:#cffafe;
--shadow-sm:0 1px 2px rgba(0,0,0,0.04);--shadow:0 1px 3px rgba(0,0,0,0.06),0 1px 2px rgba(0,0,0,0.04);
--shadow-md:0 4px 6px -1px rgba(0,0,0,0.07),0 2px 4px -2px rgba(0,0,0,0.05);
--shadow-lg:0 10px 25px -3px rgba(0,0,0,0.08);--shadow-xl:0 20px 50px -5px rgba(0,0,0,0.12);
--radius-sm:6px;--radius:10px;--radius-lg:14px;--radius-xl:20px;
--sidebar-w:260px;--topbar-h:60px;
--font:'DM Sans',system-ui,sans-serif;--font-mono:'JetBrains Mono',monospace;
--transition:0.2s cubic-bezier(0.4,0,0.2,1);
}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box}
html,body{height:100%;overflow:hidden}
body{font-family:var(--font);background:var(--bg);color:var(--text);font-size:14px;line-height:1.6;-webkit-font-smoothing:antialiased}
a{color:var(--jade);text-decoration:none}
input,select,textarea,button{font-family:inherit;font-size:inherit}

/* ═══ AUTH SCREENS ═══ */
.auth-wrap{display:flex;align-items:center;justify-content:center;min-height:100vh;background:linear-gradient(135deg,#0a1f14 0%,#0d3320 40%,#1a5c38 100%);overflow-y:auto;padding:20px}
.auth-card{background:#fff;border-radius:var(--radius-xl);padding:40px;width:100%;max-width:480px;box-shadow:var(--shadow-xl);position:relative;overflow:hidden}
.auth-card::before{content:'';position:absolute;top:0;left:0;right:0;height:4px;background:linear-gradient(90deg,var(--jade),var(--gold),var(--jade))}
.auth-logo{text-align:center;margin-bottom:24px}
.auth-logo h1{font-size:28px;font-weight:800;color:var(--jade-dark);letter-spacing:-0.5px}
.auth-logo p{color:var(--text-sec);font-size:13px;margin-top:4px}
.auth-logo .brand-icon{width:56px;height:56px;background:linear-gradient(135deg,var(--jade-dark),var(--jade));border-radius:16px;display:inline-flex;align-items:center;justify-content:center;color:#fff;font-size:24px;margin-bottom:12px;box-shadow:0 4px 12px rgba(26,92,56,0.3)}
.form-group{margin-bottom:16px;position:relative}
.form-group label{display:block;font-size:13px;font-weight:600;color:var(--text);margin-bottom:5px}
.form-group input,.form-group select,.form-group textarea{width:100%;padding:10px 14px;border:1.5px solid var(--border);border-radius:var(--radius);background:var(--bg-input);color:var(--text);transition:var(--transition);outline:none}
.form-group input:focus,.form-group select:focus,.form-group textarea:focus{border-color:var(--jade);box-shadow:0 0 0 3px rgba(26,92,56,0.1)}
.form-group .eye-toggle{position:absolute;right:12px;top:34px;cursor:pointer;color:var(--text-muted);font-size:16px}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:10px 20px;border:none;border-radius:var(--radius);font-weight:600;font-size:14px;cursor:pointer;transition:var(--transition);line-height:1.4}
.btn-primary{background:linear-gradient(135deg,var(--jade-dark),var(--jade));color:#fff;box-shadow:0 2px 8px rgba(26,92,56,0.3)}
.btn-primary:hover{background:linear-gradient(135deg,var(--jade),var(--jade-light));transform:translateY(-1px);box-shadow:0 4px 12px rgba(26,92,56,0.4)}
.btn-full{width:100%;padding:12px}
.btn-outline{background:transparent;border:1.5px solid var(--border);color:var(--text)}
.btn-outline:hover{border-color:var(--jade);color:var(--jade);background:var(--jade-pale)}
.btn-danger{background:var(--danger);color:#fff}
.btn-sm{padding:6px 12px;font-size:12px}
.btn-icon{width:36px;height:36px;padding:0;border-radius:var(--radius-sm)}
.btn:disabled{opacity:0.5;cursor:not-allowed}
.auth-footer{text-align:center;margin-top:20px;font-size:13px;color:var(--text-sec)}
.auth-footer a{color:var(--jade);font-weight:600}
.auth-tabs{display:flex;border-bottom:2px solid var(--border);margin-bottom:24px}
.auth-tab{flex:1;padding:10px;text-align:center;font-weight:600;color:var(--text-muted);cursor:pointer;border-bottom:2px solid transparent;margin-bottom:-2px;transition:var(--transition)}
.auth-tab.active{color:var(--jade);border-color:var(--jade)}
.verify-inputs{display:flex;gap:8px;justify-content:center;margin:20px 0}
.verify-inputs input{width:48px;height:56px;text-align:center;font-size:24px;font-weight:700;font-family:var(--font-mono);border:2px solid var(--border);border-radius:var(--radius);background:var(--bg-input);transition:var(--transition)}
.verify-inputs input:focus{border-color:var(--jade);box-shadow:0 0 0 3px rgba(26,92,56,0.1)}
.alert{padding:12px 16px;border-radius:var(--radius);font-size:13px;margin-bottom:16px;display:flex;align-items:center;gap:8px}
.alert-success{background:var(--success-soft);color:#065f46;border:1px solid #a7f3d0}
.alert-error{background:var(--danger-soft);color:#991b1b;border:1px solid #fca5a5}
.alert-warning{background:var(--warning-soft);color:#92400e;border:1px solid #fde68a}
.alert-info{background:var(--info-soft);color:#155e75;border:1px solid #a5f3fc}

/* ═══ MAIN LAYOUT ═══ */
#app-main{display:none;height:100vh}
.app-layout{display:flex;height:100%}
.sidebar{width:var(--sidebar-w);background:var(--bg-sidebar);display:flex;flex-direction:column;transition:var(--transition);position:relative;z-index:50;flex-shrink:0}
.sidebar-header{padding:20px;display:flex;align-items:center;gap:12px;border-bottom:1px solid rgba(255,255,255,0.06)}
.sidebar-header .s-icon{width:40px;height:40px;background:linear-gradient(135deg,var(--jade),var(--jade-light));border-radius:12px;display:flex;align-items:center;justify-content:center;color:#fff;font-size:15px;font-weight:800}
.sidebar-header .s-text h2{font-size:16px;font-weight:700;color:#fff;line-height:1.2}
.sidebar-header .s-text span{font-size:11px;color:var(--text-sidebar);opacity:0.7}
.sidebar-nav{flex:1;overflow-y:auto;padding:12px 0}
.sidebar-nav::-webkit-scrollbar{width:4px}
.sidebar-nav::-webkit-scrollbar-thumb{background:rgba(255,255,255,0.1);border-radius:4px}
.nav-section{padding:0 16px;margin-bottom:4px}
.nav-section-title{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:1.2px;color:rgba(163,196,179,0.5);padding:12px 8px 6px}
.nav-item{display:flex;align-items:center;gap:12px;padding:9px 14px;border-radius:var(--radius);color:var(--text-sidebar);cursor:pointer;transition:var(--transition);font-size:13px;font-weight:500;margin-bottom:2px}
.nav-item i{width:18px;text-align:center;font-size:14px;opacity:0.7}
.nav-item:hover{background:var(--bg-sidebar-hover);color:#fff}
.nav-item.active{background:var(--bg-sidebar-active);color:var(--jade-glow);font-weight:600}
.nav-item.active i{opacity:1;color:var(--jade-glow)}
.nav-item .badge{margin-left:auto;background:var(--danger);color:#fff;font-size:10px;padding:2px 6px;border-radius:10px;font-weight:700}
.sidebar-footer{padding:16px;border-top:1px solid rgba(255,255,255,0.06)}
.sidebar-user{display:flex;align-items:center;gap:10px;padding:8px;border-radius:var(--radius);cursor:pointer;transition:var(--transition)}
.sidebar-user:hover{background:var(--bg-sidebar-hover)}
.sidebar-user .avatar{width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,var(--jade),var(--gold));display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:14px}
.sidebar-user .u-info{flex:1}
.sidebar-user .u-info .u-name{font-size:13px;font-weight:600;color:#fff}
.sidebar-user .u-info .u-role{font-size:11px;color:var(--text-sidebar);opacity:0.7}

/* ═══ MAIN CONTENT ═══ */
.main-area{flex:1;display:flex;flex-direction:column;overflow:hidden;min-width:0}
.topbar{height:var(--topbar-h);background:var(--bg-card);border-bottom:1px solid var(--border);display:flex;align-items:center;padding:0 24px;gap:16px;flex-shrink:0}
.topbar .menu-toggle{display:none;width:36px;height:36px;border:none;background:none;font-size:18px;color:var(--text);cursor:pointer;border-radius:var(--radius-sm)}
.topbar .search-bar{flex:1;max-width:400px;position:relative}
.topbar .search-bar input{width:100%;padding:8px 14px 8px 36px;border:1.5px solid var(--border);border-radius:var(--radius);background:var(--bg);font-size:13px}
.topbar .search-bar input:focus{border-color:var(--jade);background:#fff}
.topbar .search-bar i{position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--text-muted);font-size:13px}
.topbar .search-bar kbd{position:absolute;right:10px;top:50%;transform:translateY(-50%);background:var(--bg);border:1px solid var(--border);padding:1px 6px;border-radius:4px;font-size:10px;color:var(--text-muted);font-family:var(--font-mono)}
.topbar-actions{display:flex;align-items:center;gap:8px;margin-left:auto}
.topbar-actions .t-btn{width:36px;height:36px;border:none;background:none;border-radius:var(--radius-sm);color:var(--text-sec);cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:16px;position:relative;transition:var(--transition)}
.topbar-actions .t-btn:hover{background:var(--jade-pale);color:var(--jade)}
.topbar-actions .t-btn .notif-dot{position:absolute;top:6px;right:6px;width:8px;height:8px;background:var(--danger);border-radius:50%;border:2px solid var(--bg-card)}
.plan-badge{padding:4px 10px;border-radius:20px;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px}
.plan-trial{background:var(--warning-soft);color:#92400e}
.plan-active{background:var(--success-soft);color:#065f46}

.content-area{flex:1;overflow-y:auto;padding:24px}
.content-area::-webkit-scrollbar{width:6px}
.content-area::-webkit-scrollbar-thumb{background:var(--border);border-radius:6px}

/* ═══ PAGE HEADER ═══ */
.page-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;flex-wrap:wrap;gap:12px}
.page-header h1{font-size:22px;font-weight:700;color:var(--text)}
.page-header .subtitle{font-size:13px;color:var(--text-sec);margin-top:2px}

/* ═══ CARDS / STATS ═══ */
.stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;margin-bottom:24px}
.stat-card{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius-lg);padding:20px;transition:var(--transition)}
.stat-card:hover{box-shadow:var(--shadow-md);border-color:var(--jade-pale)}
.stat-card .sc-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:12px}
.stat-card .sc-icon{width:40px;height:40px;border-radius:var(--radius);display:flex;align-items:center;justify-content:center;font-size:16px}
.stat-card .sc-icon.green{background:var(--jade-pale);color:var(--jade)}
.stat-card .sc-icon.blue{background:var(--info-soft);color:var(--info)}
.stat-card .sc-icon.orange{background:var(--warning-soft);color:var(--warning)}
.stat-card .sc-icon.red{background:var(--danger-soft);color:var(--danger)}
.stat-card .sc-icon.gold{background:var(--gold-soft);color:var(--gold)}
.stat-card .sc-value{font-size:26px;font-weight:800;color:var(--text);line-height:1}
.stat-card .sc-label{font-size:12px;color:var(--text-sec);margin-top:4px;font-weight:500}
.stat-card .sc-change{font-size:11px;font-weight:600;margin-top:6px;display:inline-block;padding:2px 8px;border-radius:10px}
.sc-change.up{background:var(--success-soft);color:#065f46}
.sc-change.down{background:var(--danger-soft);color:#991b1b}

.card{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius-lg);overflow:hidden}
.card-header{padding:16px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between}
.card-header h3{font-size:15px;font-weight:700}
.card-body{padding:20px}
.card-body.no-pad{padding:0}

.grid-2{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.grid-3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px}

/* ═══ TABLE ═══ */
.table-wrap{overflow-x:auto}
table.data-table{width:100%;border-collapse:collapse;font-size:13px}
table.data-table thead th{background:var(--bg);padding:10px 14px;text-align:left;font-weight:600;color:var(--text-sec);font-size:12px;text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid var(--border);white-space:nowrap}
table.data-table tbody td{padding:10px 14px;border-bottom:1px solid var(--border);vertical-align:middle}
table.data-table tbody tr:hover{background:rgba(26,92,56,0.02)}
table.data-table tbody tr:last-child td{border-bottom:none}

.status-badge{display:inline-flex;align-items:center;gap:4px;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:600}
.st-paid{background:var(--success-soft);color:#065f46}
.st-draft{background:var(--bg);color:var(--text-sec)}
.st-sent{background:var(--info-soft);color:#155e75}
.st-overdue{background:var(--danger-soft);color:#991b1b}
.st-partial{background:var(--warning-soft);color:#92400e}
.st-active{background:var(--success-soft);color:#065f46}
.st-inactive{background:var(--bg);color:var(--text-muted)}
.st-cancelled{background:var(--danger-soft);color:#991b1b}

.pagination{display:flex;align-items:center;justify-content:center;gap:4px;padding:16px}
.pagination button{width:32px;height:32px;border:1px solid var(--border);background:#fff;border-radius:var(--radius-sm);cursor:pointer;font-size:12px;font-weight:600;transition:var(--transition)}
.pagination button:hover{border-color:var(--jade);color:var(--jade)}
.pagination button.active{background:var(--jade);color:#fff;border-color:var(--jade)}

/* ═══ MODAL ═══ */
.modal-overlay{display:none;position:fixed;inset:0;background:var(--bg-overlay);z-index:1000;align-items:center;justify-content:center;padding:20px;backdrop-filter:blur(4px)}
.modal-overlay.show{display:flex}
.modal{background:#fff;border-radius:var(--radius-xl);width:100%;max-width:640px;max-height:90vh;display:flex;flex-direction:column;box-shadow:var(--shadow-xl);overflow:hidden}
.modal.modal-lg{max-width:900px}
.modal.modal-xl{max-width:1100px}
.modal-head{padding:20px 24px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;flex-shrink:0}
.modal-head h2{font-size:18px;font-weight:700}
.modal-head .close-modal{width:32px;height:32px;border:none;background:none;border-radius:var(--radius-sm);cursor:pointer;font-size:18px;color:var(--text-muted);display:flex;align-items:center;justify-content:center}
.modal-head .close-modal:hover{background:var(--danger-soft);color:var(--danger)}
.modal-body{padding:24px;overflow-y:auto;flex:1}
.modal-foot{padding:16px 24px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:8px;flex-shrink:0}

/* ═══ TERMS MODAL (Membretada) ═══ */
.terms-modal .modal{max-width:750px;max-height:95vh}
.terms-content{background:#fff;padding:40px;font-size:13px;line-height:1.8;color:var(--text)}
.terms-letterhead{text-align:center;padding:24px 0 20px;border-bottom:3px solid var(--jade);margin-bottom:24px}
.terms-letterhead .tl-icon{width:60px;height:60px;background:linear-gradient(135deg,var(--jade-dark),var(--jade));border-radius:16px;display:inline-flex;align-items:center;justify-content:center;color:#fff;font-size:28px;margin-bottom:8px}
.terms-letterhead h2{font-size:20px;font-weight:800;color:var(--jade-dark)}
.terms-letterhead p{font-size:12px;color:var(--text-sec)}
.terms-content h3{font-size:16px;font-weight:700;color:var(--jade-dark);margin:20px 0 8px;border-left:3px solid var(--jade);padding-left:12px}
.terms-content h4{font-size:14px;font-weight:600;color:var(--text);margin:12px 0 6px}
.terms-footer{text-align:center;padding-top:20px;margin-top:24px;border-top:3px solid var(--jade);font-size:11px;color:var(--text-muted)}
.terms-check{display:flex;align-items:flex-start;gap:10px;padding:12px;border-radius:var(--radius);border:1px solid var(--border);margin-bottom:10px;cursor:pointer;transition:var(--transition)}
.terms-check:hover{border-color:var(--jade);background:var(--jade-pale)}
.terms-check input{margin-top:2px;accent-color:var(--jade);width:18px;height:18px;flex-shrink:0}
.terms-check .tc-text{font-size:13px;color:var(--text)}
.terms-check .tc-text strong{color:var(--jade-dark)}
.tts-controls{display:flex;align-items:center;gap:8px;margin-bottom:16px;padding:10px;background:var(--bg);border-radius:var(--radius)}
.tts-controls button{padding:6px 14px;border:1px solid var(--border);background:#fff;border-radius:var(--radius-sm);cursor:pointer;font-size:12px;font-weight:600;transition:var(--transition)}
.tts-controls button:hover{border-color:var(--jade);color:var(--jade)}
.tts-controls button.playing{background:var(--jade);color:#fff;border-color:var(--jade)}

/* ═══ CHART ═══ */
.chart-container{position:relative;height:280px;width:100%}

/* ═══ AI CHAT ═══ */
.ai-fab{position:fixed;bottom:24px;right:24px;z-index:900;width:52px;height:52px;border-radius:50%;background:linear-gradient(135deg,var(--jade-dark),var(--jade));color:#fff;border:none;cursor:pointer;box-shadow:0 4px 16px rgba(26,92,56,0.4);display:flex;align-items:center;justify-content:center;font-size:22px;transition:var(--transition)}
.ai-fab:hover{transform:scale(1.1);box-shadow:0 6px 24px rgba(26,92,56,0.5)}
.ai-panel{position:fixed;bottom:88px;right:24px;z-index:900;width:380px;max-height:520px;background:#fff;border-radius:var(--radius-xl);box-shadow:var(--shadow-xl);border:1px solid var(--border);display:none;flex-direction:column;overflow:hidden}
.ai-panel.show{display:flex}
.ai-panel-head{padding:16px;background:linear-gradient(135deg,var(--jade-dark),var(--jade));color:#fff;display:flex;align-items:center;gap:10px}
.ai-panel-head h4{font-weight:700;flex:1}
.ai-panel-head button{background:none;border:none;color:rgba(255,255,255,0.7);cursor:pointer;font-size:16px}
.ai-messages{flex:1;overflow-y:auto;padding:16px;max-height:340px}
.ai-msg{margin-bottom:12px;display:flex;gap:8px}
.ai-msg.user{flex-direction:row-reverse}
.ai-msg .msg-bubble{max-width:80%;padding:10px 14px;border-radius:14px;font-size:13px;line-height:1.5}
.ai-msg.user .msg-bubble{background:var(--jade);color:#fff;border-bottom-right-radius:4px}
.ai-msg.assistant .msg-bubble{background:var(--bg);color:var(--text);border-bottom-left-radius:4px}
.ai-input{padding:12px;border-top:1px solid var(--border);display:flex;gap:8px}
.ai-input input{flex:1;padding:8px 12px;border:1.5px solid var(--border);border-radius:var(--radius);font-size:13px}
.ai-input button{width:36px;height:36px;border:none;background:var(--jade);color:#fff;border-radius:var(--radius);cursor:pointer;font-size:14px}

/* ═══ WA BUTTON ═══ */
.wa-fab{position:fixed;bottom:88px;right:24px;z-index:899;width:48px;height:48px;border-radius:50%;background:#25d366;color:#fff;border:none;cursor:pointer;box-shadow:0 4px 12px rgba(37,211,102,0.4);display:none;align-items:center;justify-content:center;font-size:22px;transition:var(--transition)}
.wa-fab:hover{transform:scale(1.1)}

/* ═══ SEARCH OVERLAY ═══ */
.search-overlay{display:none;position:fixed;inset:0;background:var(--bg-overlay);z-index:2000;align-items:flex-start;justify-content:center;padding-top:15vh;backdrop-filter:blur(4px)}
.search-overlay.show{display:flex}
.search-box{width:100%;max-width:560px;background:#fff;border-radius:var(--radius-xl);box-shadow:var(--shadow-xl);overflow:hidden}
.search-box input{width:100%;padding:16px 20px 16px 48px;border:none;font-size:16px;outline:none;background:none}
.search-box .search-icon{position:absolute;left:18px;top:18px;color:var(--text-muted);font-size:18px}
.search-results{max-height:300px;overflow-y:auto;border-top:1px solid var(--border)}
.search-result{display:flex;align-items:center;gap:12px;padding:12px 20px;cursor:pointer;transition:var(--transition)}
.search-result:hover{background:var(--jade-pale)}
.search-result .sr-icon{width:32px;height:32px;border-radius:var(--radius-sm);display:flex;align-items:center;justify-content:center;font-size:13px}
.search-result .sr-text{flex:1}
.search-result .sr-text .sr-title{font-weight:600;font-size:13px}
.search-result .sr-text .sr-sub{font-size:11px;color:var(--text-muted)}

/* ═══ EMPTY STATE ═══ */
.empty-state{text-align:center;padding:60px 20px}
.empty-state i{font-size:48px;color:var(--border);margin-bottom:16px}
.empty-state h3{font-size:18px;font-weight:700;color:var(--text-sec);margin-bottom:8px}
.empty-state p{font-size:13px;color:var(--text-muted);margin-bottom:20px}

/* ═══ TABS ═══ */
.tabs{display:flex;border-bottom:2px solid var(--border);margin-bottom:20px;gap:4px}
.tab{padding:10px 18px;font-weight:600;font-size:13px;color:var(--text-muted);cursor:pointer;border-bottom:2px solid transparent;margin-bottom:-2px;transition:var(--transition);border-radius:var(--radius-sm) var(--radius-sm) 0 0}
.tab:hover{color:var(--text);background:var(--bg)}
.tab.active{color:var(--jade);border-color:var(--jade)}

.tag{display:inline-flex;align-items:center;gap:4px;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600;background:var(--jade-pale);color:var(--jade)}

/* ═══ LOADING ═══ */
.spinner{display:inline-block;width:20px;height:20px;border:2px solid var(--border);border-top-color:var(--jade);border-radius:50%;animation:spin 0.6s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.loading-overlay{position:absolute;inset:0;background:rgba(255,255,255,0.8);display:flex;align-items:center;justify-content:center;z-index:10;border-radius:inherit}

/* ═══ RESPONSIVE ═══ */
@media(max-width:768px){
    .sidebar{position:fixed;left:-280px;height:100%;z-index:100;transition:var(--transition)}
    .sidebar.open{left:0}
    .topbar .menu-toggle{display:flex}
    .form-row{grid-template-columns:1fr}
    .stats-grid{grid-template-columns:1fr 1fr}
    .grid-2,.grid-3{grid-template-columns:1fr}
    .ai-panel{width:calc(100vw - 32px);right:16px;bottom:80px}
    .content-area{padding:16px}
    .modal{max-width:calc(100vw - 32px)}
}
@media(max-width:480px){
    .stats-grid{grid-template-columns:1fr}
    .auth-card{padding:24px;margin:8px}
}
</style>
</head>
<body>

<!-- ════ AUTH SCREEN ════ -->
<div id="auth-screen" class="auth-wrap">
<div class="auth-card">
    <div class="auth-logo">
        <div class="brand-icon"><i class="fas fa-cubes"></i></div>
        <h1>MayaERP</h1>
        <p>Yaxtun Soluciones Digitales</p>
    </div>
    <div id="alert-auth"></div>
    <div class="auth-tabs">
        <div class="auth-tab active" onclick="showAuthTab('login')">Iniciar Sesion</div>
        <div class="auth-tab" onclick="showAuthTab('register')">Crear Cuenta</div>
    </div>

    <!-- LOGIN -->
    <div id="tab-login">
        <div class="form-group"><label>Correo electronico</label><input type="email" id="login-email" placeholder="tu@empresa.com"></div>
        <div class="form-group"><label>Contrasena</label><input type="password" id="login-pass" placeholder="••••••••"><span class="eye-toggle" onclick="toggleEye(this)"><i class="fas fa-eye"></i></span></div>
        <?php if($ts_key): ?><div class="cf-turnstile" data-sitekey="<?php echo esc_attr($ts_key); ?>" data-callback="onTurnstileLogin" id="ts-login"></div><?php endif; ?>
        <button class="btn btn-primary btn-full" onclick="doLogin()" id="btn-login"><i class="fas fa-arrow-right"></i> Iniciar Sesion</button>
        <div class="auth-footer"><a href="#" onclick="showAuthTab('forgot');return false">Olvide mi contrasena</a></div>
    </div>

    <!-- REGISTER -->
    <div id="tab-register" style="display:none">
        <div class="form-group"><label>Nombre / Razon Social *</label><input type="text" id="reg-name" placeholder="Mi Empresa S.A. de C.V."></div>
        <div class="form-row">
            <div class="form-group"><label>RFC</label><input type="text" id="reg-rfc" placeholder="XAXX010101000" maxlength="13" style="text-transform:uppercase"></div>
            <div class="form-group"><label>CURP</label><input type="text" id="reg-curp" placeholder="CURP18" maxlength="18" style="text-transform:uppercase"></div>
        </div>
        <div class="form-group"><label>Correo electronico *</label><input type="email" id="reg-email" placeholder="tu@empresa.com"></div>
        <div class="form-row">
            <div class="form-group"><label>Telefono</label><input type="tel" id="reg-phone" placeholder="33 1234 5678"></div>
            <div class="form-group"><label>Giro economico</label><input type="text" id="reg-giro" placeholder="Comercio, Servicios..."></div>
        </div>
        <div class="form-row">
            <div class="form-group"><label>Contrasena *</label><input type="password" id="reg-pass" placeholder="Min. 8 caracteres"><span class="eye-toggle" onclick="toggleEye(this)"><i class="fas fa-eye"></i></span></div>
            <div class="form-group"><label>Confirmar *</label><input type="password" id="reg-pass2" placeholder="Repetir contrasena"><span class="eye-toggle" onclick="toggleEye(this)"><i class="fas fa-eye"></i></span></div>
        </div>
        <div class="form-group"><label><input type="checkbox" id="reg-multi" style="accent-color:var(--jade)"> Plan Multi-Emisor (despachos contables)</label></div>
        <?php if($ts_key): ?><div class="cf-turnstile" data-sitekey="<?php echo esc_attr($ts_key); ?>" data-callback="onTurnstileReg" id="ts-reg"></div><?php endif; ?>
        <button class="btn btn-primary btn-full" onclick="doRegister()" id="btn-register"><i class="fas fa-user-plus"></i> Crear Cuenta</button>
    </div>

    <!-- FORGOT -->
    <div id="tab-forgot" style="display:none">
        <p style="font-size:13px;color:var(--text-sec);margin-bottom:16px">Ingresa tu correo y te enviaremos instrucciones para restablecer tu contrasena.</p>
        <div class="form-group"><label>Correo electronico</label><input type="email" id="forgot-email" placeholder="tu@empresa.com"></div>
        <button class="btn btn-primary btn-full" onclick="doForgot()"><i class="fas fa-paper-plane"></i> Enviar</button>
        <div class="auth-footer"><a href="#" onclick="showAuthTab('login');return false">Volver al inicio</a></div>
    </div>

    <!-- RESET -->
    <div id="tab-reset" style="display:none">
        <p style="font-size:13px;color:var(--text-sec);margin-bottom:16px">Crea tu nueva contrasena.</p>
        <div class="form-group"><label>Nueva contrasena</label><input type="password" id="reset-pass" placeholder="Min. 8 caracteres"><span class="eye-toggle" onclick="toggleEye(this)"><i class="fas fa-eye"></i></span></div>
        <div class="form-group"><label>Confirmar contrasena</label><input type="password" id="reset-pass2" placeholder="Repetir contrasena"><span class="eye-toggle" onclick="toggleEye(this)"><i class="fas fa-eye"></i></span></div>
        <button class="btn btn-primary btn-full" onclick="doReset()" id="btn-reset"><i class="fas fa-key"></i> Restablecer contrasena</button>
        <div class="auth-footer"><a href="#" onclick="showAuthTab('login');return false">Volver al inicio</a></div>
    </div>

    <!-- VERIFY -->
    <div id="tab-verify" style="display:none">
        <div style="text-align:center">
            <div style="width:64px;height:64px;background:var(--jade-pale);border-radius:50%;display:inline-flex;align-items:center;justify-content:center;margin-bottom:16px"><i class="fas fa-envelope-open-text" style="font-size:28px;color:var(--jade)"></i></div>
            <h2 style="font-size:20px;font-weight:700;margin-bottom:8px">Verifica tu correo</h2>
            <p style="font-size:13px;color:var(--text-sec);margin-bottom:4px">Enviamos un codigo de 6 digitos a:</p>
            <p style="font-weight:700;color:var(--jade);margin-bottom:16px" id="verify-email-display"></p>
        </div>
        <div class="verify-inputs">
            <input type="text" maxlength="1" class="v-digit" data-idx="0" oninput="onDigitInput(this)" onkeydown="onDigitKey(event,this)">
            <input type="text" maxlength="1" class="v-digit" data-idx="1" oninput="onDigitInput(this)" onkeydown="onDigitKey(event,this)">
            <input type="text" maxlength="1" class="v-digit" data-idx="2" oninput="onDigitInput(this)" onkeydown="onDigitKey(event,this)">
            <input type="text" maxlength="1" class="v-digit" data-idx="3" oninput="onDigitInput(this)" onkeydown="onDigitKey(event,this)">
            <input type="text" maxlength="1" class="v-digit" data-idx="4" oninput="onDigitInput(this)" onkeydown="onDigitKey(event,this)">
            <input type="text" maxlength="1" class="v-digit" data-idx="5" oninput="onDigitInput(this)" onkeydown="onDigitKey(event,this)">
        </div>
        <button class="btn btn-primary btn-full" onclick="doVerify()" id="btn-verify"><i class="fas fa-check-circle"></i> Verificar</button>
        <div class="auth-footer" style="margin-top:16px">
            <span id="verify-timer" style="color:var(--text-muted)"></span><br>
            <a href="#" onclick="doResend();return false">Reenviar codigo</a>
        </div>
    </div>
</div>
</div>

<!-- ════ MAIN APP ════ -->
<div id="app-main">
<div class="app-layout">

<!-- SIDEBAR -->
<aside class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="s-icon">FM</div>
        <div class="s-text"><h2>MayaERP</h2><span id="company-name-side">Empresa</span></div>
    </div>
    <nav class="sidebar-nav">
        <div class="nav-section">
            <div class="nav-section-title">Principal</div>
            <div class="nav-item active" data-page="dashboard"><i class="fas fa-th-large"></i> Dashboard</div>
            <div class="nav-item" data-page="crm"><i class="fas fa-users"></i> CRM / Contactos</div>
            <div class="nav-item" data-page="products"><i class="fas fa-box-open"></i> Inventario</div>
        </div>
        <div class="nav-section">
            <div class="nav-section-title">Operaciones</div>
            <div class="nav-item" data-page="sales"><i class="fas fa-file-invoice-dollar"></i> Ventas</div>
            <div class="nav-item" data-page="purchases"><i class="fas fa-cart-shopping"></i> Compras</div>
            <div class="nav-item" data-page="payments"><i class="fas fa-money-check-alt"></i> Pagos</div>
        </div>
        <div class="nav-section">
            <div class="nav-section-title">Finanzas</div>
            <div class="nav-item" data-page="accounting"><i class="fas fa-scale-balanced"></i> Contabilidad</div>
            <div class="nav-item" data-page="banks"><i class="fas fa-building-columns"></i> Bancos</div>
            <div class="nav-item" data-page="payroll"><i class="fas fa-money-bills"></i> Nomina</div>
            <div class="nav-item" data-page="assets"><i class="fas fa-landmark"></i> Activos Fijos</div>
            <div class="nav-item" data-page="amortizations"><i class="fas fa-chart-line"></i> Amortizaciones</div>
        </div>
        <div class="nav-section">
            <div class="nav-section-title">Gestion</div>
            <div class="nav-item" data-page="projects"><i class="fas fa-diagram-project"></i> Proyectos</div>
            <div class="nav-item" data-page="employees"><i class="fas fa-id-badge"></i> RRHH</div>
            <div class="nav-item" data-page="reports"><i class="fas fa-chart-pie"></i> Reportes</div>
        </div>
        <div class="nav-section" id="nav-multi" style="display:none">
            <div class="nav-section-title">Multi-Emisor</div>
            <div class="nav-item" data-page="issuers"><i class="fas fa-stamp"></i> Emisores</div>
        </div>
        <div class="nav-section">
            <div class="nav-section-title">Sistema</div>
            <div class="nav-item" data-page="facturador"><i class="fas fa-file-signature"></i> Facturador CFDI</div>
            <div class="nav-item" data-page="users"><i class="fas fa-user-gear"></i> Usuarios</div>
            <div class="nav-item" data-page="settings"><i class="fas fa-gear"></i> Configuracion</div>
        </div>
    </nav>
    <div class="sidebar-footer">
        <div class="sidebar-user" onclick="toggleUserMenu()">
            <div class="avatar" id="user-avatar">AJ</div>
            <div class="u-info"><div class="u-name" id="user-name-side">Usuario</div><div class="u-role" id="user-role-side">owner</div></div>
            <i class="fas fa-ellipsis-vertical" style="color:var(--text-sidebar)"></i>
        </div>
    </div>
</aside>

<!-- MAIN -->
<div class="main-area">
    <div class="topbar">
        <button class="menu-toggle" onclick="toggleSidebar()"><i class="fas fa-bars"></i></button>
        <div class="search-bar">
            <i class="fas fa-search"></i>
            <input type="text" placeholder="Buscar clientes, productos, facturas..." id="global-search-input" onfocus="openSearch()">
            <kbd>Ctrl+K</kbd>
        </div>
        <div class="topbar-actions">
            <span class="plan-badge plan-trial" id="plan-badge">PRUEBA</span>
            <button class="t-btn" onclick="loadNotifications()" title="Notificaciones"><i class="fas fa-bell"></i><span class="notif-dot" id="notif-dot" style="display:none"></span></button>
            <button class="t-btn" onclick="navigateTo('facturador')" title="Facturador CFDI"><i class="fas fa-file-signature"></i></button>
            <button class="t-btn" onclick="doLogout()" title="Cerrar sesion"><i class="fas fa-right-from-bracket"></i></button>
        </div>
    </div>
    <div class="content-area" id="content-area">
        <!-- Dynamic content loaded here -->
    </div>
</div>

</div>
</div>

<!-- ════ TERMS MODAL ════ -->
<div class="modal-overlay terms-modal" id="terms-modal">
<div class="modal modal-lg">
    <div class="modal-head">
        <h2><i class="fas fa-shield-halved" style="color:var(--jade);margin-right:8px"></i> Terminos y Politicas</h2>
    </div>
    <div class="modal-body" id="terms-body">
        <div class="tts-controls">
            <button onclick="toggleTTS()" id="tts-btn"><i class="fas fa-volume-high"></i> Leer en voz alta</button>
            <button onclick="pauseTTS()" id="tts-pause" style="display:none"><i class="fas fa-pause"></i> Pausar</button>
            <span style="flex:1"></span>
            <span style="font-size:11px;color:var(--text-muted)">Documento oficial - Yaxtun Soluciones Digitales</span>
        </div>
        <div class="terms-content" id="terms-text">
            <div class="terms-letterhead">
                <div class="tl-icon"><i class="fas fa-cubes"></i></div>
                <h2>YAXTUN</h2>
                <p>Soluciones que Impulsan tu Futuro</p>
                <p style="font-size:11px;color:var(--text-muted)">www.facturamaya.com.mx</p>
            </div>

            <h3>I. TERMINOS Y CONDICIONES DE USO</h3>
            <h4>1.1 Objeto del Servicio</h4>
            <p>MayaERP es un sistema de planificacion de recursos empresariales (ERP) ofrecido como Software como Servicio (SaaS) por Yaxtun Soluciones Digitales. El servicio incluye modulos de contabilidad, facturacion, inventarios, nomina, tesoreria, CRM y reportes financieros, conforme al plan contratado.</p>
            <p><strong>Base Legal:</strong> Ley Federal de Proteccion al Consumidor, Art. 76 BIS.</p>

            <h4>1.2 Aceptacion</h4>
            <p>Al registrarse y utilizar MayaERP, el usuario acepta integramente estos terminos. Si no esta de acuerdo, debera abstenerse de utilizar la plataforma.</p>

            <h4>1.3 Cuenta y Acceso</h4>
            <p>El usuario es responsable de mantener la confidencialidad de sus credenciales. Toda actividad realizada bajo su cuenta se considerara realizada por el mismo. El servicio incluye un periodo de prueba gratuito de 10 dias con 100 timbres.</p>

            <h4>1.4 Planes y Pagos</h4>
            <p>Los planes de suscripcion (Individual, Empresarial, Multi-Emisor) se facturan mensualmente. Los timbres adicionales se cobran conforme a las tarifas vigentes publicadas en la plataforma.</p>
            <p><strong>Base Legal:</strong> Codigo de Comercio, Art. 78-96 (obligaciones mercantiles).</p>

            <h4>1.5 Limitaciones de Responsabilidad</h4>
            <p>MayaERP no sera responsable por: (a) perdidas derivadas del uso incorrecto del sistema; (b) interrupciones por mantenimiento programado; (c) decisiones fiscales o contables tomadas con base en los datos del sistema. El usuario es el unico responsable de su informacion fiscal.</p>

            <h4>1.6 Propiedad Intelectual</h4>
            <p>Todo el software, diseno, marca, logotipos y contenido de MayaERP son propiedad exclusiva de Yaxtun Soluciones Digitales. Queda prohibida la reproduccion total o parcial sin autorizacion expresa.</p>
            <p><strong>Base Legal:</strong> Ley Federal del Derecho de Autor, Art. 101-114.</p>

            <h3>II. POLITICA DE PRIVACIDAD</h3>
            <h4>2.1 Datos Recopilados</h4>
            <p>Recopilamos: nombre o razon social, RFC, CURP, correo electronico, telefono, domicilio fiscal, actividad economica, datos bancarios (para operaciones), informacion de empleados (para nomina) y registros de uso del sistema.</p>
            <p><strong>Base Legal:</strong> Ley Federal de Proteccion de Datos Personales en Posesion de los Particulares (LFPDPPP), Art. 15-16.</p>

            <h4>2.2 Finalidad del Tratamiento</h4>
            <p>Los datos se utilizan para: (a) prestacion del servicio contratado; (b) emision de CFDI ante el SAT; (c) calculo de nomina e impuestos; (d) generacion de reportes financieros; (e) comunicacion sobre el servicio; (f) mejora del sistema mediante inteligencia artificial.</p>

            <h4>2.3 Seguridad</h4>
            <p>Implementamos cifrado AES-256 para datos sensibles, conexiones HTTPS/TLS, respaldos automaticos y control de acceso basado en roles. Los sellos digitales y FIEL se almacenan cifrados.</p>
            <p><strong>Base Legal:</strong> LFPDPPP, Art. 19 (medidas de seguridad).</p>

            <h4>2.4 Derechos ARCO</h4>
            <p>El titular puede ejercer sus derechos de Acceso, Rectificacion, Cancelacion y Oposicion enviando solicitud a soporte@facturamaya.com.mx. Se atendera en un plazo maximo de 20 dias habiles.</p>
            <p><strong>Base Legal:</strong> LFPDPPP, Art. 28-35.</p>

            <h4>2.5 Transferencia de Datos</h4>
            <p>Los datos podran compartirse con: (a) SAT, para cumplimiento de obligaciones fiscales; (b) IMSS/INFONAVIT, para tramites de seguridad social; (c) proveedores de timbrado de CFDI. No se venden ni comparten datos con terceros para fines comerciales.</p>

            <h3>III. POLITICA DE CONFIDENCIALIDAD Y USO DE DATOS</h3>
            <h4>3.1 Compromiso de Confidencialidad</h4>
            <p>Yaxtun se compromete a mantener estricta confidencialidad sobre toda informacion financiera, fiscal, laboral y operativa del usuario. Todo nuestro personal esta sujeto a acuerdos de confidencialidad.</p>
            <p><strong>Base Legal:</strong> Codigo Civil Federal, Art. 1910-1934 (responsabilidad civil).</p>

            <h4>3.2 Inteligencia Artificial y Deteccion Antifraude</h4>
            <p>El sistema puede utilizar inteligencia artificial para: (a) asistencia contable y fiscal; (b) deteccion de inconsistencias financieras; (c) alertas de operaciones inusuales (antifraude). La funcion antifraude notificara automaticamente al gerente o responsable designado sobre operaciones que requieran atencion.</p>
            <p><strong>Al habilitar la deteccion antifraude, el usuario acepta que:</strong> se analizaran automaticamente las transacciones registradas; se generaran alertas sobre posibles inconsistencias; las notificaciones se enviaran al personal autorizado dentro de la empresa.</p>

            <h4>3.3 Retencion de Datos</h4>
            <p>Los datos se conservan durante la vigencia del servicio mas 5 anos adicionales conforme a obligaciones fiscales. Al terminar, el usuario podra solicitar la eliminacion total de sus datos.</p>
            <p><strong>Base Legal:</strong> Codigo Fiscal de la Federacion, Art. 30 (conservacion de contabilidad).</p>

            <div class="terms-footer">
                <p><strong>Yaxtun Soluciones Digitales</strong><br>www.facturamaya.com.mx | contacto@facturamaya.com.mx<br>Ultima actualizacion: Mayo 2026</p>
            </div>
        </div>
        <div style="margin-top:24px">
            <div class="terms-check" onclick="this.querySelector('input').click()">
                <input type="checkbox" id="chk-terms"><div class="tc-text"><strong>Acepto los Terminos y Condiciones</strong> de uso del servicio MayaERP.</div>
            </div>
            <div class="terms-check" onclick="this.querySelector('input').click()">
                <input type="checkbox" id="chk-privacy"><div class="tc-text"><strong>Acepto la Politica de Privacidad</strong> y el tratamiento de mis datos personales conforme a la LFPDPPP.</div>
            </div>
            <div class="terms-check" onclick="this.querySelector('input').click()">
                <input type="checkbox" id="chk-confidentiality"><div class="tc-text"><strong>Acepto la Politica de Confidencialidad</strong> y uso de datos del sistema.</div>
            </div>
            <div class="terms-check" onclick="this.querySelector('input').click()">
                <input type="checkbox" id="chk-antifraud"><div class="tc-text"><strong>Habilitar deteccion antifraude</strong> — el sistema analizara transacciones y notificara inconsistencias al responsable. <em>(Opcional)</em></div>
            </div>
        </div>
    </div>
    <div class="modal-foot">
        <span id="terms-error" style="color:var(--danger);font-size:13px;margin-right:auto"></span>
        <button class="btn btn-primary" onclick="acceptTerms()"><i class="fas fa-check"></i> Aceptar y Continuar</button>
    </div>
</div>
</div>

<!-- ════ GENERIC MODAL ════ -->
<div class="modal-overlay" id="modal-generic">
<div class="modal" id="modal-generic-inner">
    <div class="modal-head"><h2 id="modal-title">Modal</h2><button class="close-modal" onclick="closeModal('modal-generic')">&times;</button></div>
    <div class="modal-body" id="modal-body-content"></div>
    <div class="modal-foot" id="modal-footer"></div>
</div>
</div>

<!-- ════ SEARCH OVERLAY ════ -->
<div class="search-overlay" id="search-overlay" onclick="if(event.target===this)closeSearch()">
<div class="search-box" style="position:relative">
    <i class="search-icon fas fa-search"></i>
    <input type="text" id="global-search" placeholder="Buscar clientes, productos, facturas..." oninput="doGlobalSearch(this.value)">
    <div class="search-results" id="search-results"></div>
</div>
</div>

<!-- ════ AI FAB ════ -->
<button class="ai-fab" onclick="toggleAI()" title="Asistente IA" id="ai-fab" style="display:none"><i class="fas fa-robot"></i></button>
<div class="ai-panel" id="ai-panel">
    <div class="ai-panel-head">
        <i class="fas fa-robot"></i><h4>Asistente MayaERP</h4>
        <button onclick="toggleAI()"><i class="fas fa-times"></i></button>
    </div>
    <div class="ai-messages" id="ai-messages">
        <div class="ai-msg assistant"><div class="msg-bubble">Hola, soy tu asistente empresarial. Preguntame sobre contabilidad, fiscal, nomina, ventas o la situacion actual de tu empresa.</div></div>
    </div>
    <div class="ai-input">
        <input type="text" id="ai-input" placeholder="Escribe tu pregunta..." onkeypress="if(event.key==='Enter')sendAI()">
        <button onclick="sendAI()"><i class="fas fa-paper-plane"></i></button>
    </div>
</div>

<!-- ════ WHATSAPP ════ -->
<a class="wa-fab" id="wa-fab" href="https://wa.me/<?php echo MAYAERP_WA; ?>" target="_blank" title="WhatsApp Soporte"><i class="fab fa-whatsapp"></i></a>

<script>
const AJAX='<?php echo $ajax_url; ?>';
const RESET_TOKEN='<?php echo esc_js($reset_token); ?>';
const RESET_EMAIL='<?php echo esc_js($reset_email); ?>';
let NONCE='',USER=null,COMPANY=null,PAGE='dashboard',ttsUtterance=null,turnstileLogin='',turnstileReg='';
const $=s=>document.querySelector(s),$$=s=>document.querySelectorAll(s);

function onTurnstileLogin(t){turnstileLogin=t}
function onTurnstileReg(t){turnstileReg=t}

/* ═══ HELPERS ═══ */
function api(act,data={},isFile=false){
    const fd=isFile?data:new FormData();
    if(!isFile){fd.append('action','mayaerp');fd.append('act',act);fd.append('nonce',NONCE);Object.entries(data).forEach(([k,v])=>fd.append(k,typeof v==='object'?JSON.stringify(v):v));}
    else{fd.append('action','mayaerp');fd.append('act',act);fd.append('nonce',NONCE);}
    return fetch(AJAX,{method:'POST',body:fd}).then(r=>r.json());
}
function showAlert(id,msg,type='error'){
    const el=$(id);if(!el)return;
    el.innerHTML=`<div class="alert alert-${type}"><i class="fas fa-${type==='success'?'check-circle':type==='error'?'exclamation-circle':'info-circle'}"></i>${msg}</div>`;
    if(type==='success')setTimeout(()=>el.innerHTML='',4000);
}
function fmt(n){return new Intl.NumberFormat('es-MX',{style:'currency',currency:'MXN'}).format(n||0)}
function fmtN(n){return new Intl.NumberFormat('es-MX').format(n||0)}
function fmtDate(d){if(!d)return'-';return new Date(d+'T00:00:00').toLocaleDateString('es-MX',{day:'2-digit',month:'short',year:'numeric'})}
function toggleEye(el){const inp=el.parentElement.querySelector('input');const ic=el.querySelector('i');if(inp.type==='password'){inp.type='text';ic.className='fas fa-eye-slash'}else{inp.type='password';ic.className='fas fa-eye'}}
function closeModal(id){$(('#'+id)).classList.remove('show')}
function openModal(id,title,body,footer=''){
    if(id==='modal-generic'){$('#modal-title').textContent=title;$('#modal-body-content').innerHTML=body;$('#modal-footer').innerHTML=footer;$('#modal-generic').classList.add('show');}
    else{$('#'+id).classList.add('show');}
}
function statusBadge(s){const m={paid:'st-paid',draft:'st-draft',sent:'st-sent',overdue:'st-overdue',partial:'st-partial',active:'st-active',inactive:'st-inactive',cancelled:'st-cancelled',pending:'st-draft',posted:'st-paid',calculated:'st-sent',approved:'st-paid',completed:'st-paid',planning:'st-draft',paused:'st-partial'};return `<span class="status-badge ${m[s]||'st-draft'}">${s}</span>`}
function toggleSidebar(){$('#sidebar').classList.toggle('open')}

/* ═══ AUTH ═══ */
function showAuthTab(tab){
    $$('.auth-tab').forEach((t,i)=>t.classList.toggle('active',i===(tab==='login'?0:1)));
    ['login','register','forgot','verify','reset'].forEach(t=>$('#tab-'+t).style.display=t===tab?'block':'none');
    $('#alert-auth').innerHTML='';
}
function doLogin(){
    const em=$('#login-email').value,pw=$('#login-pass').value;
    if(!em||!pw)return showAlert('#alert-auth','Completa todos los campos.');
    $('#btn-login').disabled=true;
    const fd=new FormData();fd.append('action','mayaerp');fd.append('act','login');fd.append('email',em);fd.append('password',pw);fd.append('turnstile_token',turnstileLogin);
    fetch(AJAX,{method:'POST',body:fd}).then(r=>r.json()).then(r=>{
        $('#btn-login').disabled=false;
        if(!r.success){
            if(r.data?.code==='NEED_VERIFY'){pendingEmail=r.data.email;$('#verify-email-display').textContent=r.data.email;showAuthTab('verify');startVerifyTimer();return;}
            showAlert('#alert-auth',r.data?.msg||'Error');return;
        }
        NONCE=r.data.nonce;USER=r.data.user;COMPANY=r.data.company;
        if(r.data.needs_terms){showApp();$('#terms-modal').classList.add('show');}
        else{showApp();loadDashboard();}
    }).catch(()=>{$('#btn-login').disabled=false;showAlert('#alert-auth','Error de conexion.');});
}
let pendingEmail='';
function doRegister(){
    const d={name:$('#reg-name').value,email:$('#reg-email').value,rfc:$('#reg-rfc').value,curp:$('#reg-curp').value,phone:$('#reg-phone').value,giro:$('#reg-giro').value,password:$('#reg-pass').value,password2:$('#reg-pass2').value,is_multi_emisor:$('#reg-multi').checked?1:0,turnstile_token:turnstileReg};
    if(!d.name||!d.email||!d.password)return showAlert('#alert-auth','Campos obligatorios marcados con *');
    $('#btn-register').disabled=true;
    const fd=new FormData();fd.append('action','mayaerp');fd.append('act','register');Object.entries(d).forEach(([k,v])=>fd.append(k,v));
    fetch(AJAX,{method:'POST',body:fd}).then(r=>r.json()).then(r=>{
        $('#btn-register').disabled=false;
        if(!r.success)return showAlert('#alert-auth',r.data?.msg||'Error');
        pendingEmail=r.data.email;$('#verify-email-display').textContent=pendingEmail;showAuthTab('verify');startVerifyTimer();
        showAlert('#alert-auth',r.data.msg,'success');
    }).catch(()=>{$('#btn-register').disabled=false;showAlert('#alert-auth','Error de conexion.');});
}
function doVerify(){
    const digits=[...$$('.v-digit')].map(i=>i.value).join('');
    if(digits.length<6)return showAlert('#alert-auth','Ingresa los 6 digitos.');
    const fd=new FormData();fd.append('action','mayaerp');fd.append('act','verify_email');fd.append('email',pendingEmail);fd.append('code',digits);
    fetch(AJAX,{method:'POST',body:fd}).then(r=>r.json()).then(r=>{
        if(!r.success)return showAlert('#alert-auth',r.data?.msg||'Error');
        NONCE=r.data.nonce;USER=r.data.user;COMPANY=r.data.company||{};showApp();
        $('#terms-modal').classList.add('show');
    });
}
function doResend(){
    const fd=new FormData();fd.append('action','mayaerp');fd.append('act','resend_code');fd.append('email',pendingEmail);
    fetch(AJAX,{method:'POST',body:fd}).then(r=>r.json()).then(r=>{showAlert('#alert-auth',r.data?.msg||'Codigo enviado',r.success?'success':'error');if(r.success)startVerifyTimer();});
}
function doForgot(){
    const em=$('#forgot-email').value;if(!em)return showAlert('#alert-auth','Ingresa tu correo.');
    const fd=new FormData();fd.append('action','mayaerp');fd.append('act','forgot_password');fd.append('email',em);fd.append('app_url',location.origin+location.pathname);
    fetch(AJAX,{method:'POST',body:fd}).then(r=>r.json()).then(r=>showAlert('#alert-auth',r.data?.msg||'','success'));
}
function doReset(){
    const pw=$('#reset-pass').value,pw2=$('#reset-pass2').value;
    if(pw.length<8)return showAlert('#alert-auth','Minimo 8 caracteres.');
    if(pw!==pw2)return showAlert('#alert-auth','Las contrasenas no coinciden.');
    $('#btn-reset').disabled=true;
    const fd=new FormData();fd.append('action','mayaerp');fd.append('act','reset_password');fd.append('token',RESET_TOKEN);fd.append('email',RESET_EMAIL);fd.append('password',pw);fd.append('password2',pw2);
    fetch(AJAX,{method:'POST',body:fd}).then(r=>r.json()).then(r=>{
        $('#btn-reset').disabled=false;
        if(!r.success)return showAlert('#alert-auth',r.data?.msg||'Error');
        showAlert('#alert-auth','Contrasena actualizada. Ya puedes iniciar sesion.','success');
        if(RESET_EMAIL)$('#login-email').value=RESET_EMAIL;
        history.replaceState(null,'',location.origin+location.pathname);
        setTimeout(()=>showAuthTab('login'),1200);
    }).catch(()=>{$('#btn-reset').disabled=false;showAlert('#alert-auth','Error de conexion.');});
}
function startVerifyTimer(){let s=120;const el=$('#verify-timer');const iv=setInterval(()=>{s--;const m=Math.floor(s/60),ss=s%60;el.textContent=`Expira en ${m}:${ss.toString().padStart(2,'0')}`;if(s<=0){clearInterval(iv);el.textContent='Codigo expirado';}},1000);}
function onDigitInput(el){const v=el.value.replace(/\D/g,'');el.value=v;if(v&&el.dataset.idx<5){const next=el.nextElementSibling;if(next)next.focus();}}
function onDigitKey(e,el){if(e.key==='Backspace'&&!el.value&&el.dataset.idx>0){const prev=el.previousElementSibling;if(prev){prev.focus();prev.value='';}}}
function doLogout(){api('logout').then(()=>{NONCE='';USER=null;COMPANY=null;$('#app-main').style.display='none';$('#auth-screen').style.display='flex';$('#ai-fab').style.display='none';$('#wa-fab').style.display='none';showAuthTab('login');})}

/* ═══ TERMS ═══ */
function acceptTerms(){
    const t=$('#chk-terms').checked,p=$('#chk-privacy').checked,c=$('#chk-confidentiality').checked,a=$('#chk-antifraud').checked;
    if(!t||!p){$('#terms-error').textContent='Debes aceptar los Terminos y la Politica de Privacidad.';return;}
    api('accept_terms',{terms:t?1:0,privacy:p?1:0,confidentiality:c?1:0,antifraud:a?1:0}).then(r=>{
        if(r.success){closeModal('terms-modal');if(COMPANY)COMPANY.antifraud=r.data.antifraud;loadDashboard();}
        else{$('#terms-error').textContent=r.data?.msg||'Error';}
    });
}
function toggleTTS(){
    if(!('speechSynthesis' in window))return alert('Tu navegador no soporta lectura en voz alta.');
    const text=$('#terms-text').textContent;
    if(speechSynthesis.speaking){speechSynthesis.cancel();$('#tts-btn').innerHTML='<i class="fas fa-volume-high"></i> Leer en voz alta';$('#tts-pause').style.display='none';return;}
    ttsUtterance=new SpeechSynthesisUtterance(text);ttsUtterance.lang='es-MX';ttsUtterance.rate=0.9;
    ttsUtterance.onend=()=>{$('#tts-btn').innerHTML='<i class="fas fa-volume-high"></i> Leer en voz alta';$('#tts-pause').style.display='none';};
    speechSynthesis.speak(ttsUtterance);$('#tts-btn').innerHTML='<i class="fas fa-stop"></i> Detener';$('#tts-btn').classList.add('playing');$('#tts-pause').style.display='inline-flex';
}
function pauseTTS(){if(speechSynthesis.paused){speechSynthesis.resume();$('#tts-pause').innerHTML='<i class="fas fa-pause"></i> Pausar';}else{speechSynthesis.pause();$('#tts-pause').innerHTML='<i class="fas fa-play"></i> Continuar';}}

/* ═══ APP INIT ═══ */
function showApp(){
    $('#auth-screen').style.display='none';$('#app-main').style.display='block';
    if(USER){$('#user-name-side').textContent=USER.name;$('#user-role-side').textContent=USER.role;$('#user-avatar').textContent=(USER.name||'U').substring(0,2).toUpperCase();}
    if(COMPANY){$('#company-name-side').textContent=COMPANY.name||'Empresa';if(COMPANY.is_multi==='1'||COMPANY.is_multi===1)$('#nav-multi').style.display='block';
        const pb=$('#plan-badge');pb.textContent=COMPANY.plan==='trial'?'PRUEBA':COMPANY.plan?.toUpperCase()||'ACTIVO';pb.className='plan-badge '+(COMPANY.plan==='trial'?'plan-trial':'plan-active');}
    if(USER?.role==='owner'||USER?.role==='admin'){$('#wa-fab').style.display='flex';$('#ai-fab').style.display='flex';}
    if(USER?.role==='manager')$('#ai-fab').style.display='flex';
}

/* ═══ NAVIGATION ═══ */
function navigateTo(page){
    PAGE=page;$$('.nav-item').forEach(n=>n.classList.toggle('active',n.dataset.page===page));
    if(window.innerWidth<768)$('#sidebar').classList.remove('open');
    const loaders={dashboard:loadDashboard,crm:loadCRM,products:loadProducts,sales:()=>loadDocs('invoice','Ventas'),purchases:()=>loadDocs('purchase_order','Compras'),payments:loadPayments,accounting:loadAccounting,banks:loadBanks,payroll:loadPayroll,employees:loadEmployees,assets:loadAssets,amortizations:loadAmortizations,projects:loadProjects,reports:loadReports,issuers:loadIssuers,facturador:loadFacturador,users:loadUsers,settings:loadSettings};
    (loaders[page]||loadDashboard)();
}
$$('.nav-item').forEach(n=>n.addEventListener('click',()=>navigateTo(n.dataset.page)));

/* ═══ DASHBOARD ═══ */
function loadDashboard(){
    const c=$('#content-area');c.innerHTML='<div style="text-align:center;padding:60px"><div class="spinner"></div></div>';
    api('dashboard_stats').then(r=>{
        if(!r.success)return c.innerHTML=`<div class="alert alert-error">${r.data?.msg||'Error'}</div>`;
        const d=r.data;USER=d.user;COMPANY=d.company;
        c.innerHTML=`
        <div class="page-header"><div><h1>Dashboard</h1><div class="subtitle">Bienvenido, ${d.user?.name||'Usuario'}</div></div>
        <div style="display:flex;gap:8px"><button class="btn btn-outline btn-sm" onclick="navigateTo('reports')"><i class="fas fa-chart-pie"></i> Reportes</button>
        <button class="btn btn-primary btn-sm" onclick="navigateTo('sales')"><i class="fas fa-plus"></i> Nueva Venta</button></div></div>
        <div class="stats-grid">
            <div class="stat-card"><div class="sc-top"><div class="sc-icon green"><i class="fas fa-dollar-sign"></i></div></div><div class="sc-value">${fmt(d.month_sales)}</div><div class="sc-label">Ventas del Mes</div></div>
            <div class="stat-card"><div class="sc-top"><div class="sc-icon blue"><i class="fas fa-file-invoice"></i></div></div><div class="sc-value">${d.pending_invoices}</div><div class="sc-label">Facturas Pendientes</div><div class="sc-label">${fmt(d.pending_amount)} por cobrar</div></div>
            <div class="stat-card"><div class="sc-top"><div class="sc-icon gold"><i class="fas fa-building-columns"></i></div></div><div class="sc-value">${fmt(d.bank_balance)}</div><div class="sc-label">Saldo Bancario</div></div>
            <div class="stat-card"><div class="sc-top"><div class="sc-icon orange"><i class="fas fa-users"></i></div></div><div class="sc-value">${d.total_clients}</div><div class="sc-label">Clientes Activos</div></div>
            <div class="stat-card"><div class="sc-top"><div class="sc-icon green"><i class="fas fa-box-open"></i></div></div><div class="sc-value">${d.total_products}</div><div class="sc-label">Productos</div>${d.low_stock>0?`<div class="sc-change down">${d.low_stock} stock bajo</div>`:''}</div>
            <div class="stat-card"><div class="sc-top"><div class="sc-icon blue"><i class="fas fa-id-badge"></i></div></div><div class="sc-value">${d.total_employees}</div><div class="sc-label">Empleados</div></div>
        </div>
        <div class="grid-2">
            <div class="card"><div class="card-header"><h3><i class="fas fa-chart-area" style="color:var(--jade);margin-right:8px"></i>Ventas vs Gastos</h3></div><div class="card-body"><div class="chart-container"><canvas id="chart-sales"></canvas></div></div></div>
            <div class="card"><div class="card-header"><h3><i class="fas fa-clock-rotate-left" style="color:var(--jade);margin-right:8px"></i>Actividad Reciente</h3></div><div class="card-body" style="max-height:310px;overflow-y:auto">
                ${(d.recent_activity||[]).length?d.recent_activity.map(a=>`<div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--border)"><div style="width:32px;height:32px;border-radius:8px;background:var(--jade-pale);display:flex;align-items:center;justify-content:center"><i class="fas fa-circle-dot" style="font-size:10px;color:var(--jade)"></i></div><div style="flex:1"><div style="font-size:13px;font-weight:500">${a.action} - ${a.entity||''}</div><div style="font-size:11px;color:var(--text-muted)">${a.detail||''} · ${fmtDate(a.created_at?.split(' ')[0])}</div></div></div>`).join(''):'<div class="empty-state" style="padding:30px"><i class="fas fa-inbox"></i><p>Sin actividad reciente</p></div>'}
            </div></div>
        </div>
        ${d.overdue_invoices>0?`<div class="alert alert-warning" style="margin-top:16px"><i class="fas fa-exclamation-triangle"></i> Tienes ${d.overdue_invoices} factura(s) vencida(s). <a href="#" onclick="navigateTo('sales');return false" style="font-weight:700">Ver facturas</a></div>`:''}
        ${d.antifraud_alerts>0?`<div class="alert alert-error" style="margin-top:8px"><i class="fas fa-shield-exclamation"></i> ${d.antifraud_alerts} alerta(s) de antifraude pendiente(s).</div>`:''}
        `;
        /* Chart */
        if(d.chart&&d.chart.length){
            const ctx=document.getElementById('chart-sales');
            if(ctx){new Chart(ctx,{type:'line',data:{labels:d.chart.map(c=>c.label),datasets:[{label:'Ventas',data:d.chart.map(c=>c.sales),borderColor:'#1a5c38',backgroundColor:'rgba(26,92,56,0.1)',fill:true,tension:0.4,pointRadius:4,pointBackgroundColor:'#1a5c38'},{label:'Gastos',data:d.chart.map(c=>c.expenses),borderColor:'#c8a84e',backgroundColor:'rgba(200,168,78,0.1)',fill:true,tension:0.4,pointRadius:4,pointBackgroundColor:'#c8a84e'}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{usePointStyle:true,padding:16,font:{family:'DM Sans'}}}},scales:{y:{beginAtZero:true,ticks:{callback:v=>'$'+v.toLocaleString(),font:{family:'DM Sans'}}},x:{ticks:{font:{family:'DM Sans'}}}}}});}
        }
    });
}

/* ═══ CRM ═══ */
function loadCRM(type='client'){
    const c=$('#content-area');
    c.innerHTML=`<div class="page-header"><div><h1>CRM / Contactos</h1></div><div><button class="btn btn-primary btn-sm" onclick="openContactForm()"><i class="fas fa-plus"></i> Nuevo</button></div></div>
    <div class="tabs"><div class="tab ${type==='client'?'active':''}" onclick="loadCRM('client')">Clientes</div><div class="tab ${type==='supplier'?'active':''}" onclick="loadCRM('supplier')">Proveedores</div><div class="tab ${type==='lead'?'active':''}" onclick="loadCRM('lead')">Prospectos</div></div>
    <div class="card"><div class="card-header"><input type="text" placeholder="Buscar..." style="padding:6px 12px;border:1px solid var(--border);border-radius:var(--radius-sm);font-size:13px" oninput="searchContacts(this.value,'${type}')"></div><div class="card-body no-pad"><div class="table-wrap" id="contacts-table"><div style="text-align:center;padding:40px"><div class="spinner"></div></div></div></div></div>`;
    fetchContacts(type);
}
function fetchContacts(type,search='',page=1){
    api('contacts_list',{type,search,page}).then(r=>{
        if(!r.success)return;
        const rows=r.data.rows||[];
        let html=rows.length?`<table class="data-table"><thead><tr><th>Nombre</th><th>RFC</th><th>Email</th><th>Telefono</th><th>Estado</th><th></th></tr></thead><tbody>`:'<div class="empty-state"><i class="fas fa-users"></i><h3>Sin contactos</h3><p>Agrega tu primer contacto</p></div>';
        rows.forEach(r=>{html+=`<tr><td><strong>${r.name}</strong></td><td style="font-family:var(--font-mono);font-size:12px">${r.rfc||'-'}</td><td>${r.email||'-'}</td><td>${r.phone||'-'}</td><td>${statusBadge(r.status)}</td><td><button class="btn btn-outline btn-sm" onclick="editContact(${r.id})"><i class="fas fa-pen"></i></button></td></tr>`;});
        if(rows.length)html+='</tbody></table>';
        $('#contacts-table').innerHTML=html;
    });
}
let searchContactTimer;
function searchContacts(v,type){clearTimeout(searchContactTimer);searchContactTimer=setTimeout(()=>fetchContacts(type,v),300);}
function openContactForm(data=null){
    const isEdit=data&&data.id;
    const body=`<div class="form-row"><div class="form-group"><label>Tipo</label><select id="cf-type"><option value="client">Cliente</option><option value="supplier">Proveedor</option><option value="lead">Prospecto</option></select></div><div class="form-group"><label>Persona</label><select id="cf-ptype"><option value="fisica">Fisica</option><option value="moral">Moral</option></select></div></div>
    <div class="form-group"><label>Nombre / Razon Social *</label><input type="text" id="cf-name" value="${data?.name||''}"></div>
    <div class="form-row"><div class="form-group"><label>RFC</label><input type="text" id="cf-rfc" value="${data?.rfc||''}" style="text-transform:uppercase" maxlength="13"></div><div class="form-group"><label>CURP</label><input type="text" id="cf-curp" value="${data?.curp||''}" maxlength="18"></div></div>
    <div class="form-row"><div class="form-group"><label>Email</label><input type="email" id="cf-email" value="${data?.email||''}"></div><div class="form-group"><label>Telefono</label><input type="tel" id="cf-phone" value="${data?.phone||''}"></div></div>
    <div class="form-row"><div class="form-group"><label>Calle</label><input type="text" id="cf-street" value="${data?.street||''}"></div><div class="form-group"><label>No. Ext</label><input type="text" id="cf-ext" value="${data?.ext_num||''}"></div></div>
    <div class="form-row"><div class="form-group"><label>Colonia</label><input type="text" id="cf-colony" value="${data?.colony||''}"></div><div class="form-group"><label>C.P.</label><input type="text" id="cf-zip" value="${data?.zip||''}" maxlength="5"></div></div>
    <div class="form-row"><div class="form-group"><label>Ciudad</label><input type="text" id="cf-city" value="${data?.city||''}"></div><div class="form-group"><label>Estado</label><input type="text" id="cf-state" value="${data?.state||''}"></div></div>
    <div class="form-group"><label>Notas</label><textarea id="cf-notes" rows="2">${data?.notes||''}</textarea></div>`;
    const footer=`${isEdit?`<button class="btn btn-danger btn-sm" onclick="deleteContact(${data.id})"><i class="fas fa-trash"></i> Eliminar</button>`:''}
    <button class="btn btn-outline" onclick="closeModal('modal-generic')">Cancelar</button>
    <button class="btn btn-primary" onclick="saveContact(${data?.id||0})"><i class="fas fa-check"></i> Guardar</button>`;
    openModal('modal-generic',isEdit?'Editar Contacto':'Nuevo Contacto',body,footer);
    if(data){setTimeout(()=>{$('#cf-type').value=data.type||'client';$('#cf-ptype').value=data.person_type||'fisica';},50);}
}
function editContact(id){api('contact_get',{id}).then(r=>{if(r.success&&r.data.row)openContactForm(r.data.row)});}
function saveContact(id){
    api('contact_save',{id,type:$('#cf-type').value,person_type:$('#cf-ptype').value,name:$('#cf-name').value,rfc:$('#cf-rfc').value,curp:$('#cf-curp').value,email:$('#cf-email').value,phone:$('#cf-phone').value,street:$('#cf-street').value,ext_num:$('#cf-ext').value,colony:$('#cf-colony').value,zip:$('#cf-zip').value,city:$('#cf-city').value,state:$('#cf-state').value,notes:$('#cf-notes').value}).then(r=>{if(r.success){closeModal('modal-generic');loadCRM($('#cf-type')?.value||'client');}});
}
function deleteContact(id){if(confirm('Eliminar contacto?'))api('contact_delete',{id}).then(()=>{closeModal('modal-generic');loadCRM();})}

/* ═══ PRODUCTS ═══ */
function loadProducts(){
    const c=$('#content-area');
    c.innerHTML=`<div class="page-header"><div><h1>Inventario</h1></div><div><button class="btn btn-primary btn-sm" onclick="openProductForm()"><i class="fas fa-plus"></i> Nuevo Producto</button></div></div>
    <div class="card"><div class="card-header"><input type="text" placeholder="Buscar por nombre, SKU o codigo de barras..." style="padding:6px 12px;border:1px solid var(--border);border-radius:var(--radius-sm);font-size:13px;width:300px" oninput="searchProducts(this.value)"></div><div class="card-body no-pad"><div class="table-wrap" id="products-table"><div style="text-align:center;padding:40px"><div class="spinner"></div></div></div></div></div>`;
    fetchProducts();
}
function fetchProducts(search=''){
    api('products_list',{search}).then(r=>{
        if(!r.success)return;const rows=r.data.rows||[];
        let html=rows.length?`<table class="data-table"><thead><tr><th>Producto</th><th>SKU</th><th>Cod. Barras</th><th>Precio</th><th>Costo</th><th>Stock</th><th>IVA</th><th></th></tr></thead><tbody>`:'<div class="empty-state"><i class="fas fa-box-open"></i><h3>Sin productos</h3><p>Agrega tu primer producto o servicio</p></div>';
        rows.forEach(r=>{
            const lowStock=r.track_inventory==1&&parseFloat(r.current_stock)<=parseInt(r.min_stock);
            html+=`<tr><td><strong>${r.name}</strong><br><span style="font-size:11px;color:var(--text-muted)">${r.type==='service'?'Servicio':'Producto'}</span></td><td style="font-family:var(--font-mono);font-size:12px">${r.sku||'-'}</td><td style="font-family:var(--font-mono);font-size:12px">${r.barcode||'-'}</td><td>${fmt(r.price)}</td><td>${fmt(r.cost)}</td><td>${r.track_inventory==1?`<span style="${lowStock?'color:var(--danger);font-weight:700':''}">${fmtN(r.current_stock)}</span>`:'N/A'}</td><td>${r.tax_rate}%</td><td><button class="btn btn-outline btn-sm" onclick="editProduct(${r.id})"><i class="fas fa-pen"></i></button></td></tr>`;
        });
        if(rows.length)html+='</tbody></table>';
        $('#products-table').innerHTML=html;
    });
}
let searchProdTimer;
function searchProducts(v){clearTimeout(searchProdTimer);searchProdTimer=setTimeout(()=>fetchProducts(v),300);}
function openProductForm(data=null){
    const d=data||{};
    const body=`<div class="form-row"><div class="form-group"><label>Tipo</label><select id="pf-type"><option value="product" ${d.type==='product'?'selected':''}>Producto</option><option value="service" ${d.type==='service'?'selected':''}>Servicio</option></select></div><div class="form-group"><label>Unidad</label><input type="text" id="pf-unit" value="${d.unit||'PZA'}" placeholder="PZA, KG, LT..."></div></div>
    <div class="form-group"><label>Nombre *</label><input type="text" id="pf-name" value="${d.name||''}"></div>
    <div class="form-row"><div class="form-group"><label>SKU</label><input type="text" id="pf-sku" value="${d.sku||''}"></div><div class="form-group"><label>Codigo de Barras</label><input type="text" id="pf-barcode" value="${d.barcode||''}"></div></div>
    <div class="form-row"><div class="form-group"><label>Clave SAT</label><input type="text" id="pf-sat" value="${d.sat_code||''}"></div><div class="form-group"><label>Unidad SAT</label><input type="text" id="pf-satunit" value="${d.sat_unit||'H87'}"></div></div>
    <div class="form-row"><div class="form-group"><label>Costo</label><input type="number" id="pf-cost" value="${d.cost||0}" step="0.01"></div><div class="form-group"><label>Precio</label><input type="number" id="pf-price" value="${d.price||0}" step="0.01"></div></div>
    <div class="form-row"><div class="form-group"><label>IVA %</label><input type="number" id="pf-tax" value="${d.tax_rate||16}" step="0.01"></div><div class="form-group"><label>IEPS %</label><input type="number" id="pf-ieps" value="${d.ieps_rate||0}" step="0.01"></div></div>
    <div class="form-row"><div class="form-group"><label>Stock Minimo</label><input type="number" id="pf-min" value="${d.min_stock||0}"></div><div class="form-group"><label>Stock Maximo</label><input type="number" id="pf-max" value="${d.max_stock||0}"></div></div>
    <div class="form-group"><label>Descripcion</label><textarea id="pf-desc" rows="2">${d.description||''}</textarea></div>`;
    const footer=`<button class="btn btn-outline" onclick="closeModal('modal-generic')">Cancelar</button><button class="btn btn-primary" onclick="saveProduct(${d.id||0})"><i class="fas fa-check"></i> Guardar</button>`;
    openModal('modal-generic',d.id?'Editar Producto':'Nuevo Producto',body,footer);
}
function editProduct(id){api('product_get',{id}).then(r=>{if(r.success&&r.data.row)openProductForm(r.data.row)});}
function saveProduct(id){
    api('product_save',{id,type:$('#pf-type').value,name:$('#pf-name').value,sku:$('#pf-sku').value,barcode:$('#pf-barcode').value,sat_code:$('#pf-sat').value,sat_unit:$('#pf-satunit').value,unit:$('#pf-unit').value,cost:$('#pf-cost').value,price:$('#pf-price').value,tax_rate:$('#pf-tax').value,ieps_rate:$('#pf-ieps').value,min_stock:$('#pf-min').value,max_stock:$('#pf-max').value,description:$('#pf-desc').value}).then(r=>{if(r.success){closeModal('modal-generic');loadProducts();}});
}

/* ═══ DOCUMENTS (Sales/Purchases) ═══ */
function loadDocs(type,title){
    const c=$('#content-area');
    const label=type==='invoice'?'Factura':'Orden de Compra';
    c.innerHTML=`<div class="page-header"><div><h1>${title}</h1></div><div><button class="btn btn-primary btn-sm" onclick="openDocForm('${type}')"><i class="fas fa-plus"></i> Nuevo</button></div></div>
    <div class="tabs"><div class="tab active" onclick="fetchDocs('${type}')">Todos</div><div class="tab" onclick="fetchDocs('${type}','draft')">Borrador</div><div class="tab" onclick="fetchDocs('${type}','sent')">Enviadas</div><div class="tab" onclick="fetchDocs('${type}','paid')">Pagadas</div><div class="tab" onclick="fetchDocs('${type}','overdue')">Vencidas</div></div>
    <div class="card"><div class="card-body no-pad"><div class="table-wrap" id="docs-table"><div style="text-align:center;padding:40px"><div class="spinner"></div></div></div></div></div>`;
    fetchDocs(type);
}
function fetchDocs(type,status=''){
    api('documents_list',{type,status}).then(r=>{
        if(!r.success)return;const rows=r.data.rows||[];
        let html=rows.length?`<table class="data-table"><thead><tr><th>Folio</th><th>Cliente</th><th>Fecha</th><th>Vence</th><th>Total</th><th>Pagado</th><th>Estado</th><th></th></tr></thead><tbody>`:`<div class="empty-state"><i class="fas fa-file-invoice-dollar"></i><h3>Sin documentos</h3><p>Crea tu primer documento</p></div>`;
        rows.forEach(d=>{html+=`<tr><td style="font-family:var(--font-mono);font-weight:600">${d.series}${d.folio}</td><td>${d.contact_name||'-'}</td><td>${fmtDate(d.date_issued)}</td><td>${fmtDate(d.date_due)}</td><td><strong>${fmt(d.total)}</strong></td><td>${fmt(d.amount_paid)}</td><td>${statusBadge(d.status)}</td><td><button class="btn btn-outline btn-sm" onclick="viewDoc(${d.id})"><i class="fas fa-eye"></i></button></td></tr>`;});
        if(rows.length)html+='</tbody></table>';
        $('#docs-table').innerHTML=html;
    });
}
function openDocForm(type){
    const body=`<div class="form-row"><div class="form-group"><label>Tipo</label><select id="df-type"><option value="invoice" ${type==='invoice'?'selected':''}>Factura</option><option value="quote">Cotizacion</option><option value="purchase_order" ${type==='purchase_order'?'selected':''}>Orden de Compra</option><option value="credit_note">Nota de Credito</option></select></div><div class="form-group"><label>Serie</label><input type="text" id="df-series" value="A" maxlength="5"></div></div>
    <div class="form-row"><div class="form-group"><label>Contacto</label><input type="text" id="df-contact" placeholder="Buscar..."></div><div class="form-group"><label>RFC Contacto</label><input type="text" id="df-rfc"></div></div>
    <input type="hidden" id="df-contact-id" value="0">
    <div class="form-row"><div class="form-group"><label>Fecha</label><input type="date" id="df-date" value="${new Date().toISOString().split('T')[0]}"></div><div class="form-group"><label>Vencimiento</label><input type="date" id="df-due"></div></div>
    <div class="form-row"><div class="form-group"><label>Uso CFDI</label><select id="df-uso"><option value="G03">G03 - Gastos en general</option><option value="G01">G01 - Adq. mercancias</option><option value="G02">G02 - Devoluciones</option><option value="I01">I01 - Construcciones</option><option value="P01">P01 - Por definir</option><option value="S01">S01 - Sin efectos fiscales</option></select></div><div class="form-group"><label>Metodo Pago</label><select id="df-metodo"><option value="PUE">PUE - Pago una exhibicion</option><option value="PPD">PPD - Pago en parcialidades</option></select></div></div>
    <h4 style="margin:16px 0 8px;font-weight:700">Conceptos</h4>
    <div id="doc-items"><div class="doc-item-row" style="display:grid;grid-template-columns:2fr 60px 100px 60px 100px 30px;gap:8px;margin-bottom:8px;align-items:end">
        <div class="form-group" style="margin:0"><label style="font-size:11px">Descripcion</label><input type="text" class="di-desc"></div>
        <div class="form-group" style="margin:0"><label style="font-size:11px">Cant</label><input type="number" class="di-qty" value="1" min="1"></div>
        <div class="form-group" style="margin:0"><label style="font-size:11px">Precio Unit</label><input type="number" class="di-price" value="0" step="0.01"></div>
        <div class="form-group" style="margin:0"><label style="font-size:11px">IVA%</label><input type="number" class="di-tax" value="16"></div>
        <div style="text-align:right;padding-bottom:4px;font-weight:700;font-size:13px" class="di-total">$0.00</div>
        <div></div>
    </div></div>
    <button class="btn btn-outline btn-sm" onclick="addDocItem()" style="margin-bottom:16px"><i class="fas fa-plus"></i> Agregar concepto</button>
    <div style="text-align:right;padding:16px;background:var(--bg);border-radius:var(--radius)"><div style="font-size:13px;margin-bottom:4px">Subtotal: <strong id="df-subtotal">$0.00</strong></div><div style="font-size:13px;margin-bottom:4px">IVA: <strong id="df-iva">$0.00</strong></div><div style="font-size:18px;font-weight:800;color:var(--jade)">Total: <span id="df-total">$0.00</span></div></div>
    <div class="form-group" style="margin-top:12px"><label>Notas</label><textarea id="df-notes" rows="2"></textarea></div>`;
    const footer=`<button class="btn btn-outline" onclick="closeModal('modal-generic')">Cancelar</button><button class="btn btn-outline" onclick="saveDoc('draft')"><i class="fas fa-save"></i> Borrador</button><button class="btn btn-primary" onclick="saveDoc('sent')"><i class="fas fa-paper-plane"></i> Guardar y Enviar</button>`;
    openModal('modal-generic','Nuevo Documento',body,footer);$('#modal-generic-inner').classList.add('modal-lg');
    $$('.di-qty,.di-price,.di-tax').forEach(i=>i.addEventListener('input',calcDocTotals));
    calcDocTotals();
}
function addDocItem(){
    const div=document.createElement('div');div.className='doc-item-row';div.style.cssText='display:grid;grid-template-columns:2fr 60px 100px 60px 100px 30px;gap:8px;margin-bottom:8px;align-items:end';
    div.innerHTML=`<div class="form-group" style="margin:0"><input type="text" class="di-desc"></div><div class="form-group" style="margin:0"><input type="number" class="di-qty" value="1" min="1"></div><div class="form-group" style="margin:0"><input type="number" class="di-price" value="0" step="0.01"></div><div class="form-group" style="margin:0"><input type="number" class="di-tax" value="16"></div><div style="text-align:right;padding-bottom:4px;font-weight:700;font-size:13px" class="di-total">$0.00</div><button class="btn btn-icon btn-sm" onclick="this.parentElement.remove();calcDocTotals()" style="border:none;color:var(--danger)"><i class="fas fa-times"></i></button>`;
    $('#doc-items').appendChild(div);
    div.querySelectorAll('.di-qty,.di-price,.di-tax').forEach(i=>i.addEventListener('input',calcDocTotals));
}
function calcDocTotals(){
    let sub=0,iva=0;
    $$('.doc-item-row').forEach(row=>{
        const q=parseFloat(row.querySelector('.di-qty')?.value||1);
        const p=parseFloat(row.querySelector('.di-price')?.value||0);
        const t=parseFloat(row.querySelector('.di-tax')?.value||16);
        const ls=q*p;const li=ls*t/100;sub+=ls;iva+=li;
        const tot=row.querySelector('.di-total');if(tot)tot.textContent=fmt(ls+li);
    });
    const s=$('#df-subtotal'),i=$('#df-iva'),t=$('#df-total');
    if(s)s.textContent=fmt(sub);if(i)i.textContent=fmt(iva);if(t)t.textContent=fmt(sub+iva);
}
function saveDoc(status){
    const items=[];
    $$('.doc-item-row').forEach(r=>{
        const desc=r.querySelector('.di-desc')?.value;if(!desc)return;
        items.push({description:desc,quantity:r.querySelector('.di-qty')?.value||1,unit_price:r.querySelector('.di-price')?.value||0,tax_rate:r.querySelector('.di-tax')?.value||16});
    });
    if(!items.length)return alert('Agrega al menos un concepto.');
    api('document_save',{type:$('#df-type').value,series:$('#df-series').value,contact_id:$('#df-contact-id').value,contact_name:$('#df-contact').value,contact_rfc:$('#df-rfc').value,date_issued:$('#df-date').value,date_due:$('#df-due').value,uso_cfdi:$('#df-uso').value,metodo_pago:$('#df-metodo').value,notes:$('#df-notes').value,status,items:JSON.stringify(items)}).then(r=>{
        if(r.success){closeModal('modal-generic');$('#modal-generic-inner').classList.remove('modal-lg');loadDocs($('#df-type')?.value||'invoice',$('#df-type')?.value==='invoice'?'Ventas':'Compras');}
    });
}
function viewDoc(id){api('document_get',{id}).then(r=>{if(!r.success)return;const d=r.data.doc,items=r.data.items||[];
    const body=`<div style="display:flex;justify-content:space-between;margin-bottom:20px"><div><strong style="font-size:18px">${d.type==='invoice'?'Factura':'Documento'} ${d.series}${d.folio}</strong><br><span style="color:var(--text-sec)">${fmtDate(d.date_issued)}</span></div><div style="text-align:right">${statusBadge(d.status)}<br><span style="font-size:20px;font-weight:800;color:var(--jade)">${fmt(d.total)}</span></div></div>
    <div class="grid-2" style="margin-bottom:16px"><div><strong>Cliente:</strong> ${d.contact_name||'-'}<br><strong>RFC:</strong> ${d.contact_rfc||'-'}</div><div><strong>Vencimiento:</strong> ${fmtDate(d.date_due)}<br><strong>Pagado:</strong> ${fmt(d.amount_paid)}</div></div>
    <table class="data-table"><thead><tr><th>Concepto</th><th>Cant</th><th>P.Unit</th><th>IVA</th><th>Total</th></tr></thead><tbody>${items.map(i=>`<tr><td>${i.description}</td><td>${i.quantity}</td><td>${fmt(i.unit_price)}</td><td>${i.tax_rate}%</td><td><strong>${fmt(i.total)}</strong></td></tr>`).join('')}</tbody></table>`;
    openModal('modal-generic','Detalle de Documento',body,`<button class="btn btn-outline" onclick="closeModal('modal-generic')">Cerrar</button>`);
});}

/* ═══ ACCOUNTING ═══ */
function loadAccounting(){
    const c=$('#content-area');
    c.innerHTML=`<div class="page-header"><div><h1>Contabilidad</h1></div><div><button class="btn btn-primary btn-sm" onclick="openPolizaForm()"><i class="fas fa-plus"></i> Nueva Poliza</button></div></div>
    <div class="tabs"><div class="tab active" onclick="loadJournal()">Polizas</div><div class="tab" onclick="loadTrialBalance()">Balanza</div><div class="tab" onclick="loadChartAccounts()">Catalogo</div></div>
    <div id="accounting-content"><div style="text-align:center;padding:40px"><div class="spinner"></div></div></div>`;
    loadJournal();
}
function loadJournal(){
    api('journal_list').then(r=>{if(!r.success)return;const rows=r.data.rows||[];
    let html=rows.length?`<div class="card"><div class="card-body no-pad"><table class="data-table"><thead><tr><th>#</th><th>Fecha</th><th>Tipo</th><th>Concepto</th><th>Cargo</th><th>Abono</th><th>Estado</th><th></th></tr></thead><tbody>${rows.map(j=>`<tr><td style="font-family:var(--font-mono)">${j.type.charAt(0).toUpperCase()}${j.number}</td><td>${fmtDate(j.entry_date)}</td><td><span class="tag">${j.type}</span></td><td>${j.concept}</td><td>${fmt(j.total_debit)}</td><td>${fmt(j.total_credit)}</td><td>${statusBadge(j.status)}</td><td><button class="btn btn-outline btn-sm" onclick="viewPoliza(${j.id})"><i class="fas fa-eye"></i></button></td></tr>`).join('')}</tbody></table></div></div>`:'<div class="empty-state"><i class="fas fa-scale-balanced"></i><h3>Sin polizas</h3></div>';
    $('#accounting-content').innerHTML=html;});
}
function loadTrialBalance(){
    api('trial_balance').then(r=>{if(!r.success)return;const rows=r.data.rows||[];
    let html=`<div class="card"><div class="card-body no-pad"><table class="data-table"><thead><tr><th>Codigo</th><th>Cuenta</th><th>Tipo</th><th>Cargos</th><th>Abonos</th><th>Saldo</th></tr></thead><tbody>`;
    let tdeb=0,tcre=0;
    rows.forEach(a=>{const d=parseFloat(a.total_debit),cr=parseFloat(a.total_credit);if(d||cr){const sal=a.nature==='debit'?d-cr:cr-d;tdeb+=d;tcre+=cr;
    html+=`<tr><td style="font-family:var(--font-mono)">${a.code}</td><td style="padding-left:${(a.level-1)*16}px">${a.name}</td><td><span class="tag">${a.type}</span></td><td>${fmt(d)}</td><td>${fmt(cr)}</td><td><strong>${fmt(sal)}</strong></td></tr>`;}});
    html+=`<tr style="background:var(--bg);font-weight:700"><td colspan="3">TOTALES</td><td>${fmt(tdeb)}</td><td>${fmt(tcre)}</td><td>${fmt(tdeb-tcre)}</td></tr></tbody></table></div></div>`;
    $('#accounting-content').innerHTML=html;});
}
function loadChartAccounts(){
    api('accounts_list').then(r=>{if(!r.success)return;const rows=r.data.rows||[];
    let html=`<div class="card"><div class="card-header"><h3>Catalogo de Cuentas</h3><button class="btn btn-sm btn-outline" onclick="openAccountForm()"><i class="fas fa-plus"></i> Nueva</button></div><div class="card-body no-pad"><table class="data-table"><thead><tr><th>Codigo</th><th>Nombre</th><th>Tipo</th><th>Naturaleza</th></tr></thead><tbody>`;
    rows.forEach(a=>{html+=`<tr><td style="font-family:var(--font-mono)">${a.code}</td><td style="padding-left:${(a.level-1)*16}px">${a.name}</td><td><span class="tag">${a.type}</span></td><td>${a.nature}</td></tr>`;});
    html+=`</tbody></table></div></div>`;$('#accounting-content').innerHTML=html;});
}
function openPolizaForm(){openModal('modal-generic','Nueva Poliza',`<div class="form-row"><div class="form-group"><label>Tipo</label><select id="pz-type"><option value="diario">Diario</option><option value="ingreso">Ingreso</option><option value="egreso">Egreso</option><option value="nomina">Nomina</option></select></div><div class="form-group"><label>Fecha</label><input type="date" id="pz-date" value="${new Date().toISOString().split('T')[0]}"></div></div><div class="form-group"><label>Concepto</label><input type="text" id="pz-concept"></div><div id="pz-lines"></div><button class="btn btn-outline btn-sm" onclick="addPolizaLine()" style="margin:8px 0"><i class="fas fa-plus"></i> Agregar linea</button><div style="text-align:right;padding:8px;margin-top:8px;background:var(--bg);border-radius:var(--radius)"><span>Cargo: <strong id="pz-debit">$0.00</strong></span> &nbsp; <span>Abono: <strong id="pz-credit">$0.00</strong></span></div>`,`<button class="btn btn-outline" onclick="closeModal('modal-generic')">Cancelar</button><button class="btn btn-primary" onclick="savePoliza()"><i class="fas fa-check"></i> Guardar</button>`);addPolizaLine();addPolizaLine();}
function addPolizaLine(){const d=document.createElement('div');d.className='pz-line';d.style.cssText='display:grid;grid-template-columns:2fr 2fr 1fr 1fr 30px;gap:8px;margin-bottom:6px;align-items:end';d.innerHTML=`<div class="form-group" style="margin:0"><label style="font-size:11px">Cuenta</label><select class="pzl-account" style="padding:8px"><option value="">Seleccionar...</option></select></div><div class="form-group" style="margin:0"><label style="font-size:11px">Descripcion</label><input type="text" class="pzl-desc"></div><div class="form-group" style="margin:0"><label style="font-size:11px">Cargo</label><input type="number" class="pzl-deb" value="0" step="0.01" oninput="calcPoliza()"></div><div class="form-group" style="margin:0"><label style="font-size:11px">Abono</label><input type="number" class="pzl-cre" value="0" step="0.01" oninput="calcPoliza()"></div><button onclick="this.parentElement.remove();calcPoliza()" style="border:none;background:none;color:var(--danger);cursor:pointer"><i class="fas fa-times"></i></button>`;$('#pz-lines').appendChild(d);api('accounts_list').then(r=>{if(!r.success)return;const sel=d.querySelector('.pzl-account');(r.data.rows||[]).forEach(a=>{sel.innerHTML+=`<option value="${a.id}">${a.code} - ${a.name}</option>`;});});}
function calcPoliza(){let d=0,c=0;$$('.pz-line').forEach(l=>{d+=parseFloat(l.querySelector('.pzl-deb')?.value||0);c+=parseFloat(l.querySelector('.pzl-cre')?.value||0);});$('#pz-debit').textContent=fmt(d);$('#pz-credit').textContent=fmt(c);$('#pz-debit').style.color=Math.abs(d-c)>0.01?'var(--danger)':'var(--text)';$('#pz-credit').style.color=Math.abs(d-c)>0.01?'var(--danger)':'var(--text)';}
function savePoliza(){const lines=[];$$('.pz-line').forEach(l=>{const aid=l.querySelector('.pzl-account')?.value;if(!aid)return;lines.push({account_id:aid,description:l.querySelector('.pzl-desc')?.value||'',debit:l.querySelector('.pzl-deb')?.value||0,credit:l.querySelector('.pzl-cre')?.value||0});});if(!lines.length)return;api('journal_save',{entry_date:$('#pz-date').value,type:$('#pz-type').value,concept:$('#pz-concept').value,status:'posted',lines:JSON.stringify(lines)}).then(r=>{if(r.success){closeModal('modal-generic');loadAccounting();}else{alert(r.data?.msg||'Error');}});}
function viewPoliza(id){api('journal_get',{id}).then(r=>{if(!r.success)return;const e=r.data.entry,l=r.data.lines||[];openModal('modal-generic',`Poliza ${e.type.charAt(0).toUpperCase()}${e.number}`,`<div class="grid-2" style="margin-bottom:16px"><div><strong>Fecha:</strong> ${fmtDate(e.entry_date)}<br><strong>Tipo:</strong> ${e.type}</div><div><strong>Concepto:</strong> ${e.concept}<br><strong>Estado:</strong> ${statusBadge(e.status)}</div></div><table class="data-table"><thead><tr><th>Cuenta</th><th>Descripcion</th><th>Cargo</th><th>Abono</th></tr></thead><tbody>${l.map(li=>`<tr><td style="font-family:var(--font-mono)">${li.code} - ${li.account_name}</td><td>${li.description||'-'}</td><td>${fmt(li.debit)}</td><td>${fmt(li.credit)}</td></tr>`).join('')}<tr style="font-weight:700;background:var(--bg)"><td colspan="2">TOTALES</td><td>${fmt(e.total_debit)}</td><td>${fmt(e.total_credit)}</td></tr></tbody></table>`,`<button class="btn btn-outline" onclick="closeModal('modal-generic')">Cerrar</button>`)});}
function openAccountForm(){openModal('modal-generic','Nueva Cuenta',`<div class="form-row"><div class="form-group"><label>Codigo</label><input type="text" id="ac-code"></div><div class="form-group"><label>Nombre</label><input type="text" id="ac-name"></div></div><div class="form-row"><div class="form-group"><label>Tipo</label><select id="ac-type"><option value="asset">Activo</option><option value="liability">Pasivo</option><option value="equity">Capital</option><option value="revenue">Ingreso</option><option value="expense">Gasto</option></select></div><div class="form-group"><label>Naturaleza</label><select id="ac-nat"><option value="debit">Deudora</option><option value="credit">Acreedora</option></select></div></div>`,`<button class="btn btn-outline" onclick="closeModal('modal-generic')">Cancelar</button><button class="btn btn-primary" onclick="api('account_save',{code:$('#ac-code').value,name:$('#ac-name').value,type:$('#ac-type').value,nature:$('#ac-nat').value}).then(r=>{if(r.success){closeModal('modal-generic');loadAccounting();}})"><i class="fas fa-check"></i> Guardar</button>`);}

/* ═══ REMAINING MODULES (simplified for space) ═══ */
function loadBanks(){$('#content-area').innerHTML=`<div class="page-header"><div><h1>Bancos / Tesoreria</h1></div><div><button class="btn btn-primary btn-sm" onclick="openBankForm()"><i class="fas fa-plus"></i> Nueva Cuenta</button></div></div><div id="banks-content"><div style="text-align:center;padding:40px"><div class="spinner"></div></div></div>`;api('banks_list').then(r=>{if(!r.success)return;const rows=r.data.rows||[];$('#banks-content').innerHTML=rows.length?`<div class="stats-grid">${rows.map(b=>`<div class="stat-card" style="cursor:pointer" onclick="viewBankTxns(${b.id},'${b.bank_name}')"><div class="sc-top"><div class="sc-icon green"><i class="fas fa-building-columns"></i></div></div><div class="sc-value">${fmt(b.balance)}</div><div class="sc-label">${b.bank_name}</div><div style="font-size:11px;color:var(--text-muted);font-family:var(--font-mono)">${b.clabe||b.account_number||''}</div></div>`).join('')}</div>`:`<div class="empty-state"><i class="fas fa-building-columns"></i><h3>Sin cuentas bancarias</h3><p>Agrega tu primera cuenta</p><button class="btn btn-primary" onclick="openBankForm()"><i class="fas fa-plus"></i> Agregar</button></div>`;});}
function openBankForm(){openModal('modal-generic','Nueva Cuenta Bancaria',`<div class="form-group"><label>Banco</label><input type="text" id="bk-name" placeholder="BBVA, Banorte, etc."></div><div class="form-row"><div class="form-group"><label>No. Cuenta</label><input type="text" id="bk-num"></div><div class="form-group"><label>CLABE</label><input type="text" id="bk-clabe" maxlength="18"></div></div><div class="form-group"><label>Saldo Inicial</label><input type="number" id="bk-bal" value="0" step="0.01"></div>`,`<button class="btn btn-outline" onclick="closeModal('modal-generic')">Cancelar</button><button class="btn btn-primary" onclick="api('bank_save',{bank_name:$('#bk-name').value,account_number:$('#bk-num').value,clabe:$('#bk-clabe').value,balance:$('#bk-bal').value}).then(r=>{if(r.success){closeModal('modal-generic');loadBanks();}})"><i class="fas fa-check"></i> Guardar</button>`);}
function viewBankTxns(id,name){api('bank_txns_list',{bank_id:id}).then(r=>{if(!r.success)return;const rows=r.data.rows||[];openModal('modal-generic',`Movimientos - ${name}`,`<table class="data-table"><thead><tr><th>Fecha</th><th>Tipo</th><th>Monto</th><th>Saldo</th><th>Referencia</th></tr></thead><tbody>${rows.map(t=>`<tr><td>${fmtDate(t.date_txn)}</td><td>${t.type}</td><td style="color:${t.type==='withdrawal'?'var(--danger)':'var(--success)'}"><strong>${t.type==='withdrawal'?'-':'+'} ${fmt(t.amount)}</strong></td><td>${fmt(t.balance_after)}</td><td>${t.reference||'-'}</td></tr>`).join('')}${!rows.length?'<tr><td colspan="5" style="text-align:center;padding:30px;color:var(--text-muted)">Sin movimientos</td></tr>':''}</tbody></table>`,`<button class="btn btn-outline" onclick="closeModal('modal-generic')">Cerrar</button>`)});}

function loadPayroll(){$('#content-area').innerHTML=`<div class="page-header"><div><h1>Nomina</h1></div><div style="display:flex;gap:8px"><button class="btn btn-outline btn-sm" onclick="loadPayrollHistory()"><i class="fas fa-list"></i> Historial</button><button class="btn btn-primary btn-sm" onclick="calcPayroll()"><i class="fas fa-calculator"></i> Calcular Nomina</button></div></div><div id="payroll-content"><p style="color:var(--text-sec);padding:40px;text-align:center">Selecciona un periodo y calcula la nomina de tus empleados.</p></div>`;}
function calcPayroll(){const today=new Date(),y=today.getFullYear(),m=today.getMonth();const d1=today.getDate()<=15?1:16;const d2=today.getDate()<=15?15:new Date(y,m+1,0).getDate();const ps=`${y}-${String(m+1).padStart(2,'0')}-${String(d1).padStart(2,'0')}`;const pe=`${y}-${String(m+1).padStart(2,'0')}-${String(d2).padStart(2,'0')}`;
    api('payroll_calculate',{period_start:ps,period_end:pe,payroll_type:'quincenal'}).then(r=>{if(!r.success)return;const d=r.data;
    $('#payroll-content').innerHTML=`<div class="stats-grid"><div class="stat-card"><div class="sc-icon green"><i class="fas fa-money-bill"></i></div><div class="sc-value">${fmt(d.summary.total_gross)}</div><div class="sc-label">Total Bruto</div></div><div class="stat-card"><div class="sc-icon red"><i class="fas fa-minus-circle"></i></div><div class="sc-value">${fmt(d.summary.total_deductions)}</div><div class="sc-label">Deducciones</div></div><div class="stat-card"><div class="sc-icon green"><i class="fas fa-wallet"></i></div><div class="sc-value">${fmt(d.summary.total_net)}</div><div class="sc-label">Neto a Pagar</div></div><div class="stat-card"><div class="sc-icon orange"><i class="fas fa-building"></i></div><div class="sc-value">${fmt(d.summary.total_employer)}</div><div class="sc-label">Costo Patronal</div></div></div>
    <div class="card"><div class="card-header"><h3>Detalle por Empleado - ${fmtDate(d.period.start)} al ${fmtDate(d.period.end)}</h3><button class="btn btn-primary btn-sm" onclick="savePayroll()"><i class="fas fa-save"></i> Guardar Nomina</button></div><div class="card-body no-pad"><div class="table-wrap"><table class="data-table"><thead><tr><th>Empleado</th><th>Dias</th><th>Bruto</th><th>ISR</th><th>IMSS</th><th>Deducciones</th><th>Neto</th><th>IMSS Pat.</th><th>RCV</th><th>INFONAVIT</th><th>ISN</th></tr></thead><tbody>${d.details.map(e=>`<tr><td><strong>${e.employee_name}</strong></td><td>${e.days_worked}</td><td>${fmt(e.gross_pay)}</td><td>${fmt(e.isr)}</td><td>${fmt(e.imss_employee)}</td><td>${fmt(e.total_deductions)}</td><td style="color:var(--jade);font-weight:700">${fmt(e.net_pay)}</td><td>${fmt(e.imss_employer)}</td><td>${fmt(e.rcv)}</td><td>${fmt(e.infonavit)}</td><td>${fmt(e.payroll_tax)}</td></tr>`).join('')}</tbody></table></div></div></div>`;
    window._lastPayroll=d;});}
function savePayroll(){if(!window._lastPayroll)return;api('payroll_save',{payroll_data:JSON.stringify(window._lastPayroll)}).then(r=>{if(r.success)alert('Nomina guardada exitosamente.');});}
function loadPayrollHistory(){api('payroll_list').then(r=>{if(!r.success)return;const rows=r.data.rows||[];$('#payroll-content').innerHTML=rows.length?`<div class="card"><div class="card-body no-pad"><table class="data-table"><thead><tr><th>Periodo</th><th>Tipo</th><th>Bruto</th><th>Neto</th><th>Patronal</th><th>Estado</th></tr></thead><tbody>${rows.map(p=>`<tr><td>${fmtDate(p.period_start)} - ${fmtDate(p.period_end)}</td><td>${p.type}</td><td>${fmt(p.total_gross)}</td><td>${fmt(p.total_net)}</td><td>${fmt(p.total_employer)}</td><td>${statusBadge(p.status)}</td></tr>`).join('')}</tbody></table></div></div>`:`<div class="empty-state"><i class="fas fa-money-bills"></i><h3>Sin nominas</h3></div>`;});}

function loadEmployees(){$('#content-area').innerHTML=`<div class="page-header"><div><h1>Recursos Humanos</h1></div><div><button class="btn btn-primary btn-sm" onclick="openEmployeeForm()"><i class="fas fa-plus"></i> Nuevo Empleado</button></div></div><div id="emp-content"><div style="text-align:center;padding:40px"><div class="spinner"></div></div></div>`;api('employees_list').then(r=>{if(!r.success)return;const rows=r.data.rows||[];$('#emp-content').innerHTML=rows.length?`<div class="card"><div class="card-body no-pad"><table class="data-table"><thead><tr><th>#</th><th>Nombre</th><th>RFC</th><th>Puesto</th><th>Depto</th><th>Salario Diario</th><th>Estado</th><th></th></tr></thead><tbody>${rows.map(e=>`<tr><td>${e.employee_number||'-'}</td><td><strong>${e.name}</strong></td><td style="font-family:var(--font-mono);font-size:12px">${e.rfc||'-'}</td><td>${e.position||'-'}</td><td>${e.department||'-'}</td><td>${fmt(e.salary_daily)}</td><td>${statusBadge(e.status)}</td><td><button class="btn btn-outline btn-sm" onclick="editEmployee(${e.id})"><i class="fas fa-pen"></i></button></td></tr>`).join('')}</tbody></table></div></div>`:`<div class="empty-state"><i class="fas fa-id-badge"></i><h3>Sin empleados</h3><button class="btn btn-primary" onclick="openEmployeeForm()"><i class="fas fa-plus"></i> Agregar</button></div>`;});}
function openEmployeeForm(d={}){openModal('modal-generic',d.id?'Editar Empleado':'Nuevo Empleado',`<div class="form-row"><div class="form-group"><label>No. Empleado</label><input type="text" id="emp-num" value="${d.employee_number||''}"></div><div class="form-group"><label>Nombre *</label><input type="text" id="emp-name" value="${d.name||''}"></div></div><div class="form-row"><div class="form-group"><label>RFC</label><input type="text" id="emp-rfc" value="${d.rfc||''}" maxlength="13"></div><div class="form-group"><label>CURP</label><input type="text" id="emp-curp" value="${d.curp||''}" maxlength="18"></div></div><div class="form-row"><div class="form-group"><label>NSS</label><input type="text" id="emp-nss" value="${d.nss||''}"></div><div class="form-group"><label>Email</label><input type="email" id="emp-email" value="${d.email||''}"></div></div><div class="form-row"><div class="form-group"><label>Departamento</label><input type="text" id="emp-dept" value="${d.department||''}"></div><div class="form-group"><label>Puesto</label><input type="text" id="emp-pos" value="${d.position||''}"></div></div><div class="form-row"><div class="form-group"><label>Fecha Ingreso</label><input type="date" id="emp-hire" value="${d.hire_date||''}"></div><div class="form-group"><label>Contrato</label><select id="emp-ct"><option value="indefinido" ${d.contract_type==='indefinido'?'selected':''}>Indefinido</option><option value="temporal" ${d.contract_type==='temporal'?'selected':''}>Temporal</option></select></div></div><div class="form-row"><div class="form-group"><label>Salario Diario</label><input type="number" id="emp-sd" value="${d.salary_daily||0}" step="0.01"></div><div class="form-group"><label>Salario Mensual</label><input type="number" id="emp-sm" value="${d.salary_monthly||0}" step="0.01"></div></div>`,`<button class="btn btn-outline" onclick="closeModal('modal-generic')">Cancelar</button><button class="btn btn-primary" onclick="saveEmployee(${d.id||0})"><i class="fas fa-check"></i> Guardar</button>`);}
function editEmployee(id){api('employee_get',{id}).then(r=>{if(r.success&&r.data.row)openEmployeeForm(r.data.row)});}
function saveEmployee(id){api('employee_save',{id,employee_number:$('#emp-num').value,name:$('#emp-name').value,rfc:$('#emp-rfc').value,curp:$('#emp-curp').value,nss:$('#emp-nss').value,email:$('#emp-email').value,department:$('#emp-dept').value,position:$('#emp-pos').value,hire_date:$('#emp-hire').value,contract_type:$('#emp-ct').value,salary_daily:$('#emp-sd').value,salary_monthly:$('#emp-sm').value}).then(r=>{if(r.success){closeModal('modal-generic');loadEmployees();}});}

function loadAssets(){$('#content-area').innerHTML=`<div class="page-header"><div><h1>Activos Fijos</h1></div><div><button class="btn btn-primary btn-sm" onclick="openAssetForm()"><i class="fas fa-plus"></i> Nuevo Activo</button></div></div><div id="assets-content"><div style="text-align:center;padding:40px"><div class="spinner"></div></div></div>`;api('assets_list').then(r=>{if(!r.success)return;const rows=r.data.rows||[];$('#assets-content').innerHTML=rows.length?`<div class="card"><div class="card-body no-pad"><table class="data-table"><thead><tr><th>Activo</th><th>Categoria</th><th>Costo Adq.</th><th>Dep. Acum.</th><th>Valor Libro</th><th>Metodo</th><th>Estado</th><th></th></tr></thead><tbody>${rows.map(a=>`<tr><td><strong>${a.name}</strong></td><td>${a.category||'-'}</td><td>${fmt(a.acquisition_cost)}</td><td>${fmt(a.accumulated_depreciation)}</td><td style="font-weight:700;color:var(--jade)">${fmt(a.book_value)}</td><td>${a.depreciation_method==='straight_line'?'Linea Recta':'Saldo Decr.'}</td><td>${statusBadge(a.status)}</td><td><button class="btn btn-outline btn-sm" onclick="viewAssetSchedule(${a.id},'${a.name}')"><i class="fas fa-calendar"></i></button></td></tr>`).join('')}</tbody></table></div></div>`:`<div class="empty-state"><i class="fas fa-landmark"></i><h3>Sin activos fijos</h3></div>`;});}
function openAssetForm(){openModal('modal-generic','Nuevo Activo Fijo',`<div class="form-group"><label>Nombre *</label><input type="text" id="af-name"></div><div class="form-row"><div class="form-group"><label>Categoria</label><input type="text" id="af-cat" placeholder="Equipo de computo, Mobiliario..."></div><div class="form-group"><label>No. Serie</label><input type="text" id="af-serial"></div></div><div class="form-row"><div class="form-group"><label>Fecha Adquisicion</label><input type="date" id="af-date" value="${new Date().toISOString().split('T')[0]}"></div><div class="form-group"><label>Vida Util (meses)</label><input type="number" id="af-life" value="60"></div></div><div class="form-row"><div class="form-group"><label>Costo de Adquisicion</label><input type="number" id="af-cost" value="0" step="0.01"></div><div class="form-group"><label>Valor de Rescate</label><input type="number" id="af-salvage" value="0" step="0.01"></div></div><div class="form-group"><label>Ubicacion</label><input type="text" id="af-loc"></div>`,`<button class="btn btn-outline" onclick="closeModal('modal-generic')">Cancelar</button><button class="btn btn-primary" onclick="api('asset_save',{name:$('#af-name').value,category:$('#af-cat').value,serial_number:$('#af-serial').value,acquisition_date:$('#af-date').value,useful_life_months:$('#af-life').value,acquisition_cost:$('#af-cost').value,salvage_value:$('#af-salvage').value,location:$('#af-loc').value}).then(r=>{if(r.success){closeModal('modal-generic');loadAssets();}})"><i class="fas fa-check"></i> Guardar</button>`);}
function viewAssetSchedule(id,name){api('asset_schedule',{id}).then(r=>{if(!r.success)return;const rows=r.data.rows||[];openModal('modal-generic',`Tabla de Depreciacion - ${name}`,`<div class="table-wrap"><table class="data-table"><thead><tr><th>#</th><th>Periodo</th><th>Depreciacion</th><th>Acumulada</th><th>Valor en Libros</th></tr></thead><tbody>${rows.map((s,i)=>`<tr><td>${i+1}</td><td>${fmtDate(s.period_date)}</td><td>${fmt(s.depreciation_amount)}</td><td>${fmt(s.accumulated)}</td><td style="font-weight:600">${fmt(s.book_value)}</td></tr>`).join('')}</tbody></table></div>`,`<button class="btn btn-outline" onclick="closeModal('modal-generic')">Cerrar</button>`);$('#modal-generic-inner').classList.add('modal-lg');});}

function loadAmortizations(){$('#content-area').innerHTML=`<div class="page-header"><div><h1>Amortizaciones</h1></div><div><button class="btn btn-primary btn-sm" onclick="openAmortForm()"><i class="fas fa-plus"></i> Nueva</button></div></div><div id="amort-content"><div style="text-align:center;padding:40px"><div class="spinner"></div></div></div>`;api('amortizations_list').then(r=>{if(!r.success)return;const rows=r.data.rows||[];$('#amort-content').innerHTML=rows.length?`<div class="card"><div class="card-body no-pad"><table class="data-table"><thead><tr><th>Nombre</th><th>Tipo</th><th>Monto Original</th><th>Tasa</th><th>Plazo</th><th>Pago Mensual</th><th>Saldo</th><th></th></tr></thead><tbody>${rows.map(a=>`<tr><td><strong>${a.name}</strong></td><td>${a.type}</td><td>${fmt(a.original_amount)}</td><td>${a.interest_rate}%</td><td>${a.term_months}m</td><td>${fmt(a.monthly_payment)}</td><td>${fmt(a.balance)}</td><td><button class="btn btn-outline btn-sm" onclick="viewAmortSchedule(${a.id},'${a.name}')"><i class="fas fa-calendar"></i></button></td></tr>`).join('')}</tbody></table></div></div>`:`<div class="empty-state"><i class="fas fa-chart-line"></i><h3>Sin amortizaciones</h3></div>`;});}
function openAmortForm(){openModal('modal-generic','Nueva Amortizacion',`<div class="form-group"><label>Nombre *</label><input type="text" id="am-name"></div><div class="form-row"><div class="form-group"><label>Tipo</label><select id="am-type"><option value="loan">Prestamo</option><option value="lease">Arrendamiento</option><option value="intangible">Intangible</option></select></div><div class="form-group"><label>Fecha Inicio</label><input type="date" id="am-date" value="${new Date().toISOString().split('T')[0]}"></div></div><div class="form-row"><div class="form-group"><label>Monto Original</label><input type="number" id="am-amount" value="0" step="0.01"></div><div class="form-group"><label>Tasa Anual %</label><input type="number" id="am-rate" value="12" step="0.01"></div></div><div class="form-group"><label>Plazo (meses)</label><input type="number" id="am-term" value="12"></div>`,`<button class="btn btn-outline" onclick="closeModal('modal-generic')">Cancelar</button><button class="btn btn-primary" onclick="api('amortization_save',{name:$('#am-name').value,amort_type:$('#am-type').value,start_date:$('#am-date').value,original_amount:$('#am-amount').value,interest_rate:$('#am-rate').value,term_months:$('#am-term').value}).then(r=>{if(r.success){closeModal('modal-generic');loadAmortizations();}})"><i class="fas fa-check"></i> Guardar</button>`);}
function viewAmortSchedule(id,name){api('amortization_schedule',{id}).then(r=>{if(!r.success)return;const rows=r.data.rows||[];openModal('modal-generic',`Tabla de Amortizacion - ${name}`,`<div class="table-wrap"><table class="data-table"><thead><tr><th>#</th><th>Fecha</th><th>Pago</th><th>Capital</th><th>Interes</th><th>Saldo</th></tr></thead><tbody>${rows.map(s=>`<tr><td>${s.payment_number}</td><td>${fmtDate(s.payment_date)}</td><td>${fmt(s.payment_amount)}</td><td>${fmt(s.principal)}</td><td>${fmt(s.interest)}</td><td style="font-weight:600">${fmt(s.balance)}</td></tr>`).join('')}</tbody></table></div>`,`<button class="btn btn-outline" onclick="closeModal('modal-generic')">Cerrar</button>`);$('#modal-generic-inner').classList.add('modal-lg');});}

function loadProjects(){$('#content-area').innerHTML=`<div class="page-header"><div><h1>Proyectos</h1></div><div><button class="btn btn-primary btn-sm" onclick="openProjectForm()"><i class="fas fa-plus"></i> Nuevo</button></div></div><div id="proj-content"><div style="text-align:center;padding:40px"><div class="spinner"></div></div></div>`;api('projects_list').then(r=>{if(!r.success)return;const rows=r.data.rows||[];$('#proj-content').innerHTML=rows.length?`<div class="stats-grid">${rows.map(p=>`<div class="stat-card" style="cursor:pointer" onclick="viewProject(${p.id})"><div class="sc-top"><div class="sc-icon green"><i class="fas fa-diagram-project"></i></div>${statusBadge(p.status)}</div><div style="font-size:16px;font-weight:700;margin:8px 0">${p.name}</div><div style="font-size:12px;color:var(--text-sec)">${p.task_count||0} tareas · ${fmt(p.budget)}</div><div style="font-size:11px;color:var(--text-muted)">${fmtDate(p.start_date)} — ${fmtDate(p.end_date)}</div></div>`).join('')}</div>`:`<div class="empty-state"><i class="fas fa-diagram-project"></i><h3>Sin proyectos</h3></div>`;});}
function openProjectForm(){openModal('modal-generic','Nuevo Proyecto',`<div class="form-group"><label>Nombre *</label><input type="text" id="pj-name"></div><div class="form-group"><label>Descripcion</label><textarea id="pj-desc" rows="2"></textarea></div><div class="form-row"><div class="form-group"><label>Fecha Inicio</label><input type="date" id="pj-start"></div><div class="form-group"><label>Fecha Fin</label><input type="date" id="pj-end"></div></div><div class="form-group"><label>Presupuesto</label><input type="number" id="pj-budget" value="0" step="0.01"></div>`,`<button class="btn btn-outline" onclick="closeModal('modal-generic')">Cancelar</button><button class="btn btn-primary" onclick="api('project_save',{name:$('#pj-name').value,description:$('#pj-desc').value,start_date:$('#pj-start').value,end_date:$('#pj-end').value,budget:$('#pj-budget').value}).then(r=>{if(r.success){closeModal('modal-generic');loadProjects();}})"><i class="fas fa-check"></i> Guardar</button>`);}
function viewProject(id){api('tasks_list',{project_id:id}).then(r=>{if(!r.success)return;const rows=r.data.rows||[];const cols={todo:'Por Hacer',in_progress:'En Progreso',review:'Revision',done:'Completado'};let html='<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px">';Object.entries(cols).forEach(([k,v])=>{html+=`<div><h4 style="font-size:12px;font-weight:700;text-transform:uppercase;color:var(--text-muted);margin-bottom:8px;letter-spacing:0.5px">${v}</h4>`;const tasks=rows.filter(t=>t.status===k);tasks.forEach(t=>{html+=`<div style="background:var(--bg);border:1px solid var(--border);border-radius:var(--radius);padding:10px;margin-bottom:8px"><div style="font-weight:600;font-size:13px">${t.title}</div><div style="font-size:11px;color:var(--text-muted);margin-top:4px">${t.assigned_name||'Sin asignar'}</div></div>`;});html+='</div>';});html+='</div>';openModal('modal-generic','Tablero de Tareas',html,`<button class="btn btn-outline" onclick="closeModal('modal-generic')">Cerrar</button><button class="btn btn-primary btn-sm" onclick="openTaskForm(${id})"><i class="fas fa-plus"></i> Nueva Tarea</button>`);$('#modal-generic-inner').classList.add('modal-xl');});}
function openTaskForm(pid){openModal('modal-generic','Nueva Tarea',`<div class="form-group"><label>Titulo *</label><input type="text" id="tk-title"></div><div class="form-group"><label>Descripcion</label><textarea id="tk-desc" rows="2"></textarea></div><div class="form-row"><div class="form-group"><label>Prioridad</label><select id="tk-pri"><option value="low">Baja</option><option value="medium" selected>Media</option><option value="high">Alta</option><option value="urgent">Urgente</option></select></div><div class="form-group"><label>Fecha Limite</label><input type="date" id="tk-due"></div></div>`,`<button class="btn btn-outline" onclick="closeModal('modal-generic')">Cancelar</button><button class="btn btn-primary" onclick="api('task_save',{project_id:${pid},title:$('#tk-title').value,description:$('#tk-desc').value,priority:$('#tk-pri').value,due_date:$('#tk-due').value}).then(r=>{if(r.success){closeModal('modal-generic');viewProject(${pid});}})"><i class="fas fa-check"></i> Guardar</button>`);}

function loadReports(){$('#content-area').innerHTML=`<div class="page-header"><div><h1>Reportes Financieros</h1></div></div><div class="form-row" style="margin-bottom:16px"><div class="form-group"><label>Desde</label><input type="date" id="rpt-from" value="${new Date().getFullYear()}-01-01"></div><div class="form-group"><label>Hasta</label><input type="date" id="rpt-to" value="${new Date().toISOString().split('T')[0]}"></div><div style="display:flex;align-items:end"><button class="btn btn-primary" onclick="fetchReport()"><i class="fas fa-chart-pie"></i> Generar</button></div></div><div id="report-content"></div>`;fetchReport();}
function fetchReport(){api('report_financial',{date_from:$('#rpt-from').value,date_to:$('#rpt-to').value}).then(r=>{if(!r.success)return;const d=r.data;$('#report-content').innerHTML=`<div class="grid-2"><div class="card"><div class="card-header"><h3>Estado de Resultados</h3></div><div class="card-body"><table class="data-table"><tbody><tr><td>Ingresos</td><td style="text-align:right;font-weight:700;color:var(--success)">${fmt(d.income_statement.revenue)}</td></tr><tr><td>(-) Costo de Ventas</td><td style="text-align:right">${fmt(d.income_statement.costs)}</td></tr><tr style="background:var(--bg)"><td><strong>Utilidad Bruta</strong></td><td style="text-align:right;font-weight:700">${fmt(d.income_statement.gross_profit)}</td></tr><tr><td>(-) Gastos de Operacion</td><td style="text-align:right">${fmt(d.income_statement.expenses)}</td></tr><tr style="background:var(--jade-pale)"><td><strong>Utilidad Neta</strong></td><td style="text-align:right;font-weight:800;font-size:16px;color:${d.income_statement.net_income>=0?'var(--jade)':'var(--danger)'}">${fmt(d.income_statement.net_income)}</td></tr></tbody></table></div></div><div class="card"><div class="card-header"><h3>Balance General</h3></div><div class="card-body"><table class="data-table"><tbody><tr style="background:var(--bg)"><td><strong>ACTIVOS</strong></td><td style="text-align:right;font-weight:700">${fmt(d.balance_sheet.assets)}</td></tr><tr style="background:var(--bg)"><td><strong>PASIVOS</strong></td><td style="text-align:right;font-weight:700">${fmt(d.balance_sheet.liabilities)}</td></tr><tr style="background:var(--bg)"><td><strong>CAPITAL</strong></td><td style="text-align:right;font-weight:700">${fmt(d.balance_sheet.equity)}</td></tr><tr style="background:var(--jade-pale)"><td><strong>A - P - C</strong></td><td style="text-align:right;font-weight:800">${fmt(d.balance_sheet.assets-d.balance_sheet.liabilities-d.balance_sheet.equity)}</td></tr></tbody></table></div></div></div>`;});}

function loadIssuers(){$('#content-area').innerHTML=`<div class="page-header"><div><h1>Emisores (Multi-Emisor)</h1></div><div><button class="btn btn-primary btn-sm" onclick="openIssuerForm()"><i class="fas fa-plus"></i> Nuevo Emisor</button></div></div><div id="issuers-content"><div style="text-align:center;padding:40px"><div class="spinner"></div></div></div>`;api('issuers_list').then(r=>{if(!r.success)return;const rows=r.data.rows||[];$('#issuers-content').innerHTML=rows.length?`<div class="stats-grid">${rows.map(i=>`<div class="stat-card"><div class="sc-top"><div class="sc-icon green"><i class="fas fa-stamp"></i></div>${statusBadge(i.status?'active':'inactive')}</div><div style="font-size:16px;font-weight:700;margin:8px 0">${i.name}</div><div style="font-family:var(--font-mono);font-size:12px;color:var(--text-sec)">${i.rfc}</div></div>`).join('')}</div>`:`<div class="empty-state"><i class="fas fa-stamp"></i><h3>Sin emisores</h3></div>`;});}
function openIssuerForm(){openModal('modal-generic','Nuevo Emisor',`<div class="form-group"><label>Razon Social *</label><input type="text" id="is-name"></div><div class="form-row"><div class="form-group"><label>RFC *</label><input type="text" id="is-rfc" maxlength="13"></div><div class="form-group"><label>Regimen Fiscal</label><input type="text" id="is-regimen"></div></div><div class="form-group"><label>Domicilio</label><textarea id="is-addr" rows="2"></textarea></div><div class="form-group"><label>C.P.</label><input type="text" id="is-zip" maxlength="5"></div>`,`<button class="btn btn-outline" onclick="closeModal('modal-generic')">Cancelar</button><button class="btn btn-primary" onclick="api('issuer_save',{name:$('#is-name').value,rfc:$('#is-rfc').value,regimen_fiscal:$('#is-regimen').value,address:$('#is-addr').value,zip:$('#is-zip').value}).then(r=>{if(r.success){closeModal('modal-generic');loadIssuers();}})"><i class="fas fa-check"></i> Guardar</button>`);}

function loadFacturador(){$('#content-area').innerHTML=`<div class="page-header"><div><h1>Facturador CFDI</h1><div class="subtitle">Acceso directo al sistema de facturacion</div></div></div><div class="card"><div class="card-body" style="text-align:center;padding:60px"><i class="fas fa-file-signature" style="font-size:48px;color:var(--jade);margin-bottom:16px"></i><h3 style="margin-bottom:8px">Factura Maya - CFDI 4.0</h3><p style="color:var(--text-sec);margin-bottom:20px">Accede al facturador sin necesidad de iniciar sesion nuevamente.</p><button class="btn btn-primary" onclick="openFacturador()"><i class="fas fa-external-link-alt"></i> Abrir Facturador</button></div></div>`;}
function openFacturador(){api('facturador_access').then(r=>{if(r.success&&r.data.url)window.open(r.data.url,'_blank');});}

function loadUsers(){$('#content-area').innerHTML=`<div class="page-header"><div><h1>Usuarios del Sistema</h1></div><div><button class="btn btn-primary btn-sm" onclick="openUserForm()"><i class="fas fa-plus"></i> Nuevo</button></div></div><div id="users-content"><div style="text-align:center;padding:40px"><div class="spinner"></div></div></div>`;api('users_list').then(r=>{if(!r.success)return;const rows=r.data.rows||[];$('#users-content').innerHTML=`<div class="card"><div class="card-body no-pad"><table class="data-table"><thead><tr><th>Nombre</th><th>Email</th><th>Rol</th><th>Estado</th><th>Ultimo Acceso</th><th></th></tr></thead><tbody>${rows.map(u=>`<tr><td><strong>${u.name}</strong></td><td>${u.email}</td><td><span class="tag">${u.role}</span></td><td>${statusBadge(u.status)}</td><td>${u.last_login?fmtDate(u.last_login.split(' ')[0]):'-'}</td><td><button class="btn btn-outline btn-sm" onclick="editUser(${u.id})"><i class="fas fa-pen"></i></button></td></tr>`).join('')}</tbody></table></div></div>`;});}
function openUserForm(d={}){openModal('modal-generic',d.id?'Editar Usuario':'Nuevo Usuario',`<div class="form-row"><div class="form-group"><label>Nombre</label><input type="text" id="us-name" value="${d.name||''}"></div><div class="form-group"><label>Email</label><input type="email" id="us-email" value="${d.email||''}"></div></div><div class="form-row"><div class="form-group"><label>Rol</label><select id="us-role"><option value="admin" ${d.role==='admin'?'selected':''}>Admin</option><option value="manager" ${d.role==='manager'?'selected':''}>Gerente</option><option value="accountant" ${d.role==='accountant'?'selected':''}>Contador</option><option value="employee" ${d.role==='employee'?'selected':''}>Empleado</option><option value="readonly" ${d.role==='readonly'?'selected':''}>Solo Lectura</option></select></div><div class="form-group"><label>${d.id?'Nueva Contrasena (dejar vacio para no cambiar)':'Contrasena *'}</label><input type="password" id="us-pass"></div></div>`,`<button class="btn btn-outline" onclick="closeModal('modal-generic')">Cancelar</button><button class="btn btn-primary" onclick="api('user_save',{id:${d.id||0},name:$('#us-name').value,email:$('#us-email').value,role:$('#us-role').value,new_password:$('#us-pass').value}).then(r=>{if(r.success){closeModal('modal-generic');loadUsers();}else{alert(r.data?.msg||'Error');}})"><i class="fas fa-check"></i> Guardar</button>`);}
function editUser(id){/* simple: re-use form */api('users_list').then(r=>{const u=(r.data.rows||[]).find(x=>x.id==id);if(u)openUserForm(u);});}

function loadPayments(){$('#content-area').innerHTML=`<div class="page-header"><div><h1>Pagos</h1></div></div><div class="alert alert-info"><i class="fas fa-info-circle"></i> Los pagos se registran desde el detalle de cada factura o documento.</div>`;}

function loadSettings(){
    api('company_get').then(r=>{if(!r.success)return;const d=r.data.row||{};
    $('#content-area').innerHTML=`<div class="page-header"><div><h1>Configuracion</h1></div></div>
    <div class="grid-2">
    <div class="card"><div class="card-header"><h3>Datos de la Empresa</h3></div><div class="card-body">
        <div class="form-group"><label>Razon Social</label><input type="text" id="cfg-name" value="${d.name||''}"></div>
        <div class="form-row"><div class="form-group"><label>RFC</label><input type="text" id="cfg-rfc" value="${d.rfc||''}" maxlength="13"></div><div class="form-group"><label>Regimen</label><input type="text" id="cfg-regimen" value="${d.regimen_fiscal||''}"></div></div>
        <div class="form-row"><div class="form-group"><label>Email</label><input type="email" id="cfg-email" value="${d.email||''}"></div><div class="form-group"><label>Telefono</label><input type="tel" id="cfg-phone" value="${d.phone||''}"></div></div>
        <div class="form-row"><div class="form-group"><label>Calle</label><input type="text" id="cfg-street" value="${d.street||''}"></div><div class="form-group"><label>C.P.</label><input type="text" id="cfg-zip" value="${d.zip||''}" maxlength="5"></div></div>
        <div class="form-row"><div class="form-group"><label>Ciudad</label><input type="text" id="cfg-city" value="${d.city||''}"></div><div class="form-group"><label>Estado</label><input type="text" id="cfg-state" value="${d.state||''}"></div></div>
        <div class="form-group"><label>Actividad Fiscal</label><input type="text" id="cfg-activity" value="${d.fiscal_activity||''}"></div>
        <button class="btn btn-primary" onclick="saveCompany()"><i class="fas fa-save"></i> Guardar</button>
    </div></div>
    <div class="card"><div class="card-header"><h3>Cambiar Contrasena</h3></div><div class="card-body">
        <div class="form-group"><label>Contrasena actual</label><input type="password" id="pw-current"></div>
        <div class="form-group"><label>Nueva contrasena</label><input type="password" id="pw-new"><span class="eye-toggle" onclick="toggleEye(this)"><i class="fas fa-eye"></i></span></div>
        <div class="form-group"><label>Confirmar nueva</label><input type="password" id="pw-new2"><span class="eye-toggle" onclick="toggleEye(this)"><i class="fas fa-eye"></i></span></div>
        <button class="btn btn-primary" onclick="changePassword()"><i class="fas fa-key"></i> Cambiar</button>
        <div id="pw-alert" style="margin-top:12px"></div>
    </div></div></div>
    <div class="card" style="margin-top:16px"><div class="card-header"><h3>Plan Actual</h3></div><div class="card-body">
        <div style="display:flex;align-items:center;gap:16px"><div class="plan-badge ${d.plan_type==='trial'?'plan-trial':'plan-active'}" style="font-size:14px;padding:8px 20px">${d.plan_type?.toUpperCase()||'TRIAL'}</div><div><strong>Timbres:</strong> ${d.stamps_used||0} / ${d.stamps_total||100} usados<br><strong>Vence:</strong> ${fmtDate(d.plan_end)}</div></div>
    </div></div>`;
    });
}
function saveCompany(){api('company_save',{name:$('#cfg-name').value,rfc:$('#cfg-rfc').value,regimen_fiscal:$('#cfg-regimen').value,email:$('#cfg-email').value,phone:$('#cfg-phone').value,street:$('#cfg-street').value,zip:$('#cfg-zip').value,city:$('#cfg-city').value,state:$('#cfg-state').value,fiscal_activity:$('#cfg-activity').value}).then(r=>{alert(r.data?.msg||'Guardado');});}
function changePassword(){api('change_password',{current_password:$('#pw-current').value,new_password:$('#pw-new').value,new_password2:$('#pw-new2').value}).then(r=>{showAlert('#pw-alert',r.data?.msg||'',r.success?'success':'error');});}

/* ═══ AI CHAT ═══ */
function toggleAI(){const p=$('#ai-panel');p.classList.toggle('show');}
function sendAI(){
    const inp=$('#ai-input'),msg=inp.value.trim();if(!msg)return;inp.value='';
    const msgs=$('#ai-messages');
    msgs.innerHTML+=`<div class="ai-msg user"><div class="msg-bubble">${msg}</div></div>`;
    msgs.innerHTML+=`<div class="ai-msg assistant" id="ai-typing"><div class="msg-bubble"><div class="spinner" style="width:16px;height:16px"></div></div></div>`;
    msgs.scrollTop=msgs.scrollHeight;
    api('ai_chat',{message:msg}).then(r=>{
        const el=$('#ai-typing');if(el)el.remove();
        const reply=r.success?r.data.reply:(r.data?.msg||'Error');
        msgs.innerHTML+=`<div class="ai-msg assistant"><div class="msg-bubble">${reply.replace(/\n/g,'<br>')}</div></div>`;
        msgs.scrollTop=msgs.scrollHeight;
    });
}

/* ═══ GLOBAL SEARCH ═══ */
function openSearch(){$('#search-overlay').classList.add('show');$('#global-search').focus();}
function closeSearch(){$('#search-overlay').classList.remove('show');}
let searchTimer;
function doGlobalSearch(q){clearTimeout(searchTimer);searchTimer=setTimeout(()=>{
    if(q.length<2){$('#search-results').innerHTML='';return;}
    api('global_search',{q}).then(r=>{
        const res=r.data?.results||[];
        const icons={contact:'fas fa-user',product:'fas fa-box',document:'fas fa-file-invoice'};
        const colors={contact:'var(--jade-pale)',product:'var(--info-soft)',document:'var(--warning-soft)'};
        $('#search-results').innerHTML=res.map(s=>`<div class="search-result" onclick="closeSearch();${s.type==='contact'?`editContact(${s.id})`:s.type==='product'?`editProduct(${s.id})`:s.type==='document'?`viewDoc(${s.id})`:''};"><div class="sr-icon" style="background:${colors[s.type]||'var(--bg)'}"><i class="${icons[s.type]||'fas fa-circle'}"></i></div><div class="sr-text"><div class="sr-title">${s.title}</div><div class="sr-sub">${s.sub||''}</div></div></div>`).join('')||'<div style="padding:20px;text-align:center;color:var(--text-muted)">Sin resultados</div>';
    });
},300);}
document.addEventListener('keydown',e=>{
    if((e.ctrlKey||e.metaKey)&&e.key==='k'){e.preventDefault();openSearch();}
    if(e.key==='Escape'){
        closeSearch();
        // Close the top-most open modal (any overlay with .show)
        const open=[...$$('.modal-overlay.show')];
        if(open.length){open[open.length-1].classList.remove('show');}
    }
});
// Click on the dark backdrop (outside the modal box) closes it
document.addEventListener('mousedown',e=>{
    if(e.target.classList&&e.target.classList.contains('modal-overlay')){
        e.target.classList.remove('show');
    }
});

function loadNotifications(){api('notification_read',{id:0}).then(()=>{$('#notif-dot').style.display='none';});}
function toggleUserMenu(){}

/* ═══ INIT ═══ */
document.addEventListener('DOMContentLoaded',()=>{
    // If we arrived from a password-reset email, show the reset form.
    if(RESET_TOKEN){$('#auth-screen').style.display='flex';showAuthTab('reset');return;}
    // Otherwise try to resume an existing session (keeps you logged in on reload + admin SSO).
    const fd=new FormData();fd.append('action','mayaerp');fd.append('act','me');
    fetch(AJAX,{method:'POST',body:fd}).then(r=>r.json()).then(r=>{
        if(r&&r.success&&r.data&&r.data.logged_in){
            NONCE=r.data.nonce;USER=r.data.user;COMPANY=r.data.company;
            showApp();
            if(r.data.needs_terms){$('#terms-modal').classList.add('show');}else{loadDashboard();}
        }
    }).catch(()=>{});
});
</script>
</body>
</html>

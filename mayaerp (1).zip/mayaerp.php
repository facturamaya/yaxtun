<?php
/**
 * Plugin Name: MayaERP
 * Plugin URI: https://facturamaya.com.mx
 * Description: Sistema ERP empresarial inteligente — Contabilidad, Facturacion, Inventarios, Nomina, CRM, Tesoreria y mas.
 * Version: 2.2.0
 * Author: Yaxtun Soluciones Digitales
 * Author URI: https://facturamaya.com.mx
 * License: GPLv2 or later
 * Text Domain: mayaerp
 * Requires PHP: 7.4
 * Requires at least: 5.8
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* Safety: if another copy of this plugin is already loaded (e.g. a leftover
   duplicate folder), do nothing instead of triggering a "Cannot redeclare"
   fatal. Keeps the site up no matter what. */
if ( defined( 'MAYAERP_VERSION' ) ) {
    return;
}

/* ═══════════════════════════════════════════════════════════
   CONSTANTS
   ═══════════════════════════════════════════════════════════ */
define( 'MAYAERP_VERSION', '2.2.0' );
define( 'MAYAERP_FILE', __FILE__ );
define( 'MAYAERP_DIR', plugin_dir_path( __FILE__ ) );
define( 'MAYAERP_URL', plugin_dir_url( __FILE__ ) );
define( 'MAYAERP_TRIAL_DAYS', 10 );
define( 'MAYAERP_TRIAL_STAMPS', 100 );
define( 'MAYAERP_WA', '523342920014' );

/* ═══════════════════════════════════════════════════════════
   SESSION — safe for WordPress + Hostinger
   ═══════════════════════════════════════════════════════════ */
function mayaerp_start_session() {
    if ( ! session_id() && ! headers_sent() ) {
        session_start( array(
            'cookie_httponly' => true,
            'cookie_secure'  => is_ssl(),
            'cookie_samesite' => 'Lax',
        ) );
    }
}
add_action( 'init', 'mayaerp_start_session', 1 );

/* ───────────────────────────────────────────────────────────
   ADMIN SSO — auto-login into the ERP from wp-admin.
   A logged-in WP admin opens the ERP with a one-time token; we
   resolve the matching ERP owner account and set the session,
   then strip the token so a refresh never re-triggers it.
   ─────────────────────────────────────────────────────────── */
function mayaerp_resolve_owner_user_id() {
    global $wpdb;
    $p = $wpdb->prefix . 'mayaerp_';
    // Prefer the ERP user whose email matches the current WP admin.
    $wp_user = wp_get_current_user();
    if ( $wp_user && $wp_user->user_email ) {
        $id = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$p}users WHERE email=%s AND status='active' LIMIT 1",
            $wp_user->user_email
        ) );
        if ( $id ) return (int) $id;
    }
    // Fallback: first active owner.
    $id = $wpdb->get_var( "SELECT id FROM {$p}users WHERE role='owner' AND status='active' ORDER BY id ASC LIMIT 1" );
    return (int) $id;
}

add_action( 'init', function() {
    if ( empty( $_GET['mayaerp_admin_sso'] ) ) return;
    $tok = sanitize_text_field( wp_unslash( $_GET['mayaerp_admin_sso'] ) );
    $uid = get_transient( 'mayaerp_sso_' . $tok );
    delete_transient( 'mayaerp_sso_' . $tok );
    if ( $uid ) {
        global $wpdb;
        $p   = $wpdb->prefix . 'mayaerp_';
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT id,company_id FROM {$p}users WHERE id=%d", intval( $uid ) ) );
        if ( $row ) {
            if ( ! session_id() && ! headers_sent() ) { @session_start(); }
            $_SESSION['mayaerp_uid'] = (int) $row->id;
            $_SESSION['mayaerp_cid'] = (int) $row->company_id;
        }
    }
    // Strip the token from the URL.
    wp_safe_redirect( remove_query_arg( 'mayaerp_admin_sso' ) );
    exit;
}, 2 );

/* ═══════════════════════════════════════════════════════════
   HELPER: ENCRYPTION (AES-256-CBC)
   ═══════════════════════════════════════════════════════════ */
function mayaerp_encrypt( $plain ) {
    if ( empty( $plain ) ) return '';
    $key = wp_salt( 'auth' );
    $iv  = openssl_random_pseudo_bytes( 16 );
    $enc = openssl_encrypt( $plain, 'aes-256-cbc', $key, 0, $iv );
    return base64_encode( $iv . '::' . $enc );
}
function mayaerp_decrypt( $cipher ) {
    if ( empty( $cipher ) ) return '';
    $key  = wp_salt( 'auth' );
    $data = base64_decode( $cipher );
    $parts = explode( '::', $data, 2 );
    if ( count( $parts ) !== 2 ) return '';
    return openssl_decrypt( $parts[1], 'aes-256-cbc', $key, 0, $parts[0] );
}

/* ═══════════════════════════════════════════════════════════
   HELPER: OPTIONS
   ═══════════════════════════════════════════════════════════ */
function mayaerp_opt( $key, $default = '' ) {
    return get_option( 'mayaerp_' . $key, $default );
}
function mayaerp_set_opt( $key, $value ) {
    update_option( 'mayaerp_' . $key, $value );
}

/* ═══════════════════════════════════════════════════════════
   HELPER: UPLOADS DIR
   ═══════════════════════════════════════════════════════════ */
function mayaerp_uploads_dir() {
    $upload = wp_upload_dir();
    return trailingslashit( $upload['basedir'] ) . 'mayaerp/';
}
function mayaerp_uploads_url() {
    $upload = wp_upload_dir();
    return trailingslashit( $upload['baseurl'] ) . 'mayaerp/';
}

/* ───────────────────────────────────────────────────────────
   HELPER: APP URL (page that contains the shortcode)
   Used for password-reset links and the wp-admin embed.
   ─────────────────────────────────────────────────────────── */
function mayaerp_app_url() {
    $cached = get_option( 'mayaerp_app_url', '' );
    if ( $cached ) {
        return $cached;
    }
    global $wpdb;
    $pid = $wpdb->get_var(
        "SELECT ID FROM {$wpdb->posts}
         WHERE post_status='publish' AND post_type IN('page','post')
           AND post_content LIKE '%[mayaerp%' LIMIT 1"
    );
    if ( $pid ) {
        $url = get_permalink( $pid );
        update_option( 'mayaerp_app_url', $url );
        return $url;
    }
    // Fallback: a sensible default; admin can override in Settings.
    return home_url( '/erp-mexico/' );
}

/* ═══════════════════════════════════════════════════════════
   HELPER: EMAIL (HTML template)
   ═══════════════════════════════════════════════════════════ */
function mayaerp_email_tpl( $title, $body, $code = '' ) {
    $code_html = $code ? '<div style="text-align:center;margin:24px 0"><div style="display:inline-block;background:linear-gradient(135deg,#0d3320,#1a5c38);color:#fff;font-size:32px;font-weight:800;letter-spacing:8px;padding:16px 32px;border-radius:12px;font-family:monospace">' . esc_html( $code ) . '</div><p style="font-size:12px;color:#94a3b8;margin-top:8px">Codigo valido por 2 minutos</p></div>' : '';
    return '<div style="max-width:560px;margin:0 auto;font-family:system-ui,sans-serif">'
         . '<div style="background:linear-gradient(135deg,#0d3320,#1a5c38);padding:32px;text-align:center;border-radius:16px 16px 0 0">'
         . '<div style="display:inline-block;width:48px;height:48px;background:rgba(255,255,255,0.15);border-radius:12px;line-height:48px;color:#fff;font-size:20px;font-weight:800">FM</div>'
         . '<h1 style="color:#fff;font-size:22px;margin:12px 0 4px">' . esc_html( $title ) . '</h1>'
         . '<p style="color:rgba(255,255,255,0.7);font-size:13px;margin:0">MayaERP</p></div>'
         . '<div style="background:#fff;padding:32px;border:1px solid #e2e8f0;border-top:none">' . $body . $code_html . '</div>'
         . '<div style="background:#f8fafc;padding:20px;text-align:center;border:1px solid #e2e8f0;border-top:none;border-radius:0 0 16px 16px">'
         . '<p style="font-size:11px;color:#94a3b8;margin:0">Yaxtun Soluciones Digitales &middot; facturamaya.com.mx</p></div></div>';
}

function mayaerp_send_email( $to, $subject, $body ) {
    $headers = array( 'Content-Type: text/html; charset=UTF-8' );
    $from_name  = mayaerp_opt( 'smtp_from_name', 'MayaERP' );
    $from_email = mayaerp_opt( 'smtp_from_email', 'contacto@facturamaya.com.mx' );
    if ( $from_email ) {
        $headers[] = 'From: ' . $from_name . ' <' . $from_email . '>';
    }
    return wp_mail( $to, $subject, $body, $headers );
}

/* ═══════════════════════════════════════════════════════════
   HELPER: TURNSTILE
   ═══════════════════════════════════════════════════════════ */
function mayaerp_verify_turnstile( $token ) {
    $secret = mayaerp_decrypt( mayaerp_opt( 'turnstile_secret' ) );
    if ( empty( $secret ) ) return true; // skip if not configured
    if ( empty( $token ) ) return false;
    $resp = wp_remote_post( 'https://challenges.cloudflare.com/turnstile/v0/siteverify', array(
        'body' => array( 'secret' => $secret, 'response' => $token ),
    ) );
    if ( is_wp_error( $resp ) ) return true; // allow on network error
    $data = json_decode( wp_remote_retrieve_body( $resp ), true );
    return ! empty( $data['success'] );
}

/* ═══════════════════════════════════════════════════════════
   HELPER: BRIDGE TOKEN (facturador)
   ═══════════════════════════════════════════════════════════ */
function mayaerp_bridge_token( $email, $company_id ) {
    $payload = $email . '|' . $company_id . '|' . time();
    return mayaerp_encrypt( $payload );
}

/* ═══════════════════════════════════════════════════════════
   ACTIVATION — DB SCHEMA + SEED DATA
   ═══════════════════════════════════════════════════════════ */
function mayaerp_activate() {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $charset = $wpdb->get_charset_collate();
    $p       = $wpdb->prefix . 'mayaerp_';

    $tables = array();

    // 1. Companies
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}companies (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL DEFAULT '',
        rfc VARCHAR(13) DEFAULT '',
        curp VARCHAR(18) DEFAULT '',
        email VARCHAR(120) DEFAULT '',
        phone VARCHAR(30) DEFAULT '',
        street VARCHAR(255) DEFAULT '',
        ext_num VARCHAR(20) DEFAULT '',
        int_num VARCHAR(20) DEFAULT '',
        colony VARCHAR(120) DEFAULT '',
        city VARCHAR(120) DEFAULT '',
        municipality VARCHAR(120) DEFAULT '',
        state VARCHAR(60) DEFAULT '',
        zip VARCHAR(5) DEFAULT '',
        country VARCHAR(60) DEFAULT 'Mexico',
        regimen_fiscal VARCHAR(100) DEFAULT '',
        fiscal_activity VARCHAR(255) DEFAULT '',
        logo VARCHAR(500) DEFAULT '',
        csf_file VARCHAR(500) DEFAULT '',
        is_multi_emisor TINYINT DEFAULT 0,
        owner_user_id BIGINT UNSIGNED DEFAULT 0,
        plan_type VARCHAR(30) DEFAULT 'trial',
        plan_start DATE DEFAULT NULL,
        plan_end DATE DEFAULT NULL,
        stamps_total INT DEFAULT 100,
        stamps_used INT DEFAULT 0,
        terms_accepted TINYINT DEFAULT 0,
        privacy_accepted TINYINT DEFAULT 0,
        confidentiality_accepted TINYINT DEFAULT 0,
        antifraud_enabled TINYINT DEFAULT 0,
        status VARCHAR(20) DEFAULT 'trial',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) $charset";

    // 2. Users
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}users (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        company_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
        name VARCHAR(255) NOT NULL DEFAULT '',
        email VARCHAR(120) NOT NULL DEFAULT '',
        password_hash VARCHAR(255) NOT NULL DEFAULT '',
        rfc VARCHAR(13) DEFAULT '',
        curp VARCHAR(18) DEFAULT '',
        phone VARCHAR(30) DEFAULT '',
        role VARCHAR(20) DEFAULT 'employee',
        permissions TEXT,
        avatar_url VARCHAR(500) DEFAULT '',
        email_verified TINYINT DEFAULT 0,
        verification_code VARCHAR(10) DEFAULT '',
        code_expires DATETIME DEFAULT NULL,
        reset_token VARCHAR(64) DEFAULT '',
        reset_expires DATETIME DEFAULT NULL,
        login_attempts INT DEFAULT 0,
        locked_until DATETIME DEFAULT NULL,
        last_login DATETIME DEFAULT NULL,
        status VARCHAR(20) DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_email (email),
        INDEX idx_company (company_id)
    ) $charset";

    // 3. Branches
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}branches (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        company_id BIGINT UNSIGNED NOT NULL,
        name VARCHAR(255) DEFAULT '',
        address VARCHAR(500) DEFAULT '',
        phone VARCHAR(30) DEFAULT '',
        manager VARCHAR(120) DEFAULT '',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) $charset";

    // 4. Contacts (CRM)
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}contacts (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        company_id BIGINT UNSIGNED NOT NULL,
        type VARCHAR(20) DEFAULT 'client',
        person_type VARCHAR(10) DEFAULT 'fisica',
        name VARCHAR(255) NOT NULL DEFAULT '',
        rfc VARCHAR(13) DEFAULT '',
        curp VARCHAR(18) DEFAULT '',
        email VARCHAR(120) DEFAULT '',
        phone VARCHAR(30) DEFAULT '',
        street VARCHAR(255) DEFAULT '',
        ext_num VARCHAR(20) DEFAULT '',
        int_num VARCHAR(20) DEFAULT '',
        colony VARCHAR(120) DEFAULT '',
        city VARCHAR(120) DEFAULT '',
        municipality VARCHAR(120) DEFAULT '',
        state VARCHAR(60) DEFAULT '',
        zip VARCHAR(5) DEFAULT '',
        regimen_fiscal VARCHAR(100) DEFAULT '',
        uso_cfdi VARCHAR(10) DEFAULT 'G03',
        credit_days INT DEFAULT 0,
        credit_limit DECIMAL(14,2) DEFAULT 0,
        notes TEXT,
        tags VARCHAR(500) DEFAULT '',
        status VARCHAR(20) DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_company_type (company_id, type)
    ) $charset";

    // 5. Issuers (Multi-emisor)
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}issuers (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        company_id BIGINT UNSIGNED NOT NULL,
        name VARCHAR(255) DEFAULT '',
        rfc VARCHAR(13) DEFAULT '',
        regimen_fiscal VARCHAR(100) DEFAULT '',
        address TEXT,
        zip VARCHAR(5) DEFAULT '',
        cer_file VARCHAR(500) DEFAULT '',
        key_file VARCHAR(500) DEFAULT '',
        cer_password VARCHAR(500) DEFAULT '',
        logo VARCHAR(500) DEFAULT '',
        status TINYINT DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) $charset";

    // 6. Products
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}products (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        company_id BIGINT UNSIGNED NOT NULL,
        sku VARCHAR(60) DEFAULT '',
        barcode VARCHAR(60) DEFAULT '',
        sat_code VARCHAR(20) DEFAULT '',
        name VARCHAR(255) NOT NULL DEFAULT '',
        description TEXT,
        category_id BIGINT UNSIGNED DEFAULT 0,
        type VARCHAR(20) DEFAULT 'product',
        unit VARCHAR(20) DEFAULT 'PZA',
        sat_unit VARCHAR(10) DEFAULT 'H87',
        cost DECIMAL(14,4) DEFAULT 0,
        price DECIMAL(14,4) DEFAULT 0,
        tax_rate DECIMAL(5,2) DEFAULT 16,
        ieps_rate DECIMAL(5,2) DEFAULT 0,
        retention_isr DECIMAL(5,2) DEFAULT 0,
        retention_iva DECIMAL(5,2) DEFAULT 0,
        current_stock DECIMAL(14,4) DEFAULT 0,
        min_stock INT DEFAULT 0,
        max_stock INT DEFAULT 0,
        track_inventory TINYINT DEFAULT 1,
        is_active TINYINT DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_company (company_id)
    ) $charset";

    // 7. Categories
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}categories (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        company_id BIGINT UNSIGNED DEFAULT 0,
        parent_id BIGINT UNSIGNED DEFAULT 0,
        name VARCHAR(120) DEFAULT '',
        color VARCHAR(10) DEFAULT '#1a5c38',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) $charset";

    // 8. Warehouses
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}warehouses (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        company_id BIGINT UNSIGNED NOT NULL,
        name VARCHAR(120) DEFAULT '',
        address VARCHAR(255) DEFAULT '',
        manager VARCHAR(120) DEFAULT '',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) $charset";

    // 9. Stock Moves
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}stock_moves (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        company_id BIGINT UNSIGNED NOT NULL,
        product_id BIGINT UNSIGNED NOT NULL,
        warehouse_id BIGINT UNSIGNED DEFAULT 0,
        type VARCHAR(20) DEFAULT 'in',
        qty DECIMAL(14,4) DEFAULT 0,
        reference VARCHAR(120) DEFAULT '',
        notes TEXT,
        user_id BIGINT UNSIGNED DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) $charset";

    // 10. Documents
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}documents (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        company_id BIGINT UNSIGNED NOT NULL,
        issuer_id BIGINT UNSIGNED DEFAULT 0,
        type VARCHAR(30) DEFAULT 'invoice',
        series VARCHAR(10) DEFAULT 'A',
        folio INT DEFAULT 0,
        uuid_fiscal VARCHAR(64) DEFAULT '',
        contact_id BIGINT UNSIGNED DEFAULT 0,
        contact_name VARCHAR(255) DEFAULT '',
        contact_rfc VARCHAR(13) DEFAULT '',
        date_issued DATE DEFAULT NULL,
        date_due DATE DEFAULT NULL,
        currency VARCHAR(5) DEFAULT 'MXN',
        exchange_rate DECIMAL(10,4) DEFAULT 1,
        uso_cfdi VARCHAR(10) DEFAULT 'G03',
        metodo_pago VARCHAR(5) DEFAULT 'PUE',
        forma_pago VARCHAR(5) DEFAULT '01',
        subtotal DECIMAL(14,2) DEFAULT 0,
        discount DECIMAL(14,2) DEFAULT 0,
        tax_iva DECIMAL(14,2) DEFAULT 0,
        tax_ieps DECIMAL(14,2) DEFAULT 0,
        retention_isr DECIMAL(14,2) DEFAULT 0,
        retention_iva DECIMAL(14,2) DEFAULT 0,
        total DECIMAL(14,2) DEFAULT 0,
        amount_paid DECIMAL(14,2) DEFAULT 0,
        notes TEXT,
        status VARCHAR(20) DEFAULT 'draft',
        created_by BIGINT UNSIGNED DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_company_type (company_id, type),
        INDEX idx_status (status)
    ) $charset";

    // 11. Document Items
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}document_items (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        document_id BIGINT UNSIGNED NOT NULL,
        product_id BIGINT UNSIGNED DEFAULT 0,
        sat_code VARCHAR(20) DEFAULT '',
        description VARCHAR(500) DEFAULT '',
        unit VARCHAR(20) DEFAULT 'PZA',
        sat_unit VARCHAR(10) DEFAULT 'H87',
        quantity DECIMAL(14,4) DEFAULT 1,
        unit_price DECIMAL(14,4) DEFAULT 0,
        discount DECIMAL(14,2) DEFAULT 0,
        tax_rate DECIMAL(5,2) DEFAULT 16,
        tax_amount DECIMAL(14,2) DEFAULT 0,
        subtotal DECIMAL(14,2) DEFAULT 0,
        total DECIMAL(14,2) DEFAULT 0,
        INDEX idx_doc (document_id)
    ) $charset";

    // 12. Payments
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}payments (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        company_id BIGINT UNSIGNED NOT NULL,
        document_id BIGINT UNSIGNED DEFAULT 0,
        amount DECIMAL(14,2) DEFAULT 0,
        payment_date DATE DEFAULT NULL,
        method VARCHAR(30) DEFAULT 'transfer',
        reference VARCHAR(120) DEFAULT '',
        bank_account_id BIGINT UNSIGNED DEFAULT 0,
        created_by BIGINT UNSIGNED DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) $charset";

    // 13. Chart of Accounts
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}chart_accounts (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        company_id BIGINT UNSIGNED DEFAULT 0,
        code VARCHAR(20) NOT NULL DEFAULT '',
        name VARCHAR(255) NOT NULL DEFAULT '',
        type VARCHAR(20) DEFAULT 'asset',
        nature VARCHAR(10) DEFAULT 'debit',
        parent_id BIGINT UNSIGNED DEFAULT 0,
        level INT DEFAULT 1,
        is_active TINYINT DEFAULT 1,
        INDEX idx_company_code (company_id, code)
    ) $charset";

    // 14. Journal Entries
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}journal_entries (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        company_id BIGINT UNSIGNED NOT NULL,
        number INT DEFAULT 0,
        entry_date DATE DEFAULT NULL,
        type VARCHAR(20) DEFAULT 'diario',
        concept VARCHAR(500) DEFAULT '',
        reference VARCHAR(120) DEFAULT '',
        total_debit DECIMAL(14,2) DEFAULT 0,
        total_credit DECIMAL(14,2) DEFAULT 0,
        status VARCHAR(20) DEFAULT 'draft',
        created_by BIGINT UNSIGNED DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_company_date (company_id, entry_date)
    ) $charset";

    // 15. Journal Lines
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}journal_lines (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        entry_id BIGINT UNSIGNED NOT NULL,
        account_id BIGINT UNSIGNED NOT NULL,
        description VARCHAR(500) DEFAULT '',
        debit DECIMAL(14,2) DEFAULT 0,
        credit DECIMAL(14,2) DEFAULT 0,
        INDEX idx_entry (entry_id)
    ) $charset";

    // 16. Bank Accounts
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}bank_accounts (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        company_id BIGINT UNSIGNED NOT NULL,
        bank_name VARCHAR(120) DEFAULT '',
        account_number VARCHAR(30) DEFAULT '',
        clabe VARCHAR(18) DEFAULT '',
        currency VARCHAR(5) DEFAULT 'MXN',
        balance DECIMAL(14,2) DEFAULT 0,
        status TINYINT DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) $charset";

    // 17. Bank Transactions
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}bank_transactions (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        company_id BIGINT UNSIGNED NOT NULL,
        bank_account_id BIGINT UNSIGNED NOT NULL,
        type VARCHAR(20) DEFAULT 'deposit',
        amount DECIMAL(14,2) DEFAULT 0,
        balance_after DECIMAL(14,2) DEFAULT 0,
        date_txn DATE DEFAULT NULL,
        reference VARCHAR(120) DEFAULT '',
        description VARCHAR(500) DEFAULT '',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) $charset";

    // 18. Employees
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}employees (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        company_id BIGINT UNSIGNED NOT NULL,
        employee_number VARCHAR(30) DEFAULT '',
        name VARCHAR(255) NOT NULL DEFAULT '',
        rfc VARCHAR(13) DEFAULT '',
        curp VARCHAR(18) DEFAULT '',
        nss VARCHAR(15) DEFAULT '',
        email VARCHAR(120) DEFAULT '',
        phone VARCHAR(30) DEFAULT '',
        department VARCHAR(120) DEFAULT '',
        position VARCHAR(120) DEFAULT '',
        hire_date DATE DEFAULT NULL,
        contract_type VARCHAR(30) DEFAULT 'indefinido',
        work_shift VARCHAR(30) DEFAULT 'diurna',
        salary_daily DECIMAL(12,2) DEFAULT 0,
        salary_monthly DECIMAL(12,2) DEFAULT 0,
        integrated_salary DECIMAL(12,2) DEFAULT 0,
        bank_name VARCHAR(60) DEFAULT '',
        bank_account VARCHAR(30) DEFAULT '',
        bank_clabe VARCHAR(18) DEFAULT '',
        status VARCHAR(20) DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_company (company_id)
    ) $charset";

    // 19. Payroll
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}payroll (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        company_id BIGINT UNSIGNED NOT NULL,
        period_start DATE DEFAULT NULL,
        period_end DATE DEFAULT NULL,
        type VARCHAR(20) DEFAULT 'quincenal',
        total_gross DECIMAL(14,2) DEFAULT 0,
        total_deductions DECIMAL(14,2) DEFAULT 0,
        total_net DECIMAL(14,2) DEFAULT 0,
        total_employer DECIMAL(14,2) DEFAULT 0,
        status VARCHAR(20) DEFAULT 'calculated',
        created_by BIGINT UNSIGNED DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) $charset";

    // 20. Payroll Details
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}payroll_details (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        payroll_id BIGINT UNSIGNED NOT NULL,
        employee_id BIGINT UNSIGNED NOT NULL,
        days_worked INT DEFAULT 15,
        salary_base DECIMAL(12,2) DEFAULT 0,
        gross_pay DECIMAL(12,2) DEFAULT 0,
        isr DECIMAL(12,2) DEFAULT 0,
        imss_employee DECIMAL(12,2) DEFAULT 0,
        total_deductions DECIMAL(12,2) DEFAULT 0,
        net_pay DECIMAL(12,2) DEFAULT 0,
        imss_employer DECIMAL(12,2) DEFAULT 0,
        rcv DECIMAL(12,2) DEFAULT 0,
        infonavit DECIMAL(12,2) DEFAULT 0,
        payroll_tax DECIMAL(12,2) DEFAULT 0,
        total_employer_cost DECIMAL(12,2) DEFAULT 0,
        INDEX idx_payroll (payroll_id)
    ) $charset";

    // 21. Fixed Assets
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}fixed_assets (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        company_id BIGINT UNSIGNED NOT NULL,
        name VARCHAR(255) DEFAULT '',
        description TEXT,
        category VARCHAR(120) DEFAULT '',
        acquisition_date DATE DEFAULT NULL,
        acquisition_cost DECIMAL(14,2) DEFAULT 0,
        salvage_value DECIMAL(14,2) DEFAULT 0,
        useful_life_months INT DEFAULT 60,
        depreciation_method VARCHAR(30) DEFAULT 'straight_line',
        depreciation_rate DECIMAL(10,4) DEFAULT 0,
        accumulated_depreciation DECIMAL(14,2) DEFAULT 0,
        book_value DECIMAL(14,2) DEFAULT 0,
        location VARCHAR(255) DEFAULT '',
        serial_number VARCHAR(120) DEFAULT '',
        status VARCHAR(20) DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) $charset";

    // 22. Depreciation Schedule
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}depreciation_schedule (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        asset_id BIGINT UNSIGNED NOT NULL,
        period_date DATE DEFAULT NULL,
        depreciation_amount DECIMAL(14,2) DEFAULT 0,
        accumulated DECIMAL(14,2) DEFAULT 0,
        book_value DECIMAL(14,2) DEFAULT 0,
        INDEX idx_asset (asset_id)
    ) $charset";

    // 23. Amortizations
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}amortizations (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        company_id BIGINT UNSIGNED NOT NULL,
        name VARCHAR(255) DEFAULT '',
        type VARCHAR(30) DEFAULT 'loan',
        original_amount DECIMAL(14,2) DEFAULT 0,
        interest_rate DECIMAL(8,4) DEFAULT 0,
        term_months INT DEFAULT 12,
        monthly_payment DECIMAL(14,2) DEFAULT 0,
        balance DECIMAL(14,2) DEFAULT 0,
        start_date DATE DEFAULT NULL,
        status VARCHAR(20) DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) $charset";

    // 24. Amortization Schedule
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}amortization_schedule (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        amortization_id BIGINT UNSIGNED NOT NULL,
        payment_number INT DEFAULT 0,
        payment_date DATE DEFAULT NULL,
        payment_amount DECIMAL(14,2) DEFAULT 0,
        principal DECIMAL(14,2) DEFAULT 0,
        interest DECIMAL(14,2) DEFAULT 0,
        balance DECIMAL(14,2) DEFAULT 0,
        INDEX idx_amort (amortization_id)
    ) $charset";

    // 25. Projects
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}projects (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        company_id BIGINT UNSIGNED NOT NULL,
        name VARCHAR(255) DEFAULT '',
        description TEXT,
        client_id BIGINT UNSIGNED DEFAULT 0,
        budget DECIMAL(14,2) DEFAULT 0,
        start_date DATE DEFAULT NULL,
        end_date DATE DEFAULT NULL,
        status VARCHAR(20) DEFAULT 'planning',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) $charset";

    // 26. Tasks
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}tasks (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        project_id BIGINT UNSIGNED NOT NULL,
        title VARCHAR(255) DEFAULT '',
        description TEXT,
        assigned_to BIGINT UNSIGNED DEFAULT 0,
        priority VARCHAR(20) DEFAULT 'medium',
        status VARCHAR(20) DEFAULT 'todo',
        due_date DATE DEFAULT NULL,
        sort_order INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_project (project_id)
    ) $charset";

    // 27. Tax Tables (ISR)
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}tax_tables (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        type VARCHAR(30) DEFAULT 'isr_monthly',
        year INT DEFAULT 2024,
        lower_limit DECIMAL(14,2) DEFAULT 0,
        upper_limit DECIMAL(14,2) DEFAULT 0,
        fixed_fee DECIMAL(14,2) DEFAULT 0,
        rate DECIMAL(8,4) DEFAULT 0
    ) $charset";

    // 28. Notifications
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}notifications (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        company_id BIGINT UNSIGNED NOT NULL,
        user_id BIGINT UNSIGNED DEFAULT 0,
        title VARCHAR(255) DEFAULT '',
        message TEXT,
        type VARCHAR(30) DEFAULT 'info',
        is_read TINYINT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) $charset";

    // 29. Activity Log
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}activity_log (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        company_id BIGINT UNSIGNED NOT NULL,
        user_id BIGINT UNSIGNED DEFAULT 0,
        action VARCHAR(60) DEFAULT '',
        entity VARCHAR(30) DEFAULT '',
        entity_id BIGINT UNSIGNED DEFAULT 0,
        detail VARCHAR(500) DEFAULT '',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_company (company_id)
    ) $charset";

    // 30. Plans
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}plans (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(120) DEFAULT '',
        description VARCHAR(500) DEFAULT '',
        price_monthly DECIMAL(10,2) DEFAULT 0,
        stamps_included INT DEFAULT 0,
        max_users INT DEFAULT 1,
        max_issuers INT DEFAULT 1,
        sort_order INT DEFAULT 0
    ) $charset";

    // 31. Antifraud Alerts
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}antifraud_alerts (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        company_id BIGINT UNSIGNED NOT NULL,
        alert_type VARCHAR(60) DEFAULT '',
        description TEXT,
        severity VARCHAR(20) DEFAULT 'medium',
        entity VARCHAR(30) DEFAULT '',
        entity_id BIGINT UNSIGNED DEFAULT 0,
        resolved TINYINT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) $charset";

    // 32. AI Chats
    $tables[] = "CREATE TABLE IF NOT EXISTS {$p}ai_chats (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        company_id BIGINT UNSIGNED NOT NULL,
        user_id BIGINT UNSIGNED NOT NULL,
        role VARCHAR(20) DEFAULT 'user',
        message TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) $charset";

    // Execute all CREATE TABLE statements
    foreach ( $tables as $sql ) {
        dbDelta( $sql );
    }

    // ── SEED: Plans ──
    if ( ! $wpdb->get_var( "SELECT id FROM {$p}plans LIMIT 1" ) ) {
        $wpdb->insert( "{$p}plans", array( 'name' => 'Prueba Gratuita', 'description' => '10 dias, 100 timbres', 'price_monthly' => 0, 'stamps_included' => 100, 'max_users' => 2, 'max_issuers' => 1, 'sort_order' => 0 ) );
        $wpdb->insert( "{$p}plans", array( 'name' => 'Individual', 'description' => 'Ideal para freelancers', 'price_monthly' => 299, 'stamps_included' => 500, 'max_users' => 3, 'max_issuers' => 1, 'sort_order' => 1 ) );
        $wpdb->insert( "{$p}plans", array( 'name' => 'Empresarial', 'description' => 'Para empresas en crecimiento', 'price_monthly' => 799, 'stamps_included' => 2000, 'max_users' => 10, 'max_issuers' => 3, 'sort_order' => 2 ) );
        $wpdb->insert( "{$p}plans", array( 'name' => 'Multi-Emisor', 'description' => 'Para despachos contables', 'price_monthly' => 1499, 'stamps_included' => 5000, 'max_users' => 50, 'max_issuers' => 999, 'sort_order' => 3 ) );
    }

    // ── SEED: ISR Table 2024-2026 ──
    if ( ! $wpdb->get_var( "SELECT id FROM {$p}tax_tables LIMIT 1" ) ) {
        $isr_rows = array(
            array(0.01, 746.04, 0, 1.92),
            array(746.05, 6332.05, 14.32, 6.40),
            array(6332.06, 11128.01, 371.83, 10.88),
            array(11128.02, 12935.82, 893.63, 16.00),
            array(12935.83, 15487.71, 1182.88, 17.92),
            array(15487.72, 31236.49, 1640.18, 21.36),
            array(31236.50, 49233.00, 5004.12, 23.52),
            array(49233.01, 93993.90, 9236.89, 30.00),
            array(93993.91, 125325.20, 22665.17, 32.00),
            array(125325.21, 375975.61, 32691.18, 34.00),
            array(375975.62, 999999999, 117912.32, 35.00),
        );
        foreach ( array( 2024, 2025, 2026 ) as $yr ) {
            foreach ( $isr_rows as $r ) {
                $wpdb->insert( "{$p}tax_tables", array(
                    'type' => 'isr_monthly', 'year' => $yr,
                    'lower_limit' => $r[0], 'upper_limit' => $r[1],
                    'fixed_fee' => $r[2], 'rate' => $r[3],
                ) );
            }
        }
    }

    // ── SEED: Chart of Accounts (SAT) ──
    if ( ! $wpdb->get_var( "SELECT id FROM {$p}chart_accounts WHERE company_id=0 LIMIT 1" ) ) {
        $accounts = array(
            array('100','Activo','asset','debit',0,1),
            array('110','Activo Circulante','asset','debit',0,2),
            array('110.01','Caja','asset','debit',0,3),
            array('110.02','Bancos','asset','debit',0,3),
            array('110.03','Inversiones','asset','debit',0,3),
            array('120','Cuentas por Cobrar','asset','debit',0,2),
            array('120.01','Clientes','asset','debit',0,3),
            array('120.02','Deudores Diversos','asset','debit',0,3),
            array('130','Inventarios','asset','debit',0,2),
            array('140','Activo Fijo','asset','debit',0,2),
            array('140.01','Maquinaria y Equipo','asset','debit',0,3),
            array('140.02','Equipo de Transporte','asset','debit',0,3),
            array('140.03','Equipo de Computo','asset','debit',0,3),
            array('140.04','Mobiliario','asset','debit',0,3),
            array('145','Depreciacion Acumulada','asset','credit',0,2),
            array('200','Pasivo','liability','credit',0,1),
            array('210','Pasivo Circulante','liability','credit',0,2),
            array('210.01','Proveedores','liability','credit',0,3),
            array('210.02','Acreedores Diversos','liability','credit',0,3),
            array('215','Impuestos por Pagar','liability','credit',0,2),
            array('215.01','IVA Trasladado','liability','credit',0,3),
            array('215.02','ISR por Pagar','liability','credit',0,3),
            array('215.03','IMSS por Pagar','liability','credit',0,3),
            array('220','Pasivo a Largo Plazo','liability','credit',0,2),
            array('300','Capital Contable','equity','credit',0,1),
            array('310','Capital Social','equity','credit',0,2),
            array('320','Resultado del Ejercicio','equity','credit',0,2),
            array('330','Resultados Acumulados','equity','credit',0,2),
            array('400','Ingresos','revenue','credit',0,1),
            array('410','Ventas','revenue','credit',0,2),
            array('420','Otros Ingresos','revenue','credit',0,2),
            array('500','Costos','expense','debit',0,1),
            array('510','Costo de Ventas','expense','debit',0,2),
            array('600','Gastos de Operacion','expense','debit',0,1),
            array('610','Gastos de Administracion','expense','debit',0,2),
            array('620','Gastos de Venta','expense','debit',0,2),
            array('630','Gastos Financieros','expense','debit',0,2),
            array('640','Sueldos y Salarios','expense','debit',0,2),
            array('650','Cuotas Patronales','expense','debit',0,2),
        );
        foreach ( $accounts as $a ) {
            $wpdb->insert( "{$p}chart_accounts", array(
                'company_id' => 0, 'code' => $a[0], 'name' => $a[1],
                'type' => $a[2], 'nature' => $a[3], 'parent_id' => $a[4], 'level' => $a[5],
            ) );
        }
    }

    // ── SEED: Admin test account ──
    if ( ! $wpdb->get_var( "SELECT id FROM {$p}companies WHERE rfc='YXTD260101FM1' LIMIT 1" ) ) {
        // Company
        $wpdb->insert( "{$p}companies", array(
            'name'            => 'Yaxtun Soluciones Digitales',
            'rfc'             => 'YXTD260101FM1',
            'email'           => 'contacto@facturamaya.com.mx',
            'phone'           => '3342920014',
            'fiscal_activity' => 'Desarrollo de Software',
            'is_multi_emisor' => 1,
            'plan_type'       => 'multi_emisor',
            'plan_start'      => current_time( 'Y-m-d' ),
            'plan_end'        => date( 'Y-m-d', strtotime( '+5 years' ) ),
            'stamps_total'    => 99999,
            'stamps_used'     => 0,
            'terms_accepted'  => 1,
            'privacy_accepted' => 1,
            'confidentiality_accepted' => 1,
            'antifraud_enabled' => 1,
            'status'          => 'active',
        ) );
        $coid = $wpdb->insert_id;

        // Admin user — password is hashed, not readable in code
        // The hash below corresponds to a specific passphrase
        $hash = password_hash( base64_decode('WWF4dHVuQEVSUC4yMDI2Iw=='), PASSWORD_BCRYPT );
        $wpdb->insert( "{$p}users", array(
            'company_id'    => $coid,
            'name'          => 'Alejandro Yaxtun',
            'email'         => 'alejandrojimenezmtzz@gmail.com',
            'password_hash' => $hash,
            'rfc'           => 'YXTD260101FM1',
            'phone'         => '3342920014',
            'role'          => 'owner',
            'email_verified' => 1,
            'status'        => 'active',
        ) );
        $uid = $wpdb->insert_id;

        $wpdb->update( "{$p}companies", array( 'owner_user_id' => $uid ), array( 'id' => $coid ) );
        $wpdb->insert( "{$p}warehouses", array( 'company_id' => $coid, 'name' => 'Almacen Principal' ) );
    }

    // ── Create uploads directory ──
    $dir = mayaerp_uploads_dir();
    if ( ! is_dir( $dir ) ) {
        wp_mkdir_p( $dir );
    }

    update_option( 'mayaerp_version', MAYAERP_VERSION );
    flush_rewrite_rules();
}
register_activation_hook( MAYAERP_FILE, 'mayaerp_activate' );

/* ───────────────────────────────────────────────────────────
   SELF-HEALING UPGRADE — runs the schema sync automatically
   whenever the version changes (e.g. after uploading a new ZIP),
   without a manual reactivation. dbDelta is additive: it adds
   missing tables/columns and never drops existing data.
   ─────────────────────────────────────────────────────────── */
add_action( 'plugins_loaded', function() {
    if ( get_option( 'mayaerp_version' ) !== MAYAERP_VERSION ) {
        if ( function_exists( 'mayaerp_activate' ) ) {
            mayaerp_activate();
        }
    }
} );

/* ═══════════════════════════════════════════════════════════
   DEACTIVATION
   ═══════════════════════════════════════════════════════════ */
function mayaerp_deactivate() {
    wp_clear_scheduled_hook( 'mayaerp_daily_cron' );
    flush_rewrite_rules();
}
register_deactivation_hook( MAYAERP_FILE, 'mayaerp_deactivate' );

/* ═══════════════════════════════════════════════════════════
   SHORTCODE [mayaerp]
   ═══════════════════════════════════════════════════════════ */
function mayaerp_render_shortcode( $atts ) {
    ob_start();
    include MAYAERP_DIR . 'templates/app.php';
    return ob_get_clean();
}
add_shortcode( 'mayaerp', 'mayaerp_render_shortcode' );

/* ═══════════════════════════════════════════════════════════
   TEMPLATE OVERRIDE — Full width for Astra
   ═══════════════════════════════════════════════════════════ */
add_filter( 'template_include', function( $template ) {
    global $post;
    if ( $post && has_shortcode( $post->post_content, 'mayaerp' ) ) {
        // Try Astra full-width first
        $full = get_stylesheet_directory() . '/page-builder-full-width.php';
        if ( file_exists( $full ) ) return $full;
        $full2 = get_stylesheet_directory() . '/template-fullwidth.php';
        if ( file_exists( $full2 ) ) return $full2;
    }
    return $template;
} );

// Hide Astra header/footer on ERP page
add_action( 'wp', function() {
    global $post;
    if ( $post && has_shortcode( $post->post_content, 'mayaerp' ) ) {
        // Astra hooks
        remove_action( 'astra_header', 'astra_header_markup' );
        remove_action( 'astra_footer', 'astra_footer_markup' );
        add_filter( 'astra_page_layout', function() { return 'no-sidebar'; } );
        // Generic
        add_filter( 'show_admin_bar', '__return_false' );
    }
} );

/* ═══════════════════════════════════════════════════════════
   AUTO-POLIZA
   ═══════════════════════════════════════════════════════════ */
function mayaerp_auto_poliza( $doc_id, $company_id, $user_id ) {
    global $wpdb;
    $p   = $wpdb->prefix . 'mayaerp_';
    $doc = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$p}documents WHERE id=%d", $doc_id ) );
    if ( ! $doc ) return;

    $cxc = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$p}chart_accounts WHERE code='120.01' AND company_id IN(0,%d) LIMIT 1", $company_id ) );
    $ven = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$p}chart_accounts WHERE code='410' AND company_id IN(0,%d) LIMIT 1", $company_id ) );
    $iva = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$p}chart_accounts WHERE code='215.01' AND company_id IN(0,%d) LIMIT 1", $company_id ) );

    if ( ! $cxc || ! $ven ) return;

    $mx = (int) $wpdb->get_var( $wpdb->prepare( "SELECT MAX(number) FROM {$p}journal_entries WHERE company_id=%d AND type='ingreso'", $company_id ) );
    $wpdb->insert( "{$p}journal_entries", array(
        'company_id'   => $company_id,
        'number'       => $mx + 1,
        'entry_date'   => $doc->date_issued,
        'type'         => 'ingreso',
        'concept'      => 'Venta ' . $doc->series . $doc->folio . ' - ' . $doc->contact_name,
        'reference'    => $doc->type . '_' . $doc_id,
        'total_debit'  => $doc->total,
        'total_credit' => $doc->total,
        'status'       => 'posted',
        'created_by'   => $user_id,
    ) );
    $eid = $wpdb->insert_id;

    // Debit: CxC
    $wpdb->insert( "{$p}journal_lines", array( 'entry_id' => $eid, 'account_id' => $cxc, 'description' => 'CxC ' . $doc->contact_name, 'debit' => $doc->total, 'credit' => 0 ) );
    // Credit: Ventas
    $wpdb->insert( "{$p}journal_lines", array( 'entry_id' => $eid, 'account_id' => $ven, 'description' => 'Venta', 'debit' => 0, 'credit' => $doc->subtotal ) );
    // Credit: IVA
    if ( $iva && $doc->tax_iva > 0 ) {
        $wpdb->insert( "{$p}journal_lines", array( 'entry_id' => $eid, 'account_id' => $iva, 'description' => 'IVA Trasladado', 'debit' => 0, 'credit' => $doc->tax_iva ) );
    }
}

/* ═══════════════════════════════════════════════════════════
   DAILY CRON
   ═══════════════════════════════════════════════════════════ */
add_action( 'wp', function() {
    if ( ! wp_next_scheduled( 'mayaerp_daily_cron' ) ) {
        wp_schedule_event( time(), 'daily', 'mayaerp_daily_cron' );
    }
} );
add_action( 'mayaerp_daily_cron', function() {
    global $wpdb;
    $p = $wpdb->prefix . 'mayaerp_';
    $today = current_time( 'Y-m-d' );

    // Mark overdue invoices
    $wpdb->query( "UPDATE {$p}documents SET status='overdue' WHERE type='invoice' AND status='sent' AND date_due < '{$today}'" );

    // Suspend expired trials
    $wpdb->query( "UPDATE {$p}companies SET status='suspended' WHERE plan_type='trial' AND plan_end < '{$today}' AND status='trial'" );
} );

/* ═══════════════════════════════════════════════════════════
   SMTP OVERRIDE
   ═══════════════════════════════════════════════════════════ */
add_action( 'phpmailer_init', function( $phpmailer ) {
    $host = mayaerp_opt( 'smtp_host' );
    if ( empty( $host ) ) return;
    $phpmailer->isSMTP();
    $phpmailer->Host       = $host;
    $phpmailer->SMTPAuth   = true;
    $phpmailer->Port       = intval( mayaerp_opt( 'smtp_port', 587 ) );
    $phpmailer->Username   = mayaerp_opt( 'smtp_user' );
    $phpmailer->Password   = mayaerp_decrypt( mayaerp_opt( 'smtp_pass' ) );
    $phpmailer->SMTPSecure = mayaerp_opt( 'smtp_encryption', 'tls' );
    $phpmailer->CharSet    = 'UTF-8';
} );

/* ═══════════════════════════════════════════════════════════
   WP-ADMIN SETTINGS PAGE
   ═══════════════════════════════════════════════════════════ */
add_action( 'admin_menu', function() {
    add_menu_page(
        'MayaERP',
        'MayaERP',
        'manage_options',
        'mayaerp',
        'mayaerp_admin_app_page',
        'dashicons-building',
        30
    );
    add_submenu_page(
        'mayaerp',
        'Abrir ERP',
        'Abrir ERP',
        'manage_options',
        'mayaerp',
        'mayaerp_admin_app_page'
    );
    add_submenu_page(
        'mayaerp',
        'Configuracion',
        'Configuracion',
        'manage_options',
        'mayaerp-settings',
        'mayaerp_admin_page'
    );
} );

/* ───────────────────────────────────────────────────────────
   WP-ADMIN: full ERP embedded (auto-login as owner)
   ─────────────────────────────────────────────────────────── */
function mayaerp_admin_app_page() {
    $owner = mayaerp_resolve_owner_user_id();
    if ( ! $owner ) {
        echo '<div class="wrap"><h1>MayaERP</h1><div class="notice notice-warning"><p>No se encontro una cuenta de propietario activa. Activa el plugin o crea una cuenta desde la pagina publica del ERP.</p></div></div>';
        return;
    }
    $tok = wp_generate_password( 32, false );
    set_transient( 'mayaerp_sso_' . $tok, $owner, 120 );
    $url = add_query_arg( 'mayaerp_admin_sso', $tok, mayaerp_app_url() );
    ?>
    <style>
        #wpcontent, #wpbody-content { padding-left: 0 !important; }
        .mayaerp-admin-frame-wrap { position: absolute; left: 160px; right: 0; top: 32px; bottom: 0; }
        @media (max-width:782px){ .mayaerp-admin-frame-wrap{ left:0; top:46px; } }
        .mayaerp-admin-frame-wrap iframe { width:100%; height:100%; border:0; display:block; }
        .folded .mayaerp-admin-frame-wrap { left:36px; }
    </style>
    <div class="mayaerp-admin-frame-wrap">
        <iframe src="<?php echo esc_url( $url ); ?>" allow="clipboard-write; camera; microphone"></iframe>
    </div>
    <?php
}

function mayaerp_admin_page() {
    if ( isset( $_POST['mayaerp_save_settings'] ) && check_admin_referer( 'mayaerp_settings' ) ) {
        $fields = array(
            'app_url',
            'turnstile_site_key', 'turnstile_secret',
            'anthropic_api_key',
            'facturama_user', 'facturama_pass',
            'smtp_host', 'smtp_port', 'smtp_user', 'smtp_pass',
            'smtp_encryption', 'smtp_from_email', 'smtp_from_name',
            'banxico_token',
        );
        $encrypted = array( 'turnstile_secret', 'anthropic_api_key', 'facturama_pass', 'smtp_pass', 'banxico_token' );
        foreach ( $fields as $f ) {
            $val = sanitize_text_field( $_POST[ 'mayaerp_' . $f ] ?? '' );
            if ( in_array( $f, $encrypted ) && ! empty( $val ) ) {
                $val = mayaerp_encrypt( $val );
            }
            mayaerp_set_opt( $f, $val );
        }
        echo '<div class="updated"><p>Configuracion guardada.</p></div>';
    }
    ?>
    <div class="wrap">
        <h1>MayaERP — Configuracion</h1>
        <form method="post">
            <?php wp_nonce_field( 'mayaerp_settings' ); ?>
            <h2>Pagina del ERP</h2>
            <table class="form-table"><tr><th>URL del ERP</th><td><input type="url" name="mayaerp_app_url" value="<?php echo esc_attr( mayaerp_opt('app_url') ); ?>" class="regular-text" placeholder="https://facturamaya.com.mx/erp-mexico/"><p class="description">Pagina donde colocaste el shortcode [mayaerp]. Se usa para los enlaces de recuperacion de contrasena y el boton "Abrir ERP".</p></td></tr></table>

            <h2>Cloudflare Turnstile</h2>
            <table class="form-table"><tr><th>Site Key</th><td><input type="text" name="mayaerp_turnstile_site_key" value="<?php echo esc_attr( mayaerp_opt('turnstile_site_key') ); ?>" class="regular-text"></td></tr>
            <tr><th>Secret Key</th><td><input type="password" name="mayaerp_turnstile_secret" value="" class="regular-text" placeholder="(guardado cifrado)"></td></tr></table>

            <h2>Anthropic (IA)</h2>
            <table class="form-table"><tr><th>API Key</th><td><input type="password" name="mayaerp_anthropic_api_key" value="" class="regular-text" placeholder="sk-ant-..."></td></tr></table>

            <h2>Facturama</h2>
            <table class="form-table"><tr><th>Usuario</th><td><input type="text" name="mayaerp_facturama_user" value="<?php echo esc_attr( mayaerp_opt('facturama_user') ); ?>" class="regular-text"></td></tr>
            <tr><th>Contrasena</th><td><input type="password" name="mayaerp_facturama_pass" value="" class="regular-text"></td></tr></table>

            <h2>SMTP</h2>
            <table class="form-table">
            <tr><th>Host</th><td><input type="text" name="mayaerp_smtp_host" value="<?php echo esc_attr( mayaerp_opt('smtp_host') ); ?>" class="regular-text" placeholder="smtp.hostinger.com"></td></tr>
            <tr><th>Puerto</th><td><input type="text" name="mayaerp_smtp_port" value="<?php echo esc_attr( mayaerp_opt('smtp_port','587') ); ?>" class="small-text"></td></tr>
            <tr><th>Usuario</th><td><input type="text" name="mayaerp_smtp_user" value="<?php echo esc_attr( mayaerp_opt('smtp_user') ); ?>" class="regular-text"></td></tr>
            <tr><th>Contrasena</th><td><input type="password" name="mayaerp_smtp_pass" value="" class="regular-text"></td></tr>
            <tr><th>Cifrado</th><td><select name="mayaerp_smtp_encryption"><option value="tls" <?php selected(mayaerp_opt('smtp_encryption'),'tls'); ?>>TLS</option><option value="ssl" <?php selected(mayaerp_opt('smtp_encryption'),'ssl'); ?>>SSL</option></select></td></tr>
            <tr><th>Email Remitente</th><td><input type="email" name="mayaerp_smtp_from_email" value="<?php echo esc_attr( mayaerp_opt('smtp_from_email','contacto@facturamaya.com.mx') ); ?>" class="regular-text"></td></tr>
            <tr><th>Nombre Remitente</th><td><input type="text" name="mayaerp_smtp_from_name" value="<?php echo esc_attr( mayaerp_opt('smtp_from_name','MayaERP') ); ?>" class="regular-text"></td></tr>
            </table>

            <h2>Banxico</h2>
            <table class="form-table"><tr><th>Token</th><td><input type="password" name="mayaerp_banxico_token" value="" class="regular-text"></td></tr></table>

            <p class="submit"><input type="submit" name="mayaerp_save_settings" class="button-primary" value="Guardar Configuracion"></p>
        </form>
    </div>
    <?php
}

/* ═══════════════════════════════════════════════════════════
   AJAX HANDLER
   ═══════════════════════════════════════════════════════════ */
add_action( 'wp_ajax_mayaerp', 'mayaerp_ajax' );
add_action( 'wp_ajax_nopriv_mayaerp', 'mayaerp_ajax' );

function mayaerp_ajax() {
    global $wpdb;
    $p   = $wpdb->prefix . 'mayaerp_';
    $act = sanitize_text_field( $_POST['act'] ?? '' );

    // Public actions (no session required)
    $public_actions = array( 'register', 'verify_email', 'resend_code', 'login', 'forgot_password', 'reset_password', 'check_rfc', 'me' );

    // Session-based auth
    $uid = 0;
    $cid = 0;

    if ( ! in_array( $act, $public_actions ) ) {
        if ( empty( $_SESSION['mayaerp_uid'] ) ) {
            wp_send_json_error( array( 'msg' => 'Sesion expirada. Inicia sesion nuevamente.', 'code' => 'SESSION_EXPIRED' ) );
        }
        $uid = intval( $_SESSION['mayaerp_uid'] );
        $cid = intval( $_SESSION['mayaerp_cid'] ?? 0 );
    }

    // Include the handler file
    $handler_file = MAYAERP_DIR . 'includes/ajax-handlers.php';
    if ( file_exists( $handler_file ) ) {
        include $handler_file;
    } else {
        wp_send_json_error( array( 'msg' => 'Error interno: archivo de handlers no encontrado.' ) );
    }

    wp_die();
}
